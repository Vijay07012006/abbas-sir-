import React from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { useAuth } from './context/AuthContext'

// User Pages
import Home from './pages/user/Home'
import UserLogin from './pages/user/UserLogin'
import UserDashboard from './pages/user/UserDashboard'
import ProductsPage from './pages/user/ProductsPage'
import ProductDetail from './pages/user/ProductDetail'
import CartPage from './pages/user/CartPage'
import { CheckoutPage } from './pages/user/CheckoutPage'
import { OrdersPage } from './pages/user/OrdersPage'
import { AboutPage, ContactPage } from './pages/user/AboutPage'

// Admin Pages
import AdminAuth from './pages/admin/AdminAuth'
import AdminLayout from './pages/admin/layout/AdminLayout'
import AdminHome from './pages/admin/layout/AdminHome'
import Category from './pages/admin/category/Category'
import AddCategory from './pages/admin/category/AddCategory'
import { Products } from './pages/admin/products/Products'
import AddProduct from './pages/admin/products/AddProduct'
import Orders from './pages/admin/orders/Orders'
import Users from './pages/admin/users/Users'

// Protected Route Components
const UserRoute = ({ children }) => {
  const { user } = useAuth()
  return user ? children : <Navigate to="/login" replace />
}

const AdminRoute = ({ children }) => {
  const { admin } = useAuth()
  return admin ? children : <Navigate to="/admin" replace />
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Public */}
        <Route path="/" element={<Navigate to="/home" replace />} />
        <Route path="/home" element={<Home />} />
        <Route path="/login" element={<UserLogin />} />
        <Route path="/products" element={<ProductsPage />} />
        <Route path="/product/:id" element={<ProductDetail />} />
        <Route path="/about" element={<AboutPage />} />
        <Route path="/contact" element={<ContactPage />} />
        <Route path="/cart" element={<CartPage />} />

        {/* User Protected */}
        <Route path="/dashboard" element={<UserRoute><UserDashboard /></UserRoute>} />
        <Route path="/checkout" element={<UserRoute><CheckoutPage /></UserRoute>} />
        <Route path="/orders" element={<UserRoute><OrdersPage /></UserRoute>} />

        {/* Admin Auth */}
        <Route path="/admin" element={<AdminAuth />} />

        {/* Admin Protected Layout */}
        <Route path="/admin" element={<AdminRoute><AdminLayout /></AdminRoute>}>
          <Route path="home" element={<AdminHome />} />
          <Route path="category" element={<Category />} />
          <Route path="add-category" element={<AddCategory />} />
          <Route path="edit-category/:id" element={<AddCategory />} />
          <Route path="products" element={<Products />} />
          <Route path="add-product" element={<AddProduct />} />
          <Route path="edit-product/:id" element={<AddProduct />} />
          <Route path="orders" element={<Orders />} />
          <Route path="users" element={<Users />} />
        </Route>

        {/* 404 */}
        <Route path="*" element={<Navigate to="/home" replace />} />
      </Routes>
    </BrowserRouter>
  )
}
