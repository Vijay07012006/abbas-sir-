import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import { AuthProvider } from './context/AuthContext.jsx'
import 'bootstrap/dist/css/bootstrap.min.css'
import './assets/css/global.css'
import { ToastContainer } from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <AuthProvider>
      <App />
      <ToastContainer
        position="bottom-right"
        autoClose={3000}
        theme="dark"
        toastStyle={{
          background: '#0d1b2a',
          border: '1px solid rgba(0,212,255,0.2)',
          color: '#ccd6f6',
          fontFamily: "'Exo 2', sans-serif"
        }}
      />
    </AuthProvider>
  </React.StrictMode>
)
