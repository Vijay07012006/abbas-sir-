import React, { createContext, useContext, useState, useEffect } from 'react';
import api from '../utils/api';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [admin, setAdmin] = useState(null);
  const [loading, setLoading] = useState(true);
  const [cart, setCart] = useState(() => {
    try { return JSON.parse(localStorage.getItem('sp_cart') || '[]'); } catch { return []; }
  });

  useEffect(() => {
    const userInfo = localStorage.getItem('userInfo');
    const adminInfo = localStorage.getItem('adminInfo');
    if (userInfo) setUser(JSON.parse(userInfo));
    if (adminInfo) setAdmin(JSON.parse(adminInfo));
    setLoading(false);
  }, []);

  useEffect(() => {
    localStorage.setItem('sp_cart', JSON.stringify(cart));
  }, [cart]);

  const loginUser = async (email, password) => {
    const res = await api.post('/api/user/login', { email, password });
    const { token, user: userData } = res.data;
    localStorage.setItem('userToken', token);
    localStorage.setItem('userInfo', JSON.stringify(userData));
    setUser(userData);
    return res.data;
  };

  const registerUser = async (name, email, password, mobile) => {
    const res = await api.post('/api/user/register', { name, email, password, mobile });
    const { token, user: userData } = res.data;
    localStorage.setItem('userToken', token);
    localStorage.setItem('userInfo', JSON.stringify(userData));
    setUser(userData);
    return res.data;
  };

  const loginAdmin = async (email, password) => {
    const res = await api.post('/api/admin/login', { email, password });
    const { token, admin: adminData } = res.data;
    localStorage.setItem('adminToken', token);
    localStorage.setItem('adminInfo', JSON.stringify(adminData));
    setAdmin(adminData);
    return res.data;
  };

  const logoutUser = () => {
    localStorage.removeItem('userToken');
    localStorage.removeItem('userInfo');
    setUser(null);
  };

  const logoutAdmin = () => {
    localStorage.removeItem('adminToken');
    localStorage.removeItem('adminInfo');
    setAdmin(null);
  };

  const addToCart = (product, qty = 1) => {
    setCart(prev => {
      const exists = prev.find(x => x._id === product._id);
      if (exists) return prev.map(x => x._id === product._id ? { ...x, qty: x.qty + qty } : x);
      return [...prev, { ...product, qty }];
    });
  };

  const removeFromCart = (productId) => setCart(prev => prev.filter(x => x._id !== productId));

  const updateCartQty = (productId, qty) => {
    if (qty < 1) return removeFromCart(productId);
    setCart(prev => prev.map(x => x._id === productId ? { ...x, qty } : x));
  };

  const clearCart = () => setCart([]);

  const cartTotal = cart.reduce((a, b) => a + (b.finalPrice || b.actualPrice) * b.qty, 0);
  const cartCount = cart.reduce((a, b) => a + b.qty, 0);

  return (
    <AuthContext.Provider value={{
      user, admin, loading, cart, cartTotal, cartCount,
      loginUser, registerUser, loginAdmin, logoutUser, logoutAdmin,
      addToCart, removeFromCart, updateCartQty, clearCart
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
export default AuthContext;
