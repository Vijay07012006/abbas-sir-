import React, { useState, useEffect } from 'react'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { toast } from 'react-toastify'

const css = `
.sp-nav {
  position: fixed; top: 0; left: 0; right: 0; z-index: 1000;
  height: 68px; display: flex; align-items: center;
  justify-content: space-between; padding: 0 2rem;
  background: rgba(10,15,30,0.85); backdrop-filter: blur(20px);
  border-bottom: 1px solid rgba(0,212,255,0.18);
  transition: all 0.35s ease;
}
.sp-nav.scrolled { background: rgba(10,15,30,0.97); box-shadow: 0 4px 30px rgba(0,0,0,0.5); }
.nav-logo { display: flex; align-items: center; gap: 10px; text-decoration: none; }
.logo-box {
  width: 40px; height: 40px;
  background: linear-gradient(135deg,#00d4ff,#7b2ff7);
  border-radius: 8px; display: flex; align-items: center;
  justify-content: center; font-family: var(--font1);
  font-weight: 900; font-size: 14px; color: #fff;
  animation: logoPulse 3s ease-in-out infinite;
}
@keyframes logoPulse {
  0%,100% { box-shadow: 0 0 15px rgba(0,212,255,0.4); }
  50% { box-shadow: 0 0 30px rgba(0,212,255,0.7); }
}
.logo-text { font-family: var(--font1); font-size: 15px; font-weight: 700; color: var(--white); }
.logo-text span { color: var(--accent); }
.nav-links { display: flex; align-items: center; gap: 4px; list-style: none; }
.nav-links a {
  font-family: var(--font2); font-size: 13px; font-weight: 600;
  color: var(--textdim); text-decoration: none; padding: 6px 13px;
  border-radius: 6px; transition: var(--transition); position: relative;
}
.nav-links a::after {
  content: ''; position: absolute; bottom: 2px; left: 13px; right: 13px;
  height: 1.5px; background: var(--accent); transform: scaleX(0); transition: var(--transition);
}
.nav-links a:hover, .nav-links a.active { color: var(--accent); }
.nav-links a:hover::after, .nav-links a.active::after { transform: scaleX(1); }
.nav-actions { display: flex; align-items: center; gap: 10px; }
.nav-cart {
  position: relative; display: flex; align-items: center; gap: 6px;
  color: var(--textdim); text-decoration: none; font-size: 20px;
  padding: 6px 10px; border-radius: 8px; transition: var(--transition);
}
.nav-cart:hover { color: var(--accent); }
.cart-count {
  position: absolute; top: -2px; right: -2px;
  background: var(--accent3); color: #fff; width: 18px; height: 18px;
  border-radius: 50%; font-size: 10px; display: flex;
  align-items: center; justify-content: center; font-family: var(--font3);
}
.btn-nav-login {
  font-family: var(--font2); font-size: 12px; font-weight: 700;
  color: var(--accent); background: transparent;
  border: 1.5px solid var(--accent); padding: 7px 18px;
  border-radius: 20px; text-decoration: none; transition: var(--transition);
}
.btn-nav-login:hover { background: var(--accent); color: var(--c1); }
.btn-nav-reg {
  font-family: var(--font2); font-size: 12px; font-weight: 700;
  color: #fff; background: linear-gradient(135deg,var(--accent),var(--accent2));
  border: none; padding: 7px 18px; border-radius: 20px;
  text-decoration: none; transition: var(--transition);
  box-shadow: 0 0 15px rgba(0,212,255,0.3);
}
.btn-nav-reg:hover { transform: translateY(-2px); box-shadow: 0 0 25px rgba(0,212,255,0.5); }
.btn-nav-user {
  font-family: var(--font2); font-size: 12px; font-weight: 700;
  color: #fff; background: linear-gradient(135deg,var(--green),#00aa55);
  border: none; padding: 7px 18px; border-radius: 20px;
  text-decoration: none; transition: var(--transition);
}
.btn-nav-logout {
  font-family: var(--font2); font-size: 12px; font-weight: 600;
  color: var(--textdim); background: transparent;
  border: 1px solid rgba(255,255,255,0.15); padding: 7px 14px;
  border-radius: 20px; cursor: pointer; transition: var(--transition);
}
.btn-nav-logout:hover { border-color: var(--red); color: var(--red); }
.hamburger { display: none; flex-direction: column; gap: 5px; cursor: pointer; padding: 4px; background: none; border: none; }
.hamburger span { width: 24px; height: 2px; background: var(--text); border-radius: 2px; transition: var(--transition); display: block; }
.hamburger.open span:nth-child(1) { transform: rotate(45deg) translate(5px,5px); }
.hamburger.open span:nth-child(2) { opacity: 0; }
.hamburger.open span:nth-child(3) { transform: rotate(-45deg) translate(5px,-5px); }
.mobile-menu {
  display: none; position: fixed; top: 68px; left: 0; right: 0;
  background: rgba(10,15,30,0.98); backdrop-filter: blur(20px);
  z-index: 999; padding: 1rem; border-bottom: 1px solid var(--border);
  transform: translateY(-10px); opacity: 0; transition: var(--transition);
}
.mobile-menu.open { display: block; transform: translateY(0); opacity: 1; }
.mobile-menu ul { list-style: none; }
.mobile-menu ul li a {
  display: block; padding: 12px 16px; color: var(--textdim);
  text-decoration: none; font-size: 15px; border-radius: 8px; transition: var(--transition);
}
.mobile-menu ul li a:hover { background: rgba(0,212,255,0.08); color: var(--accent); }
.mobile-actions { display: flex; gap: 10px; padding: 12px 16px; flex-wrap: wrap; }
@media(max-width:991px) {
  .nav-links, .nav-actions { display: none !important; }
  .hamburger { display: flex !important; }
}
`

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const { user, admin, logoutUser, logoutAdmin, cartCount } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 30)
    window.addEventListener('scroll', fn)
    return () => window.removeEventListener('scroll', fn)
  }, [])

  useEffect(() => { setMenuOpen(false) }, [location.pathname])

  const handleLogout = () => {
    if (admin) { logoutAdmin(); toast.info('Admin logged out.') }
    else { logoutUser(); toast.info('Logged out.') }
    navigate('/home')
  }

  const isActive = (path) => location.pathname === path ? 'active' : ''

  const navLinks = [
    ['Home', '/home'], ['Products', '/products'],
    ['About', '/about'], ['Contact', '/contact']
  ]

  return (
    <>
      <style>{css}</style>
      <nav className={`sp-nav ${scrolled ? 'scrolled' : ''}`}>
        <Link to="/home" className="nav-logo">
          <div className="logo-box">SP</div>
          <span className="logo-text">Softpr<span>Innovation</span></span>
        </Link>

        <ul className="nav-links">
          {navLinks.map(([label, path]) => (
            <li key={path}><Link to={path} className={isActive(path)}>{label}</Link></li>
          ))}
          {admin && <li><Link to="/admin/home" className={isActive('/admin/home')}>⚙ Admin</Link></li>}
        </ul>

        <div className="nav-actions">
          <Link to="/cart" className="nav-cart">
            🛒
            {cartCount > 0 && <span className="cart-count">{cartCount}</span>}
          </Link>
          {user || admin ? (
            <>
              <Link to={admin ? '/admin/home' : '/dashboard'} className="btn-nav-user">
                {admin ? '⚙ Admin Panel' : `👤 ${user?.name?.split(' ')[0]}`}
              </Link>
              <button className="btn-nav-logout" onClick={handleLogout}>Logout</button>
            </>
          ) : (
            <>
              <Link to="/login" className="btn-nav-login">Login</Link>
              <Link to="/login?tab=register" className="btn-nav-reg">Register</Link>
            </>
          )}
        </div>

        <button className={`hamburger ${menuOpen ? 'open' : ''}`} onClick={() => setMenuOpen(o => !o)}>
          <span /><span /><span />
        </button>
      </nav>

      <div className={`mobile-menu ${menuOpen ? 'open' : ''}`}>
        <ul>
          {navLinks.map(([label, path]) => (
            <li key={path}><Link to={path}>{label}</Link></li>
          ))}
          {admin && <li><Link to="/admin/home">⚙ Admin Panel</Link></li>}
          {(user || admin) && <li><Link to={admin ? '/admin/home' : '/dashboard'}>Dashboard</Link></li>}
        </ul>
        <div className="mobile-actions">
          <Link to="/cart" className="btn-outline">🛒 Cart ({cartCount})</Link>
          {user || admin ? (
            <button className="btn-danger" onClick={handleLogout}>Logout</button>
          ) : (
            <>
              <Link to="/login" className="btn-outline">Login</Link>
              <Link to="/login?tab=register" className="btn-glow">Register</Link>
            </>
          )}
        </div>
      </div>
    </>
  )
}
