import React from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { toast } from 'react-toastify'
import { IMG_URL } from '../utils/api'

const css = `
.prod-card {
  background: var(--card); border: 1px solid var(--border);
  border-radius: 16px; overflow: hidden; transition: var(--transition);
  position: relative; display: flex; flex-direction: column; height: 100%;
}
.prod-card:hover {
  transform: translateY(-10px); border-color: rgba(0,212,255,0.4);
  box-shadow: 0 25px 50px rgba(0,0,0,0.4), 0 0 20px rgba(0,212,255,0.15);
}
.prod-img-wrap {
  height: 200px;
  background: linear-gradient(135deg, rgba(13,27,42,1), rgba(17,34,64,1));
  display: flex; align-items: center; justify-content: center;
  border-bottom: 1px solid var(--border); position: relative; overflow: hidden;
}
.prod-img-wrap::after {
  content: ''; position: absolute; inset: 0;
  background: radial-gradient(ellipse at center, rgba(0,212,255,0.06) 0%, transparent 70%);
  transition: var(--transition);
}
.prod-card:hover .prod-img-wrap::after { background: radial-gradient(ellipse at center, rgba(0,212,255,0.14) 0%, transparent 70%); }
.prod-img {
  max-width: 75%; max-height: 75%; object-fit: contain;
  filter: drop-shadow(0 4px 20px rgba(0,212,255,0.2));
  transition: var(--transition); position: relative; z-index: 1;
}
.prod-card:hover .prod-img { transform: scale(1.08); filter: drop-shadow(0 4px 30px rgba(0,212,255,0.4)); }
.prod-no-img { font-size: 4rem; opacity: 0.3; }
.prod-discount {
  position: absolute; top: 12px; left: 12px;
  background: linear-gradient(135deg, var(--accent3), #e55000);
  color: #fff; font-family: var(--font1); font-size: 10px;
  font-weight: 700; padding: 4px 8px; border-radius: 10px; z-index: 2;
}
.prod-tag {
  position: absolute; top: 12px; right: 12px;
  font-family: var(--font3); font-size: 10px; padding: 4px 10px;
  border-radius: 12px; letter-spacing: 1px; text-transform: uppercase; z-index: 2;
}
.prod-body { padding: 1.2rem; flex: 1; display: flex; flex-direction: column; gap: 6px; }
.prod-cat { font-family: var(--font3); font-size: 10px; color: var(--accent); letter-spacing: 2px; text-transform: uppercase; opacity: 0.8; }
.prod-name { font-family: var(--font1); font-size: 13px; font-weight: 700; color: var(--white); line-height: 1.3; }
.prod-desc { font-size: 12px; color: var(--textdim); line-height: 1.5; flex: 1; }
.prod-meta { display: flex; gap: 8px; flex-wrap: wrap; }
.prod-meta span { font-family: var(--font3); font-size: 10px; letter-spacing: 1px; }
.prod-free { color: var(--green); }
.prod-cod { color: #b57aff; }
.prod-footer {
  display: flex; align-items: center; justify-content: space-between;
  padding-top: 10px; border-top: 1px solid rgba(255,255,255,0.06); margin-top: auto;
}
.prod-price { font-family: var(--font1); font-size: 17px; font-weight: 900; color: var(--accent); }
.prod-old { font-size: 11px; color: var(--textdim); text-decoration: line-through; margin-left: 5px; }
.btn-add-cart {
  font-family: var(--font2); font-weight: 700; font-size: 11px;
  color: var(--c1); background: linear-gradient(135deg, var(--accent), var(--accent2));
  border: none; padding: 8px 14px; border-radius: 20px; cursor: pointer;
  transition: var(--transition); letter-spacing: 0.5px; white-space: nowrap;
}
.btn-add-cart:hover { transform: scale(1.06); box-shadow: 0 0 15px rgba(0,212,255,0.4); }
.btn-add-cart:disabled { opacity: 0.5; cursor: not-allowed; transform: none; }
.out-of-stock-overlay {
  position: absolute; inset: 0; background: rgba(0,0,0,0.5);
  display: flex; align-items: center; justify-content: center;
  z-index: 3;
}
.out-of-stock-overlay span {
  font-family: var(--font1); font-size: 12px; color: var(--red);
  border: 1px solid var(--red); padding: 6px 16px; border-radius: 20px;
  background: rgba(255,71,87,0.1);
}
`

export default function ProductCard({ product }) {
  const { addToCart, user } = useAuth()
  const navigate = window.history

  const finalPrice = product.finalPrice || Math.round(product.actualPrice - (product.actualPrice * product.discount) / 100)
  const isOOS = product.stockStatus === 'outOfStock'

  const handleCart = (e) => {
    e.preventDefault()
    if (!user) { window.location.href = '/login'; return }
    addToCart(product)
    toast.success(`${product.name} added to cart! 🛒`)
  }

  return (
    <>
      <style>{css}</style>
      <div className="prod-card">
        {product.discount > 0 && <span className="prod-discount">-{product.discount}%</span>}
        {product.tag && <span className={`prod-tag badge-${product.tag}`}>{product.tag}</span>}

        <Link to={`/product/${product._id}`}>
          <div className="prod-img-wrap">
            {isOOS && (
              <div className="out-of-stock-overlay"><span>Out of Stock</span></div>
            )}
            {product.images && product.images[0] ? (
              <img
                src={`${IMG_URL}/${product.images[0]}`}
                alt={product.name}
                className="prod-img"
                loading="lazy"
                onError={e => { e.target.style.display = 'none'; e.target.nextSibling.style.display = 'block' }}
              />
            ) : null}
            <span className="prod-no-img" style={{ display: product.images?.[0] ? 'none' : 'block' }}>📦</span>
          </div>
        </Link>

        <div className="prod-body">
          {product.category && (
            <div className="prod-cat">{product.category.category || product.category}</div>
          )}
          <Link to={`/product/${product._id}`} style={{ textDecoration: 'none' }}>
            <div className="prod-name">{product.name}</div>
          </Link>
          <div className="prod-desc">
            {product.description?.slice(0, 70)}{product.description?.length > 70 ? '…' : ''}
          </div>
          <div className="prod-meta">
            {product.freeDelivery && <span className="prod-free">✈ Free Delivery</span>}
            {product.isCod && <span className="prod-cod">💵 COD</span>}
          </div>
          <div className="prod-footer">
            <div>
              <span className="prod-price">₹{finalPrice.toLocaleString('en-IN')}</span>
              {product.discount > 0 && (
                <span className="prod-old">₹{Number(product.actualPrice).toLocaleString('en-IN')}</span>
              )}
            </div>
            <button className="btn-add-cart" onClick={handleCart} disabled={isOOS}>
              {isOOS ? 'Sold Out' : '+ Cart'}
            </button>
          </div>
        </div>
      </div>
    </>
  )
}
