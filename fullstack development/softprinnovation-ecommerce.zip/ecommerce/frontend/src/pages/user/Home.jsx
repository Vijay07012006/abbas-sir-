import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import Navbar from '../../components/Navbar'
import ProductCard from '../../components/ProductCard'
import api from '../../utils/api'

const SLIDES = [
  { tag: 'New Arrivals 2025', title: ['Next-Gen', 'Electronics'], sub: 'Premium Raspberry Pi, Arduino, ESP32 & IoT components — curated for makers, engineers, and innovators.', gradient: 'linear-gradient(135deg,#0a0f1e 0%,#0d1b2a 50%,#112240 100%)' },
  { tag: 'IoT Essentials', title: ['Build The', 'Future Today'], sub: 'From microcontrollers to complete development boards — everything you need to bring your ideas to life.', gradient: 'linear-gradient(135deg,#0f0a1e 0%,#1a0d2a 50%,#240d40 100%)' },
  { tag: 'Best Deals', title: ['Up to 40%', 'Off Today'], sub: 'Limited-time offers on ESP32, Arduino Mega, Raspberry Pi 5, sensors and much more.', gradient: 'linear-gradient(135deg,#1e0a0a 0%,#2a0d0d 50%,#400d0d 100%)' },
]

const TICKERS = ['Raspberry Pi 5 — Now In Stock', 'Free Shipping on Orders Over ₹999', 'New Arduino Uno R4 Available', 'ESP32 Starter Kits — 20% Off', 'Same-Day Dispatch Before 3PM', '1000+ Electronics Components', 'Genuine Products Only', 'COD Available Nationwide']
const FEATURES = [
  { icon: '🚀', title: 'Fast Dispatch', desc: 'Orders placed before 3 PM dispatched same day.' },
  { icon: '✅', title: 'Genuine Products', desc: '100% authentic from certified manufacturers.' },
  { icon: '🛡️', title: 'Warranty & Support', desc: 'Manufacturer warranty on all products. 24/7 support.' },
  { icon: '💰', title: 'Best Prices', desc: 'Competitive pricing with deals for bulk & students.' },
  { icon: '📦', title: 'Secure Packaging', desc: 'Anti-static, shock-proof packaging every time.' },
  { icon: '🔁', title: 'Easy Returns', desc: 'Hassle-free 7-day return and replacement policy.' },
]
const TESTIMONIALS = [
  { stars: '★★★★★', text: 'Got my Raspberry Pi 5 in 24 hours — perfectly packaged. Best electronics store online!', name: 'Arjun Sharma', role: 'Electronics Engineer, Bangalore' },
  { stars: '★★★★★', text: 'Incredible variety of IoT components. Support helped me pick the right sensors for my project.', name: 'Priya Nair', role: 'IoT Developer, Pune' },
  { stars: '★★★★☆', text: 'Prices are competitive and delivery is super fast. Arduino order was dispatched same day.', name: 'Rohit Verma', role: 'Student Maker, Delhi' },
]

const css = `
.home-wrap { background: var(--c1); min-height: 100vh; }
/* PARTICLES */
.particles { position: fixed; inset: 0; pointer-events: none; z-index: 0; overflow: hidden; }
.particle { position: absolute; border-radius: 50%; animation: floatP linear infinite; }
@keyframes floatP { 0%{transform:translateY(100vh) rotate(0deg);opacity:0} 10%{opacity:1} 90%{opacity:1} 100%{transform:translateY(-10vh) rotate(720deg);opacity:0} }
/* HERO */
.hero { position: relative; min-height: 100vh; display: flex; align-items: center; overflow: hidden; padding-top: 68px; }
.hero-slide { position: absolute; inset: 0; opacity: 0; transition: opacity 1s ease; }
.hero-slide.active { opacity: 1; }
.hero-overlay { position: absolute; inset: 0; background: linear-gradient(135deg,rgba(10,15,30,0.93) 0%,rgba(10,15,30,0.7) 50%,rgba(10,15,30,0.4) 100%); }
.hero-grid { position: absolute; inset: 0; background-image: linear-gradient(rgba(0,212,255,0.04) 1px,transparent 1px),linear-gradient(90deg,rgba(0,212,255,0.04) 1px,transparent 1px); background-size: 50px 50px; animation: gridMove 20s linear infinite; }
@keyframes gridMove { 0%{background-position:0 0} 100%{background-position:50px 50px} }
.hero-content { position: relative; z-index: 2; padding: 3rem 0; }
.hero-eyebrow { font-family: var(--font3); font-size: 12px; color: var(--green); letter-spacing: 4px; text-transform: uppercase; margin-bottom: 1rem; display: flex; align-items: center; gap: 12px; }
.hero-eyebrow::before { content: ''; width: 36px; height: 1px; background: var(--green); box-shadow: 0 0 8px var(--green); }
.hero-title { font-family: var(--font1); font-size: clamp(2.2rem,5.5vw,4.5rem); font-weight: 900; line-height: 1.05; margin-bottom: 1.2rem; }
.hero-title .grad { background: linear-gradient(135deg,var(--accent),var(--accent2),var(--accent3)); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; }
.hero-sub { font-size: 1.05rem; color: var(--textdim); max-width: 520px; line-height: 1.75; margin-bottom: 2rem; }
.hero-btns { display: flex; gap: 14px; flex-wrap: wrap; }
.hero-stats { display: flex; gap: 2rem; margin-top: 2.5rem; flex-wrap: wrap; }
.hstat-num { font-family: var(--font1); font-size: 1.8rem; font-weight: 900; color: var(--accent); display: block; text-shadow: 0 0 20px rgba(0,212,255,0.4); }
.hstat-label { font-family: var(--font3); font-size: 10px; color: var(--textdim); letter-spacing: 2px; text-transform: uppercase; }
.hero-indicators { position: absolute; bottom: 30px; left: 50%; transform: translateX(-50%); z-index: 3; display: flex; gap: 10px; }
.hero-dot { width: 8px; height: 8px; border-radius: 50%; background: rgba(255,255,255,0.3); cursor: pointer; transition: var(--transition); }
.hero-dot.active { background: var(--accent); box-shadow: 0 0 10px var(--accent); width: 24px; border-radius: 4px; }
.circuit-card { background: rgba(13,27,42,0.8); border: 1px solid var(--border); border-radius: 16px; padding: 1.5rem; backdrop-filter: blur(10px); box-shadow: 0 0 60px rgba(0,212,255,0.1); }
/* TICKER */
.ticker { background: rgba(0,212,255,0.06); border-top: 1px solid var(--border); border-bottom: 1px solid var(--border); padding: 10px 0; overflow: hidden; position: relative; z-index: 2; }
.ticker-inner { display: flex; gap: 50px; animation: tick 30s linear infinite; white-space: nowrap; }
@keyframes tick { 0%{transform:translateX(0)} 100%{transform:translateX(-50%)} }
.ticker-item { font-family: var(--font3); font-size: 12px; color: var(--accent); letter-spacing: 2px; display: inline-flex; align-items: center; gap: 10px; }
.ticker-dot { width: 5px; height: 5px; background: var(--green); border-radius: 50%; box-shadow: 0 0 6px var(--green); }
/* SECTION */
.sp-section { position: relative; z-index: 2; padding: 5rem 0; }
/* CAT CARDS */
.cat-grid { display: grid; grid-template-columns: repeat(auto-fill,minmax(150px,1fr)); gap: 16px; margin-top: 2rem; }
.cat-card { background: var(--card); border: 1px solid var(--border); border-radius: 14px; padding: 1.75rem 1.25rem; text-align: center; text-decoration: none; display: block; transition: var(--transition); position: relative; overflow: hidden; }
.cat-card:hover { transform: translateY(-8px); border-color: rgba(0,212,255,0.5); box-shadow: 0 20px 40px rgba(0,0,0,0.4),0 0 20px rgba(0,212,255,0.15); }
.cat-img-wrap { width: 70px; height: 70px; border-radius: 50%; background: rgba(0,212,255,0.08); border: 1.5px solid var(--border); display: flex; align-items: center; justify-content: center; margin: 0 auto 14px; transition: var(--transition); font-size: 2rem; overflow: hidden; }
.cat-card:hover .cat-img-wrap { border-color: var(--accent); box-shadow: 0 0 20px rgba(0,212,255,0.3); }
.cat-img { width: 46px; height: 46px; object-fit: contain; filter: drop-shadow(0 0 8px rgba(0,212,255,0.3)); }
.cat-name { font-family: var(--font1); font-size: 11px; font-weight: 700; color: var(--white); display: block; margin-bottom: 4px; }
.cat-hint { font-family: var(--font3); font-size: 10px; color: var(--textdim); }
/* PRODUCTS GRID */
.products-grid { display: grid; grid-template-columns: repeat(auto-fill,minmax(250px,1fr)); gap: 20px; margin-top: 2rem; }
/* FEATURES */
.feat-grid { display: grid; grid-template-columns: repeat(auto-fill,minmax(280px,1fr)); gap: 20px; margin-top: 2rem; }
.feat-item { background: var(--card); border: 1px solid var(--border); border-radius: 14px; padding: 1.75rem; display: flex; gap: 1.25rem; align-items: flex-start; transition: var(--transition); }
.feat-item:hover { border-color: rgba(0,212,255,0.35); transform: translateX(4px); box-shadow: 0 10px 30px rgba(0,0,0,0.3); }
.feat-icon { width: 52px; height: 52px; flex-shrink: 0; border: 1px solid var(--border); border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 1.6rem; background: rgba(0,212,255,0.06); transition: var(--transition); }
.feat-item:hover .feat-icon { border-color: var(--accent); box-shadow: 0 0 15px rgba(0,212,255,0.2); }
.feat-title { font-family: var(--font1); font-size: 13px; font-weight: 700; color: var(--accent); margin-bottom: 6px; }
.feat-desc { font-size: 13px; color: var(--textdim); line-height: 1.55; }
/* CTA */
.cta-banner { position: relative; z-index: 2; border: 1px solid var(--border); border-radius: 20px; padding: 5rem 3rem; text-align: center; overflow: hidden; background: linear-gradient(135deg,rgba(0,212,255,0.05),rgba(123,47,247,0.08)); margin: 1rem 0; }
.cta-banner::before { content:''; position:absolute; inset:0; background:radial-gradient(ellipse at 50% 50%,rgba(0,212,255,0.08),transparent 65%); animation:ctaPulse 5s ease-in-out infinite; }
@keyframes ctaPulse { 0%,100%{opacity:.5} 50%{opacity:1} }
.cta-banner h2 { font-family: var(--font1); font-size: clamp(1.4rem,3vw,2.2rem); font-weight: 900; color: var(--white); margin-bottom: 1rem; position: relative; }
.cta-banner p { color: var(--textdim); font-size: 15px; max-width: 480px; margin: 0 auto 2rem; position: relative; line-height: 1.7; }
/* TESTIMONIALS */
.testi-grid { display: grid; grid-template-columns: repeat(auto-fill,minmax(300px,1fr)); gap: 20px; margin-top: 2rem; }
.testi-card { background: var(--card); border: 1px solid var(--border); border-radius: 16px; padding: 2rem; position: relative; overflow: hidden; transition: var(--transition); }
.testi-card::after { content:'"'; position:absolute; top:-16px; right:20px; font-size:7rem; color:rgba(0,212,255,0.05); font-family:serif; line-height:1; }
.testi-card:hover { border-color: rgba(0,212,255,0.3); transform: translateY(-4px); }
.testi-stars { color: var(--green); font-size: 14px; letter-spacing: 2px; margin-bottom: 12px; }
.testi-text { font-size: 14px; color: var(--textdim); line-height: 1.75; font-style: italic; margin-bottom: 1.25rem; }
.testi-name { font-family: var(--font1); font-size: 12px; font-weight: 700; color: var(--accent); }
.testi-role { font-family: var(--font3); font-size: 11px; color: var(--textdim); margin-top: 2px; }
/* CONTACT */
.contact-wrap { background: var(--card); border: 1px solid var(--border); border-radius: 20px; padding: 2.5rem; }
.cf-label { font-family: var(--font3); font-size: 11px; color: var(--accent); letter-spacing: 2px; text-transform: uppercase; display: block; margin-bottom: 8px; }
.cf-input { width: 100%; background: rgba(0,10,25,0.8); border: 1px solid var(--border); border-radius: 10px; padding: 12px 16px; color: var(--text); font-family: var(--font2); font-size: 14px; outline: none; transition: var(--transition); margin-bottom: 1.25rem; }
.cf-input:focus { border-color: var(--accent); box-shadow: 0 0 15px rgba(0,212,255,0.12); }
textarea.cf-input { resize: vertical; min-height: 110px; }
.ci-item { display: flex; gap: 16px; align-items: center; margin-bottom: 20px; }
.ci-icon { width: 46px; height: 46px; flex-shrink: 0; border: 1px solid var(--border); border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 1.3rem; background: rgba(0,212,255,0.05); }
.ci-label { font-family: var(--font3); font-size: 10px; color: var(--accent); letter-spacing: 2px; text-transform: uppercase; }
.ci-val { font-size: 14px; color: var(--text); margin-top: 2px; }
/* FOOTER */
.sp-footer { position: relative; z-index: 2; border-top: 1px solid var(--border); background: rgba(5,10,20,0.98); padding: 4rem 0 2rem; }
.footer-brand { font-family: var(--font1); font-size: 18px; font-weight: 900; color: var(--white); margin-bottom: 1rem; }
.footer-brand span { color: var(--accent); }
.footer-desc { font-size: 13px; color: var(--textdim); line-height: 1.7; max-width: 280px; }
.footer-heading { font-family: var(--font1); font-size: 11px; font-weight: 700; color: var(--accent); letter-spacing: 3px; text-transform: uppercase; margin-bottom: 1.2rem; }
.footer-links { list-style: none; }
.footer-links li { margin-bottom: 10px; }
.footer-links a { color: var(--textdim); text-decoration: none; font-size: 14px; transition: var(--transition); display: flex; align-items: center; gap: 8px; }
.footer-links a::before { content: '›'; color: var(--accent); transition: var(--transition); }
.footer-links a:hover { color: var(--accent); }
.footer-links a:hover::before { transform: translateX(4px); }
.social-links { display: flex; gap: 12px; margin-top: 1rem; }
.social-btn { width: 40px; height: 40px; border: 1px solid var(--border); border-radius: 10px; display: flex; align-items: center; justify-content: center; color: var(--textdim); font-size: 16px; text-decoration: none; transition: var(--transition); }
.social-btn:hover { border-color: var(--accent); color: var(--accent); box-shadow: 0 0 12px rgba(0,212,255,0.3); }
.footer-bottom { border-top: 1px solid var(--border); margin-top: 3rem; padding-top: 1.5rem; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem; }
.footer-copy { font-family: var(--font3); font-size: 11px; color: var(--textdim); letter-spacing: 1px; }
.nl-row { display: flex; gap: 10px; margin-top: 1rem; }
.nl-input { flex: 1; background: rgba(0,10,25,0.8); border: 1px solid var(--border); border-radius: 8px; padding: 10px 14px; color: var(--text); font-family: var(--font2); font-size: 13px; outline: none; transition: var(--transition); }
.nl-input:focus { border-color: var(--accent); }
.nl-btn { background: linear-gradient(135deg,var(--accent),var(--accent2)); border: none; border-radius: 8px; padding: 10px 18px; font-family: var(--font1); font-size: 10px; font-weight: 700; color: var(--c1); cursor: pointer; transition: var(--transition); white-space: nowrap; letter-spacing: 1px; }
.nl-btn:hover { box-shadow: 0 0 20px rgba(0,212,255,0.4); }
@media(max-width:576px) {
  .cat-grid { grid-template-columns: repeat(2,1fr); }
  .cta-banner { padding: 3rem 1.5rem; }
  .hero-stats { gap: 1.2rem; }
}
`

const particles = Array.from({ length: 16 }, (_, i) => ({
  id: i, size: Math.random() * 4 + 2, left: Math.random() * 100,
  duration: Math.random() * 15 + 10, delay: Math.random() * 10,
  color: ['#00d4ff','#7b2ff7','#ff6b35','#00ff88'][Math.floor(Math.random() * 4)]
}))

export default function Home() {
  const [slide, setSlide] = useState(0)
  const [categories, setCategories] = useState([])
  const [products, setProducts] = useState([])
  const [loadingCats, setLoadingCats] = useState(true)
  const [loadingProds, setLoadingProds] = useState(true)
  const [contactMsg, setContactMsg] = useState({ name: '', email: '', subject: '', message: '' })

  useEffect(() => {
    const t = setInterval(() => setSlide(s => (s + 1) % SLIDES.length), 5000)
    return () => clearInterval(t)
  }, [])

  useEffect(() => {
    api.get('/api/category').then(r => { setCategories(r.data.categories || []); setLoadingCats(false) }).catch(() => setLoadingCats(false))
  }, [])

  useEffect(() => {
    api.get('/api/product?limit=8&status=active').then(r => { setProducts(r.data.products || []); setLoadingProds(false) }).catch(() => setLoadingProds(false))
  }, [])

  const cur = SLIDES[slide]

  return (
    <>
      <style>{css}</style>
      <div className="home-wrap">
        {/* Particles */}
        <div className="particles">
          {particles.map(p => (
            <div key={p.id} className="particle" style={{ width: p.size, height: p.size, left: `${p.left}%`, background: p.color, boxShadow: `0 0 ${p.size * 3}px ${p.color}`, animationDuration: `${p.duration}s`, animationDelay: `${p.delay}s` }} />
          ))}
        </div>

        <Navbar />

        {/* HERO */}
        <section className="hero">
          {SLIDES.map((s, i) => (
            <div key={i} className={`hero-slide ${i === slide ? 'active' : ''}`} style={{ background: s.gradient }} />
          ))}
          <div className="hero-overlay" />
          <div className="hero-grid" />

          <div className="container">
            <div className="row align-items-center">
              <div className="col-lg-7 hero-content">
                <div className="hero-eyebrow">{cur.tag}</div>
                <h1 className="hero-title">
                  {cur.title[0]}<br /><span className="grad">{cur.title[1]}</span>
                </h1>
                <p className="hero-sub">{cur.sub}</p>
                <div className="hero-btns">
                  <Link to="/products" className="btn-glow">Explore Products</Link>
                  <Link to="/products" className="btn-outline">Browse Categories</Link>
                </div>
                <div className="hero-stats">
                  {[['1K+','Products'],['10K+','Customers'],['99%','Satisfaction'],['24h','Support']].map(([n,l]) => (
                    <div key={l}>
                      <span className="hstat-num">{n}</span>
                      <span className="hstat-label">{l}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="col-lg-5 mt-4 mt-lg-0" style={{ position: 'relative', zIndex: 2 }}>
                <div className="circuit-card">
                  <svg viewBox="0 0 400 260" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ width: '100%' }}>
                    <rect width="400" height="260" fill="#010D1A" rx="8"/>
                    <path d="M20 130 H90 V70 H190" stroke="#00d4ff" strokeWidth="1.5" opacity="0.35"/>
                    <path d="M20 150 H70 V190 H170 V230" stroke="#00ff88" strokeWidth="1.5" opacity="0.3"/>
                    <path d="M190 130 H280 V90 H380" stroke="#00d4ff" strokeWidth="1.5" opacity="0.3"/>
                    <rect x="140" y="80" width="120" height="100" fill="#0A2A0A" stroke="#00ff88" strokeWidth="1.5" rx="4"/>
                    <text x="200" y="126" fill="#00ff88" fontSize="8" textAnchor="middle" fontFamily="Share Tech Mono">RASPBERRY</text>
                    <text x="200" y="138" fill="#00ff88" fontSize="8" textAnchor="middle" fontFamily="Share Tech Mono">Pi 5</text>
                    <text x="200" y="150" fill="#00ff88" fontSize="6" textAnchor="middle" opacity="0.6">BCM2712</text>
                    <rect x="20" y="50" width="88" height="58" fill="#0A0A1A" stroke="#00d4ff" strokeWidth="1.5" rx="4"/>
                    <text x="64" y="75" fill="#00d4ff" fontSize="7" textAnchor="middle" fontFamily="Share Tech Mono">ARDUINO</text>
                    <text x="64" y="87" fill="#00d4ff" fontSize="7" textAnchor="middle" fontFamily="Share Tech Mono">MEGA 2560</text>
                    <rect x="295" y="68" width="80" height="50" fill="#1A0A1A" stroke="#7b2ff7" strokeWidth="1.5" rx="4"/>
                    <text x="335" y="90" fill="#b57aff" fontSize="7" textAnchor="middle" fontFamily="Share Tech Mono">ESP32</text>
                    <text x="335" y="102" fill="#b57aff" fontSize="6" textAnchor="middle" fontFamily="Share Tech Mono">WiFi+BT</text>
                    <circle cx="40" cy="150" r="5" fill="#00ff88" opacity="0.9"><animate attributeName="opacity" values="0.9;0.1;0.9" dur="1.4s" repeatCount="indefinite"/></circle>
                    <circle cx="60" cy="150" r="5" fill="#ff6b35" opacity="0.7"><animate attributeName="opacity" values="0.7;0.1;0.7" dur="2s" repeatCount="indefinite"/></circle>
                    <circle cx="80" cy="150" r="5" fill="#00d4ff" opacity="0.8"><animate attributeName="opacity" values="0.8;0.1;0.8" dur="2.5s" repeatCount="indefinite"/></circle>
                    <circle r="3" fill="#00d4ff" opacity="0.9"><animateMotion path="M20,130 H90 V70 H190" dur="2s" repeatCount="indefinite"/></circle>
                    <circle r="3" fill="#00ff88" opacity="0.9"><animateMotion path="M190,130 H280 V90 H380" dur="2.5s" repeatCount="indefinite"/></circle>
                    <circle r="2" fill="#ff6b35" opacity="0.8"><animateMotion path="M20,150 H70 V190 H170 V230" dur="3s" repeatCount="indefinite"/></circle>
                  </svg>
                </div>
              </div>
            </div>
          </div>
          <div className="hero-indicators">
            {SLIDES.map((_, i) => <div key={i} className={`hero-dot ${i === slide ? 'active' : ''}`} onClick={() => setSlide(i)} />)}
          </div>
        </section>

        {/* TICKER */}
        <div className="ticker">
          <div className="ticker-inner">
            {[...TICKERS,...TICKERS].map((item, i) => (
              <span key={i} className="ticker-item"><span className="ticker-dot" />{item}</span>
            ))}
          </div>
        </div>

        {/* CATEGORIES */}
        <section className="sp-section">
          <div className="container">
            <div className="text-center mb-3">
              <div className="section-eyebrow" style={{ justifyContent: 'center' }}>Shop By Category</div>
              <h2 className="section-title">Browse <span className="gradient-text">All Categories</span></h2>
              <p className="section-sub" style={{ margin: '0 auto', maxWidth: 480 }}>From embedded systems to IoT sensors — find every component you need.</p>
            </div>
            {loadingCats ? (
              <div className="cat-grid">{Array.from({length:6}).map((_,i) => <div key={i} className="skeleton" style={{height:160}}/>)}</div>
            ) : categories.length === 0 ? (
              <div className="empty-state"><div className="empty-icon">📂</div><h3>No Categories Yet</h3><p>Admin can add categories from the dashboard.</p></div>
            ) : (
              <div className="cat-grid">
                {categories.map(cat => (
                  <Link key={cat._id} to={`/products?category=${cat._id}`} className="cat-card">
                    <div className="cat-img-wrap">
                      {cat.picture ? <img src={`http://localhost:5000/${cat.picture}`} alt={cat.category} className="cat-img" /> : <span>📦</span>}
                    </div>
                    <span className="cat-name">{cat.category}</span>
                    <span className="cat-hint">View Products →</span>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </section>

        {/* FEATURED PRODUCTS */}
        <section className="sp-section" style={{ paddingTop: '2rem' }}>
          <div className="container">
            <div className="d-flex align-items-end justify-content-between mb-3 flex-wrap gap-3">
              <div>
                <div className="section-eyebrow">Featured</div>
                <h2 className="section-title">Top <span className="gradient-text">Products</span></h2>
              </div>
              <Link to="/products" className="btn-outline" style={{ fontSize: '13px', padding: '10px 22px' }}>View All →</Link>
            </div>
            {loadingProds ? (
              <div className="products-grid">{Array.from({length:4}).map((_,i) => <div key={i} className="skeleton" style={{height:340}}/>)}</div>
            ) : products.length === 0 ? (
              <div className="empty-state"><div className="empty-icon">🛍️</div><h3>No Products Yet</h3><p>Admin can add products from the dashboard.</p></div>
            ) : (
              <div className="products-grid">
                {products.map(p => <ProductCard key={p._id} product={p} />)}
              </div>
            )}
          </div>
        </section>

        {/* FEATURES */}
        <section className="sp-section" style={{ paddingTop: '2rem' }}>
          <div className="container">
            <div className="text-center mb-4">
              <div className="section-eyebrow" style={{ justifyContent: 'center' }}>Why Choose Us</div>
              <h2 className="section-title">The <span className="gradient-text">SoftprInnovation</span> Advantage</h2>
            </div>
            <div className="feat-grid">
              {FEATURES.map((f, i) => (
                <div key={i} className="feat-item">
                  <div className="feat-icon">{f.icon}</div>
                  <div><div className="feat-title">{f.title}</div><div className="feat-desc">{f.desc}</div></div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <div className="container"><div className="cta-banner">
          <h2>⚡ Ready to Start Building?</h2>
          <p>Join thousands of engineers, students, and makers who trust SoftprInnovation.</p>
          <div style={{ display: 'flex', gap: 16, justifyContent: 'center', flexWrap: 'wrap', position: 'relative' }}>
            <Link to="/products" className="btn-glow">Shop Now</Link>
            <Link to="/login?tab=register" className="btn-outline">Create Account</Link>
          </div>
        </div></div>

        {/* TESTIMONIALS */}
        <section className="sp-section">
          <div className="container">
            <div className="text-center mb-4">
              <div className="section-eyebrow" style={{ justifyContent: 'center' }}>Reviews</div>
              <h2 className="section-title">What <span className="gradient-text">Makers Say</span></h2>
            </div>
            <div className="testi-grid">
              {TESTIMONIALS.map((t, i) => (
                <div key={i} className="testi-card">
                  <div className="testi-stars">{t.stars}</div>
                  <p className="testi-text">"{t.text}"</p>
                  <div className="testi-name">{t.name}</div>
                  <div className="testi-role">{t.role}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CONTACT */}
        <section className="sp-section" id="contact">
          <div className="container">
            <div className="row g-5 align-items-center">
              <div className="col-lg-5">
                <div className="section-eyebrow">Get In Touch</div>
                <h2 className="section-title">Contact <span className="gradient-text">Us</span></h2>
                <p style={{ color: 'var(--textdim)', fontSize: 15, lineHeight: 1.75, marginBottom: '2rem' }}>Have a question about a product? Need bulk pricing? We're here to help.</p>
                {[['📧','Email','support@softprinnovation.com'],['📞','Phone','+91 98765 43210'],['📍','Location','Tech Park, Lucknow, UP, India'],['🕐','Hours','Mon–Sat: 9AM – 7PM IST']].map(([icon,label,val],i) => (
                  <div key={i} className="ci-item">
                    <div className="ci-icon">{icon}</div>
                    <div><div className="ci-label">{label}</div><div className="ci-val">{val}</div></div>
                  </div>
                ))}
              </div>
              <div className="col-lg-7">
                <div className="contact-wrap">
                  <div className="row g-3">
                    <div className="col-md-6"><label className="cf-label">Full Name</label><input className="cf-input" placeholder="John Doe" value={contactMsg.name} onChange={e => setContactMsg(p => ({...p,name:e.target.value}))}/></div>
                    <div className="col-md-6"><label className="cf-label">Email</label><input className="cf-input" type="email" placeholder="you@example.com" value={contactMsg.email} onChange={e => setContactMsg(p => ({...p,email:e.target.value}))}/></div>
                    <div className="col-12"><label className="cf-label">Subject</label><input className="cf-input" placeholder="Product inquiry..." value={contactMsg.subject} onChange={e => setContactMsg(p => ({...p,subject:e.target.value}))}/></div>
                    <div className="col-12"><label className="cf-label">Message</label><textarea className="cf-input" placeholder="Describe your requirement..." value={contactMsg.message} onChange={e => setContactMsg(p => ({...p,message:e.target.value}))}/></div>
                    <div className="col-12">
                      <button className="btn-glow" style={{ width: '100%', justifyContent: 'center', border: 'none' }} onClick={() => { alert('Message sent! We reply within 24 hours.'); setContactMsg({name:'',email:'',subject:'',message:''}); }}>Send Message ⚡</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* FOOTER */}
        <footer className="sp-footer">
          <div className="container">
            <div className="row g-4">
              <div className="col-lg-4">
                <div className="footer-brand">Softpr<span>Innovation</span></div>
                <p className="footer-desc">Your one-stop shop for premium electronics — Raspberry Pi, Arduino, ESP32, sensors, modules, and everything in between.</p>
                <div className="social-links">
                  {[['📘','#'],['📸','#'],['🐦','#'],['▶️','#'],['💬','#']].map(([icon,href],i) => <a key={i} href={href} className="social-btn">{icon}</a>)}
                </div>
                <div style={{ marginTop: '1.5rem' }}>
                  <div style={{ fontFamily:'var(--font3)', fontSize:'11px', color:'var(--accent)', letterSpacing:'2px', textTransform:'uppercase', marginBottom:'8px' }}>Newsletter</div>
                  <div className="nl-row"><input className="nl-input" type="email" placeholder="Enter your email..." /><button className="nl-btn">Subscribe</button></div>
                </div>
              </div>
              <div className="col-lg-2 col-6">
                <div className="footer-heading">Navigation</div>
                <ul className="footer-links">
                  {[['Home','/home'],['Products','/products'],['About','/about'],['Contact','/contact']].map(([l,p]) => <li key={l}><Link to={p}>{l}</Link></li>)}
                </ul>
              </div>
              <div className="col-lg-2 col-6">
                <div className="footer-heading">Account</div>
                <ul className="footer-links">
                  {[['Login','/login'],['Register','/login?tab=register'],['Dashboard','/dashboard'],['My Cart','/cart'],['My Orders','/orders']].map(([l,p]) => <li key={l}><Link to={p}>{l}</Link></li>)}
                </ul>
              </div>
              <div className="col-lg-2 col-6">
                <div className="footer-heading">Products</div>
                <ul className="footer-links">
                  {['Raspberry Pi','Arduino','ESP32','Sensors','Modules'].map(l => <li key={l}><Link to="/products">{l}</Link></li>)}
                </ul>
              </div>
              <div className="col-lg-2 col-6">
                <div className="footer-heading">Support</div>
                <ul className="footer-links">
                  {[['Contact','/contact'],['FAQ','#'],['Shipping','#'],['Returns','#'],['Privacy','#']].map(([l,p]) => <li key={l}><Link to={p}>{l}</Link></li>)}
                </ul>
              </div>
            </div>
            <div className="footer-bottom">
              <div className="footer-copy">© 2025 SoftprInnovation. All rights reserved.</div>
              <div className="footer-copy" style={{ display:'flex', gap:14, alignItems:'center' }}>
                <span style={{ color:'var(--accent)' }}>Made in India 🇮🇳</span><span>|</span><span>Powering Makers Everywhere</span>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </>
  )
}
