import React, { useState, useEffect } from 'react'
import { useNavigate, useSearchParams, Link } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import { toast } from 'react-toastify'

const css = `
.auth-page { min-height: 100vh; background: var(--c1); display: flex; align-items: center; justify-content: center; padding: 2rem; position: relative; overflow: hidden; }
.auth-bg { position: absolute; inset: 0; background: radial-gradient(ellipse at 30% 50%, rgba(0,212,255,0.06) 0%, transparent 60%), radial-gradient(ellipse at 70% 50%, rgba(123,47,247,0.06) 0%, transparent 60%); }
.auth-grid { position: absolute; inset: 0; background-image: linear-gradient(rgba(0,212,255,0.03) 1px,transparent 1px),linear-gradient(90deg,rgba(0,212,255,0.03) 1px,transparent 1px); background-size: 50px 50px; }
.auth-wrap { position: relative; z-index: 1; width: 100%; max-width: 960px; display: flex; border-radius: 20px; overflow: hidden; box-shadow: 0 30px 60px rgba(0,0,0,0.5); border: 1px solid var(--border); }
.auth-left { width: 45%; background: linear-gradient(135deg,rgba(0,212,255,0.15),rgba(123,47,247,0.2)); display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center; padding: 3rem 2rem; border-right: 1px solid var(--border); position: relative; overflow: hidden; }
.auth-left::before { content:''; position:absolute; inset:0; background:radial-gradient(ellipse at center, rgba(0,212,255,0.1), transparent 70%); animation: authGlow 4s ease-in-out infinite; }
@keyframes authGlow { 0%,100%{opacity:.5} 50%{opacity:1} }
.auth-left-title { font-family: var(--font1); font-size: clamp(1.5rem,3vw,2.2rem); font-weight: 900; color: var(--white); margin-bottom: 1rem; position: relative; }
.auth-left-sub { color: var(--textdim); font-size: 14px; line-height: 1.7; margin-bottom: 2rem; position: relative; max-width: 280px; }
.auth-circuit { position: relative; z-index: 1; }
.auth-right { flex: 1; background: rgba(10,15,30,0.95); padding: 3rem 2.5rem; display: flex; flex-direction: column; justify-content: center; }
.auth-logo { font-family: var(--font1); font-size: 18px; font-weight: 900; color: var(--white); margin-bottom: 2rem; display: flex; align-items: center; gap: 10px; }
.auth-logo .logo-box { width: 36px; height: 36px; background: linear-gradient(135deg,var(--accent),var(--accent2)); border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 13px; font-weight: 900; color: #fff; }
.auth-logo span { color: var(--accent); }
.auth-tabs { display: flex; gap: 0; margin-bottom: 2rem; border-bottom: 1px solid var(--border); }
.auth-tab { font-family: var(--font2); font-size: 14px; font-weight: 700; color: var(--textdim); background: none; border: none; padding: 10px 20px; cursor: pointer; transition: var(--transition); position: relative; }
.auth-tab.active { color: var(--accent); }
.auth-tab.active::after { content:''; position:absolute; bottom:-1px; left:0; right:0; height:2px; background: linear-gradient(90deg,var(--accent),var(--accent2)); }
.auth-title { font-family: var(--font1); font-size: 1.5rem; font-weight: 800; color: var(--white); margin-bottom: 1.75rem; }
.auth-field { margin-bottom: 1.25rem; }
.auth-label { font-family: var(--font3); font-size: 10px; color: var(--accent); letter-spacing: 2px; text-transform: uppercase; display: block; margin-bottom: 8px; }
.auth-input { width: 100%; background: rgba(0,10,25,0.8); border: 1px solid var(--border); border-radius: 10px; padding: 12px 16px; color: var(--text); font-family: var(--font2); font-size: 14px; outline: none; transition: var(--transition); }
.auth-input:focus { border-color: var(--accent); box-shadow: 0 0 15px rgba(0,212,255,0.12); }
.auth-input-wrap { position: relative; }
.auth-input-wrap .auth-icon { position: absolute; left: 14px; top: 50%; transform: translateY(-50%); color: var(--textdim); font-size: 14px; }
.auth-input-wrap .auth-input { padding-left: 40px; }
.auth-btn { width: 100%; font-family: var(--font2); font-weight: 700; font-size: 15px; color: var(--c1); background: linear-gradient(135deg,var(--accent),var(--accent2)); border: none; padding: 14px; border-radius: 30px; cursor: pointer; transition: var(--transition); box-shadow: 0 0 25px rgba(0,212,255,0.3); margin-top: 0.5rem; letter-spacing: 0.5px; }
.auth-btn:hover { transform: translateY(-2px); box-shadow: 0 0 40px rgba(0,212,255,0.5); }
.auth-btn:disabled { opacity: 0.6; cursor: not-allowed; transform: none; }
.auth-switch { margin-top: 1.5rem; text-align: center; font-size: 13px; color: var(--textdim); }
.auth-switch span { color: var(--accent); cursor: pointer; font-weight: 600; }
.auth-switch span:hover { text-decoration: underline; }
.auth-admin-link { margin-top: 1rem; text-align: center; }
.auth-admin-link a { font-size: 12px; color: var(--textdim); transition: var(--transition); }
.auth-admin-link a:hover { color: var(--accent3); }
.auth-row { display: flex; gap: 16px; }
.auth-row .auth-field { flex: 1; }
.error-msg { color: var(--red); font-size: 12px; margin-top: 4px; font-family: var(--font3); }
@media(max-width:768px) {
  .auth-left { display: none; }
  .auth-wrap { max-width: 480px; }
  .auth-right { padding: 2rem 1.5rem; }
  .auth-row { flex-direction: column; gap: 0; }
}
`

export default function UserLogin() {
  const [searchParams] = useSearchParams()
  const [tab, setTab] = useState(searchParams.get('tab') === 'register' ? 'register' : 'login')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [form, setForm] = useState({ name: '', email: '', password: '', confirmPassword: '', mobile: '' })

  const { loginUser, registerUser, user } = useAuth()
  const navigate = useNavigate()

  useEffect(() => { if (user) navigate('/dashboard') }, [user])
  useEffect(() => { setTab(searchParams.get('tab') === 'register' ? 'register' : 'login') }, [searchParams])

  const handleChange = (e) => {
    setForm(p => ({ ...p, [e.target.name]: e.target.value }))
    setError('')
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    try {
      if (tab === 'login') {
        await loginUser(form.email, form.password)
        toast.success('Welcome back! 🎉')
        navigate('/dashboard')
      } else {
        if (form.password !== form.confirmPassword) {
          setError('Passwords do not match.'); setLoading(false); return
        }
        if (form.password.length < 6) {
          setError('Password must be at least 6 characters.'); setLoading(false); return
        }
        await registerUser(form.name, form.email, form.password, form.mobile)
        toast.success('Account created! Welcome! 🎉')
        navigate('/dashboard')
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Something went wrong.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <>
      <style>{css}</style>
      <div className="auth-page">
        <div className="auth-bg" />
        <div className="auth-grid" />
        <div className="auth-wrap">
          {/* LEFT PANEL */}
          <div className="auth-left">
            <div className="auth-circuit">
              <svg viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ width: 200, height: 200 }}>
                <circle cx="100" cy="100" r="80" stroke="rgba(0,212,255,0.2)" strokeWidth="1"/>
                <circle cx="100" cy="100" r="60" stroke="rgba(0,212,255,0.15)" strokeWidth="1"/>
                <circle cx="100" cy="100" r="40" stroke="rgba(0,212,255,0.1)" strokeWidth="1"/>
                <circle cx="100" cy="100" r="8" fill="var(--accent)" opacity="0.8">
                  <animate attributeName="r" values="8;12;8" dur="2s" repeatCount="indefinite"/>
                </circle>
                {[0,45,90,135,180,225,270,315].map((deg, i) => {
                  const rad = (deg * Math.PI) / 180
                  const x = 100 + 80 * Math.cos(rad)
                  const y = 100 + 80 * Math.sin(rad)
                  return <circle key={i} cx={x} cy={y} r="4" fill={i % 2 === 0 ? 'var(--accent)' : 'var(--accent2)'} opacity="0.7">
                    <animate attributeName="opacity" values="0.7;0.2;0.7" dur={`${1.5 + i * 0.2}s`} repeatCount="indefinite"/>
                  </circle>
                })}
                <text x="100" y="97" fill="var(--accent)" fontSize="10" textAnchor="middle" fontFamily="Share Tech Mono">SECURE</text>
                <text x="100" y="110" fill="var(--accent)" fontSize="10" textAnchor="middle" fontFamily="Share Tech Mono">AUTH</text>
              </svg>
            </div>
            <div className="auth-left-title">{tab === 'login' ? 'Welcome Back!' : 'Join Us Today!'}</div>
            <p className="auth-left-sub">{tab === 'login' ? 'Login to access your orders, wishlist, and exclusive deals on electronics.' : 'Create an account to track orders and get exclusive offers on electronics.'}</p>
            <Link to="/home" className="btn-outline" style={{ fontSize: 13, padding: '8px 20px', position: 'relative' }}>← Back to Home</Link>
          </div>

          {/* RIGHT PANEL */}
          <div className="auth-right">
            <div className="auth-logo">
              <div className="logo-box">SP</div>
              Softpr<span>Innovation</span>
            </div>

            <div className="auth-tabs">
              <button className={`auth-tab ${tab === 'login' ? 'active' : ''}`} onClick={() => setTab('login')}>Login</button>
              <button className={`auth-tab ${tab === 'register' ? 'active' : ''}`} onClick={() => setTab('register')}>Register</button>
            </div>

            <h2 className="auth-title">{tab === 'login' ? 'Sign In' : 'Create Account'}</h2>

            <form onSubmit={handleSubmit}>
              {tab === 'register' && (
                <div className="auth-row">
                  <div className="auth-field">
                    <label className="auth-label">Full Name *</label>
                    <input className="auth-input" name="name" value={form.name} onChange={handleChange} placeholder="John Doe" required />
                  </div>
                  <div className="auth-field">
                    <label className="auth-label">Mobile</label>
                    <input className="auth-input" name="mobile" value={form.mobile} onChange={handleChange} placeholder="+91 9876543210" />
                  </div>
                </div>
              )}

              <div className="auth-field">
                <label className="auth-label">Email Address *</label>
                <input className="auth-input" type="email" name="email" value={form.email} onChange={handleChange} placeholder="you@example.com" required />
              </div>

              <div className={tab === 'register' ? 'auth-row' : ''}>
                <div className="auth-field">
                  <label className="auth-label">Password *</label>
                  <input className="auth-input" type="password" name="password" value={form.password} onChange={handleChange} placeholder={tab === 'register' ? 'Min 6 characters' : '••••••••'} required />
                </div>
                {tab === 'register' && (
                  <div className="auth-field">
                    <label className="auth-label">Confirm Password *</label>
                    <input className="auth-input" type="password" name="confirmPassword" value={form.confirmPassword} onChange={handleChange} placeholder="••••••••" required />
                  </div>
                )}
              </div>

              {error && <div className="error-msg">⚠ {error}</div>}

              <button className="auth-btn" type="submit" disabled={loading}>
                {loading ? 'Please wait...' : tab === 'login' ? 'Sign In →' : 'Create Account →'}
              </button>
            </form>

            <div className="auth-switch">
              {tab === 'login' ? <>New here? <span onClick={() => setTab('register')}>Create Account</span></> : <>Already have an account? <span onClick={() => setTab('login')}>Sign In</span></>}
            </div>
            <div className="auth-admin-link">
              <Link to="/admin">🔐 Admin Login</Link>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
