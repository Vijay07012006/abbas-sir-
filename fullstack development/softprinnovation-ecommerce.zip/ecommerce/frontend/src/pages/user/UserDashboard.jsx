import React, { useState, useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import api from '../../utils/api'
import Navbar from '../../components/Navbar'
import { toast } from 'react-toastify'

const css = `
.dash-page { min-height: 100vh; background: var(--c1); padding-top: 68px; }
.dash-hero { background: linear-gradient(135deg,rgba(0,212,255,0.08),rgba(123,47,247,0.08)); border-bottom: 1px solid var(--border); padding: 3rem 0 2rem; }
.dash-avatar { width: 70px; height: 70px; border-radius: 50%; background: linear-gradient(135deg,var(--accent),var(--accent2)); display: flex; align-items: center; justify-content: center; font-family: var(--font1); font-size: 24px; font-weight: 900; color: #fff; border: 3px solid rgba(0,212,255,0.3); }
.dash-name { font-family: var(--font1); font-size: 1.5rem; font-weight: 800; color: var(--white); margin-bottom: 4px; }
.dash-email { font-family: var(--font3); font-size: 12px; color: var(--textdim); }
.dash-stats { display: grid; grid-template-columns: repeat(auto-fill,minmax(200px,1fr)); gap: 20px; padding: 2rem 0; }
.dash-stat { background: var(--card); border: 1px solid var(--border); border-radius: 16px; padding: 1.75rem; text-align: center; transition: var(--transition); }
.dash-stat:hover { border-color: rgba(0,212,255,0.3); transform: translateY(-4px); }
.ds-icon { font-size: 2.5rem; margin-bottom: 12px; display: block; }
.ds-num { font-family: var(--font1); font-size: 2rem; font-weight: 900; color: var(--accent); display: block; }
.ds-label { font-family: var(--font3); font-size: 11px; color: var(--textdim); letter-spacing: 2px; text-transform: uppercase; }
.dash-content { padding: 2rem 0; }
.dash-section-title { font-family: var(--font1); font-size: 1.1rem; font-weight: 700; color: var(--white); margin-bottom: 1.5rem; display: flex; align-items: center; gap: 10px; }
.order-card { background: var(--card); border: 1px solid var(--border); border-radius: 14px; padding: 1.25rem; margin-bottom: 16px; transition: var(--transition); }
.order-card:hover { border-color: rgba(0,212,255,0.3); }
.order-id { font-family: var(--font3); font-size: 12px; color: var(--accent); }
.order-status { font-family: var(--font3); font-size: 11px; padding: 4px 12px; border-radius: 12px; }
.status-placed { background: rgba(0,212,255,0.15); color: var(--accent); }
.status-shipped { background: rgba(123,47,247,0.15); color: #b57aff; }
.status-delivered { background: rgba(0,255,136,0.15); color: var(--green); }
.status-cancelled { background: rgba(255,71,87,0.15); color: var(--red); }
.profile-form { background: var(--card); border: 1px solid var(--border); border-radius: 16px; padding: 2rem; }
.pf-label { font-family: var(--font3); font-size: 10px; color: var(--accent); letter-spacing: 2px; text-transform: uppercase; display: block; margin-bottom: 8px; }
.pf-input { width: 100%; background: rgba(0,10,25,0.8); border: 1px solid var(--border); border-radius: 10px; padding: 12px 16px; color: var(--text); font-family: var(--font2); font-size: 14px; outline: none; transition: var(--transition); margin-bottom: 1.25rem; }
.pf-input:focus { border-color: var(--accent); box-shadow: 0 0 12px rgba(0,212,255,0.12); }
`

export default function UserDashboard() {
  const { user, logoutUser, cart, cartTotal } = useAuth()
  const [orders, setOrders] = useState([])
  const [loadingOrders, setLoadingOrders] = useState(true)
  const [activeTab, setActiveTab] = useState('overview')
  const [profile, setProfile] = useState({ name: user?.name || '', mobile: '' })
  const navigate = useNavigate()

  useEffect(() => {
    api.get('/api/order/my').then(r => { setOrders(r.data.orders || []); setLoadingOrders(false) }).catch(() => setLoadingOrders(false))
  }, [])

  const handleProfileUpdate = async (e) => {
    e.preventDefault()
    try {
      await api.put('/api/user/profile', profile)
      toast.success('Profile updated!')
    } catch { toast.error('Update failed.') }
  }

  const handleLogout = () => { logoutUser(); navigate('/login') }

  const statusClass = (s) => `order-status status-${s}`

  const tabs = ['overview', 'orders', 'profile']

  return (
    <>
      <style>{css}</style>
      <div className="dash-page">
        <Navbar />
        <div className="dash-hero">
          <div className="container">
            <div className="d-flex align-items-center gap-3 flex-wrap">
              <div className="dash-avatar">{user?.name?.[0]?.toUpperCase() || 'U'}</div>
              <div>
                <div className="dash-name">Welcome, {user?.name}!</div>
                <div className="dash-email">{user?.email}</div>
              </div>
              <button className="btn-danger ms-auto" onClick={handleLogout}>Logout</button>
            </div>
            <div style={{ display: 'flex', gap: '12px', marginTop: '1.5rem', borderBottom: '1px solid var(--border)', paddingBottom: '0' }}>
              {tabs.map(t => (
                <button key={t} onClick={() => setActiveTab(t)} style={{ fontFamily: 'var(--font2)', fontSize: '14px', fontWeight: '600', color: activeTab === t ? 'var(--accent)' : 'var(--textdim)', background: 'none', border: 'none', padding: '10px 16px', cursor: 'pointer', borderBottom: activeTab === t ? '2px solid var(--accent)' : '2px solid transparent', textTransform: 'capitalize', transition: 'var(--transition)' }}>
                  {t}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="dash-content">
          <div className="container">
            {/* OVERVIEW */}
            {activeTab === 'overview' && (
              <>
                <div className="dash-stats">
                  {[
                    ['🛒', String(orders.length), 'Total Orders'],
                    ['✅', String(orders.filter(o => o.orderStatus === 'delivered').length), 'Delivered'],
                    ['🛍️', String(cart.length), 'Cart Items'],
                    ['💰', `₹${cartTotal.toLocaleString('en-IN')}`, 'Cart Value'],
                  ].map(([icon, num, label]) => (
                    <div key={label} className="dash-stat">
                      <span className="ds-icon">{icon}</span>
                      <span className="ds-num">{num}</span>
                      <span className="ds-label">{label}</span>
                    </div>
                  ))}
                </div>
                <div className="dash-section-title">📦 Recent Orders</div>
                {orders.slice(0, 3).map(order => (
                  <div key={order._id} className="order-card">
                    <div className="d-flex justify-content-between align-items-center flex-wrap gap-2">
                      <div>
                        <div className="order-id">#{order._id.slice(-8).toUpperCase()}</div>
                        <div style={{ fontSize: '13px', color: 'var(--textdim)', marginTop: '4px' }}>{order.items?.length} item(s) • ₹{order.totalAmount?.toLocaleString('en-IN')}</div>
                      </div>
                      <span className={statusClass(order.orderStatus)}>{order.orderStatus}</span>
                    </div>
                  </div>
                ))}
                {orders.length === 0 && !loadingOrders && (
                  <div className="empty-state"><div className="empty-icon">📦</div><h3>No Orders Yet</h3><p>Start shopping to see your orders here.</p><Link to="/products" className="btn-glow mt-3">Shop Now</Link></div>
                )}
                <div className="mt-4 d-flex gap-3 flex-wrap">
                  <Link to="/products" className="btn-glow">🛍️ Continue Shopping</Link>
                  <Link to="/cart" className="btn-outline">🛒 View Cart</Link>
                </div>
              </>
            )}

            {/* ORDERS */}
            {activeTab === 'orders' && (
              <>
                <div className="dash-section-title">📦 My Orders</div>
                {loadingOrders ? <div className="spinner" /> : orders.length === 0 ? (
                  <div className="empty-state"><div className="empty-icon">📦</div><h3>No Orders Yet</h3><Link to="/products" className="btn-glow mt-3">Shop Now</Link></div>
                ) : orders.map(order => (
                  <div key={order._id} className="order-card">
                    <div className="d-flex justify-content-between align-items-center flex-wrap gap-2">
                      <div>
                        <div className="order-id">Order #{order._id.slice(-8).toUpperCase()}</div>
                        <div style={{ fontSize: '13px', color: 'var(--textdim)', marginTop: '4px' }}>
                          {new Date(order.createdAt).toLocaleDateString('en-IN')} • {order.items?.length} item(s) • ₹{order.totalAmount?.toLocaleString('en-IN')} • {order.paymentMethod}
                        </div>
                      </div>
                      <span className={statusClass(order.orderStatus)}>{order.orderStatus}</span>
                    </div>
                  </div>
                ))}
              </>
            )}

            {/* PROFILE */}
            {activeTab === 'profile' && (
              <>
                <div className="dash-section-title">👤 My Profile</div>
                <div className="profile-form">
                  <form onSubmit={handleProfileUpdate}>
                    <div className="row g-3">
                      <div className="col-md-6">
                        <label className="pf-label">Full Name</label>
                        <input className="pf-input" value={profile.name} onChange={e => setProfile(p => ({...p,name:e.target.value}))} placeholder="Your name" />
                      </div>
                      <div className="col-md-6">
                        <label className="pf-label">Mobile</label>
                        <input className="pf-input" value={profile.mobile} onChange={e => setProfile(p => ({...p,mobile:e.target.value}))} placeholder="+91 9876543210" />
                      </div>
                      <div className="col-md-6">
                        <label className="pf-label">Email (read-only)</label>
                        <input className="pf-input" value={user?.email || ''} readOnly style={{ opacity: 0.6 }} />
                      </div>
                    </div>
                    <button className="btn-glow mt-3" type="submit">Save Changes</button>
                  </form>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </>
  )
}
