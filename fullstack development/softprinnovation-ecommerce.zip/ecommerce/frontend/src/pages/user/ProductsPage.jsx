import React, { useState, useEffect } from 'react'
import { useSearchParams } from 'react-router-dom'
import Navbar from '../../components/Navbar'
import ProductCard from '../../components/ProductCard'
import api from '../../utils/api'

const css = `
.products-page { min-height: 100vh; background: var(--c1); padding-top: 68px; }
.products-hero { background: linear-gradient(135deg,rgba(0,212,255,0.06),rgba(123,47,247,0.06)); border-bottom: 1px solid var(--border); padding: 3rem 0 2rem; }
.products-hero h1 { font-family: var(--font1); font-size: clamp(1.8rem,4vw,3rem); font-weight: 900; color: var(--white); margin-bottom: 0.5rem; }
.products-hero p { color: var(--textdim); font-size: 15px; }
.search-bar { display: flex; gap: 12px; margin-top: 1.5rem; flex-wrap: wrap; }
.search-input { flex: 1; min-width: 200px; background: rgba(0,10,25,0.8); border: 1px solid var(--border); border-radius: 30px; padding: 12px 20px; color: var(--text); font-family: var(--font2); font-size: 14px; outline: none; transition: var(--transition); }
.search-input:focus { border-color: var(--accent); box-shadow: 0 0 15px rgba(0,212,255,0.15); }
.search-btn { font-family: var(--font2); font-weight: 700; font-size: 13px; color: var(--c1); background: linear-gradient(135deg,var(--accent),var(--accent2)); border: none; padding: 12px 24px; border-radius: 30px; cursor: pointer; transition: var(--transition); }
.search-btn:hover { box-shadow: 0 0 20px rgba(0,212,255,0.4); }
.filters-bar { display: flex; gap: 12px; padding: 1.5rem 0; flex-wrap: wrap; align-items: center; }
.filter-select { background: rgba(0,10,25,0.8); border: 1px solid var(--border); border-radius: 20px; padding: 8px 16px; color: var(--text); font-family: var(--font2); font-size: 13px; outline: none; cursor: pointer; transition: var(--transition); }
.filter-select:focus { border-color: var(--accent); }
.filter-chip { font-family: var(--font3); font-size: 11px; padding: 6px 14px; border-radius: 20px; cursor: pointer; border: 1px solid var(--border); background: transparent; color: var(--textdim); transition: var(--transition); letter-spacing: 1px; }
.filter-chip:hover, .filter-chip.active { border-color: var(--accent); color: var(--accent); background: rgba(0,212,255,0.08); }
.products-grid2 { display: grid; grid-template-columns: repeat(auto-fill,minmax(250px,1fr)); gap: 20px; }
.pagination { display: flex; gap: 8px; justify-content: center; align-items: center; margin-top: 3rem; flex-wrap: wrap; }
.page-btn { width: 40px; height: 40px; border-radius: 50%; border: 1px solid var(--border); background: transparent; color: var(--textdim); font-family: var(--font3); font-size: 13px; cursor: pointer; transition: var(--transition); display: flex; align-items: center; justify-content: center; }
.page-btn:hover, .page-btn.active { border-color: var(--accent); color: var(--accent); background: rgba(0,212,255,0.08); }
.results-info { font-family: var(--font3); font-size: 12px; color: var(--textdim); letter-spacing: 1px; }
`

const TAGS = ['All', 'new', 'hot', 'sale', 'featured']

export default function ProductsPage() {
  const [searchParams, setSearchParams] = useSearchParams()
  const [products, setProducts] = useState([])
  const [categories, setCategories] = useState([])
  const [loading, setLoading] = useState(true)
  const [total, setTotal] = useState(0)
  const [pages, setPages] = useState(1)

  const [search, setSearch] = useState('')
  const [selectedCat, setSelectedCat] = useState(searchParams.get('category') || '')
  const [selectedTag, setSelectedTag] = useState('')
  const [sortBy, setSortBy] = useState('-createdAt')
  const [page, setPage] = useState(1)

  useEffect(() => {
    api.get('/api/category').then(r => setCategories(r.data.categories || []))
  }, [])

  useEffect(() => {
    fetchProducts()
  }, [selectedCat, selectedTag, sortBy, page])

  const fetchProducts = async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams({ page, limit: 12, sort: sortBy })
      if (selectedCat) params.append('category', selectedCat)
      if (selectedTag && selectedTag !== 'All') params.append('tag', selectedTag)
      if (search.trim()) params.append('search', search.trim())
      const r = await api.get(`/api/product?${params}`)
      setProducts(r.data.products || [])
      setTotal(r.data.total || 0)
      setPages(r.data.pages || 1)
    } catch {}
    setLoading(false)
  }

  const handleSearch = (e) => { e.preventDefault(); setPage(1); fetchProducts() }

  return (
    <>
      <style>{css}</style>
      <div className="products-page">
        <Navbar />
        <div className="products-hero">
          <div className="container">
            <h1>All <span className="gradient-text">Products</span></h1>
            <p>Discover {total}+ premium electronics components for your next project.</p>
            <form className="search-bar" onSubmit={handleSearch}>
              <input className="search-input" value={search} onChange={e => setSearch(e.target.value)} placeholder="Search products, brands, components..." />
              <button className="search-btn" type="submit">🔍 Search</button>
            </form>
          </div>
        </div>

        <div className="container py-4">
          <div className="filters-bar">
            <select className="filter-select" value={selectedCat} onChange={e => { setSelectedCat(e.target.value); setPage(1) }}>
              <option value="">All Categories</option>
              {categories.map(c => <option key={c._id} value={c._id}>{c.category}</option>)}
            </select>
            <select className="filter-select" value={sortBy} onChange={e => { setSortBy(e.target.value); setPage(1) }}>
              <option value="-createdAt">Newest First</option>
              <option value="finalPrice">Price: Low to High</option>
              <option value="-finalPrice">Price: High to Low</option>
              <option value="-sold">Best Selling</option>
              <option value="-avgRating">Top Rated</option>
            </select>
            {TAGS.map(tag => (
              <button key={tag} className={`filter-chip ${selectedTag === tag || (tag === 'All' && !selectedTag) ? 'active' : ''}`} onClick={() => { setSelectedTag(tag === 'All' ? '' : tag); setPage(1) }}>{tag}</button>
            ))}
            <span className="results-info ms-auto">{total} products found</span>
          </div>

          {loading ? (
            <div className="products-grid2">{Array.from({length:8}).map((_,i) => <div key={i} className="skeleton" style={{height:340}}/>)}</div>
          ) : products.length === 0 ? (
            <div className="empty-state"><div className="empty-icon">🔍</div><h3>No Products Found</h3><p>Try adjusting your search or filters.</p></div>
          ) : (
            <div className="products-grid2">{products.map(p => <ProductCard key={p._id} product={p}/>)}</div>
          )}

          {pages > 1 && (
            <div className="pagination">
              <button className="page-btn" onClick={() => setPage(p => Math.max(1,p-1))} disabled={page===1}>‹</button>
              {Array.from({length: pages}, (_,i) => (
                <button key={i+1} className={`page-btn ${page === i+1 ? 'active' : ''}`} onClick={() => setPage(i+1)}>{i+1}</button>
              ))}
              <button className="page-btn" onClick={() => setPage(p => Math.min(pages,p+1))} disabled={page===pages}>›</button>
            </div>
          )}
        </div>
      </div>
    </>
  )
}
