import React, { useEffect, useState } from 'react'
import Navbar from '../../components/Navbar'
import api from '../../utils/api'

export function OrdersPage() {
  const [orders, setOrders] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    api.get('/api/order/my').then(r => { setOrders(r.data.orders || []); setLoading(false) }).catch(() => setLoading(false))
  }, [])

  const statusColor = { placed: 'var(--accent)', confirmed: '#b57aff', processing: 'var(--accent3)', shipped: 'var(--accent2)', delivered: 'var(--green)', cancelled: 'var(--red)' }

  return (
    <>
      <div style={{ minHeight: '100vh', background: 'var(--c1)', paddingTop: 68 }}>
        <Navbar />
        <div className="container py-5">
          <h1 style={{ fontFamily: 'var(--font1)', fontSize: '2rem', marginBottom: '2rem' }}>My <span className="gradient-text">Orders</span></h1>
          {loading ? <div className="spinner" /> : orders.length === 0 ? (
            <div className="empty-state"><div className="empty-icon">📦</div><h3>No Orders Yet</h3></div>
          ) : orders.map(order => (
            <div key={order._id} style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 14, padding: '1.5rem', marginBottom: 16 }}>
              <div className="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
                <div>
                  <div style={{ fontFamily: 'var(--font3)', fontSize: 12, color: 'var(--accent)' }}>Order #{order._id.slice(-8).toUpperCase()}</div>
                  <div style={{ fontSize: 12, color: 'var(--textdim)', marginTop: 4 }}>{new Date(order.createdAt).toLocaleDateString('en-IN', { year: 'numeric', month: 'long', day: 'numeric' })} • {order.paymentMethod}</div>
                </div>
                <span style={{ fontFamily: 'var(--font3)', fontSize: 11, padding: '4px 14px', borderRadius: 20, border: `1px solid ${statusColor[order.orderStatus]}`, color: statusColor[order.orderStatus], background: `${statusColor[order.orderStatus]}18`, letterSpacing: '1px', textTransform: 'uppercase' }}>{order.orderStatus}</span>
              </div>
              {order.items?.map((item, i) => (
                <div key={i} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid rgba(255,255,255,0.04)', fontSize: 13 }}>
                  <span style={{ color: 'var(--text)' }}>{item.name} <span style={{ color: 'var(--textdim)' }}>x{item.qty}</span></span>
                  <span style={{ color: 'var(--accent)', fontFamily: 'var(--font1)', fontSize: 13 }}>₹{(item.price * item.qty).toLocaleString('en-IN')}</span>
                </div>
              ))}
              <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 10 }}>
                <span style={{ fontFamily: 'var(--font1)', fontSize: '1rem', color: 'var(--accent)' }}>Total: ₹{order.totalAmount?.toLocaleString('en-IN')}</span>
              </div>
              {order.trackingId && <div style={{ fontFamily: 'var(--font3)', fontSize: 11, color: 'var(--green)', marginTop: 8 }}>Tracking: {order.trackingId}</div>}
            </div>
          ))}
        </div>
      </div>
    </>
  )
}

export default OrdersPage
