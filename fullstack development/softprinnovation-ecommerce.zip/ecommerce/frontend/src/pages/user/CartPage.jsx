import React from 'react'
import { Link, useNavigate } from 'react-router-dom'
import Navbar from '../../components/Navbar'
import { useAuth } from '../../context/AuthContext'
import { IMG_URL } from '../../utils/api'

const css = `
.cart-page { min-height: 100vh; background: var(--c1); padding-top: 68px; }
.cart-item { background: var(--card); border: 1px solid var(--border); border-radius: 14px; padding: 1.25rem; margin-bottom: 14px; display: flex; gap: 1.25rem; align-items: center; transition: var(--transition); }
.cart-item:hover { border-color: rgba(0,212,255,0.25); }
.cart-img { width: 80px; height: 80px; object-fit: contain; border-radius: 10px; background: rgba(0,10,25,0.8); padding: 8px; flex-shrink: 0; }
.cart-img-placeholder { width: 80px; height: 80px; border-radius: 10px; background: rgba(0,10,25,0.8); display: flex; align-items: center; justify-content: center; font-size: 2rem; flex-shrink: 0; }
.cart-name { font-family: var(--font1); font-size: 14px; font-weight: 700; color: var(--white); margin-bottom: 4px; }
.cart-price { font-family: var(--font1); font-size: 16px; color: var(--accent); }
.cart-qty-wrap { display: flex; align-items: center; gap: 10px; margin-top: 8px; }
.cart-qty-btn { width: 32px; height: 32px; border-radius: 50%; border: 1px solid var(--border); background: transparent; color: var(--text); font-size: 16px; cursor: pointer; display: flex; align-items: center; justify-content: center; transition: var(--transition); }
.cart-qty-btn:hover { border-color: var(--accent); color: var(--accent); }
.cart-qty-val { font-family: var(--font1); font-size: 15px; color: var(--white); min-width: 28px; text-align: center; }
.cart-remove { background: none; border: none; color: var(--textdim); font-size: 18px; cursor: pointer; transition: var(--transition); margin-left: auto; flex-shrink: 0; padding: 4px 8px; border-radius: 6px; }
.cart-remove:hover { color: var(--red); background: rgba(255,71,87,0.1); }
.cart-summary { background: var(--card); border: 1px solid var(--border); border-radius: 16px; padding: 2rem; position: sticky; top: 90px; }
.summary-row { display: flex; justify-content: space-between; align-items: center; padding: 10px 0; border-bottom: 1px solid rgba(255,255,255,0.05); font-size: 14px; }
.summary-row:last-child { border-bottom: none; }
.summary-label { color: var(--textdim); }
.summary-val { color: var(--text); font-weight: 600; }
.summary-total { font-family: var(--font1); font-size: 1.3rem; font-weight: 900; color: var(--accent); }
`

export default function CartPage() {
  const { cart, updateCartQty, removeFromCart, clearCart, cartTotal, user } = useAuth()
  const navigate = useNavigate()
  const shipping = cartTotal >= 999 ? 0 : 49

  return (
    <>
      <style>{css}</style>
      <div className="cart-page">
        <Navbar />
        <div className="container py-5">
          <h1 style={{ fontFamily: 'var(--font1)', fontSize: '2rem', marginBottom: '2rem' }}>
            🛒 My <span className="gradient-text">Cart</span>
            {cart.length > 0 && <span style={{ fontFamily: 'var(--font3)', fontSize: '14px', color: 'var(--textdim)', marginLeft: '12px' }}>({cart.length} items)</span>}
          </h1>

          {cart.length === 0 ? (
            <div className="empty-state">
              <div className="empty-icon">🛒</div>
              <h3>Your Cart is Empty</h3>
              <p>Explore our products and add items to cart.</p>
              <Link to="/products" className="btn-glow mt-3">Start Shopping</Link>
            </div>
          ) : (
            <div className="row g-4">
              <div className="col-lg-8">
                <div className="d-flex justify-content-between align-items-center mb-3">
                  <span style={{ fontFamily: 'var(--font3)', fontSize: '12px', color: 'var(--textdim)', letterSpacing: '2px' }}>{cart.length} ITEMS</span>
                  <button className="btn-danger" style={{ fontSize: '12px', padding: '6px 16px' }} onClick={clearCart}>Clear Cart</button>
                </div>
                {cart.map(item => {
                  const price = item.finalPrice || Math.round(item.actualPrice - item.actualPrice * (item.discount || 0) / 100)
                  return (
                    <div key={item._id} className="cart-item">
                      {item.images?.[0] ? (
                        <img src={`${IMG_URL}/${item.images[0]}`} alt={item.name} className="cart-img" />
                      ) : <div className="cart-img-placeholder">📦</div>}
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div className="cart-name">{item.name}</div>
                        {item.category && <div style={{ fontFamily: 'var(--font3)', fontSize: '10px', color: 'var(--accent)', letterSpacing: '2px', marginBottom: '6px' }}>{item.category.category || item.category}</div>}
                        <div className="cart-price">₹{price.toLocaleString('en-IN')}</div>
                        <div className="cart-qty-wrap">
                          <button className="cart-qty-btn" onClick={() => updateCartQty(item._id, item.qty - 1)}>−</button>
                          <span className="cart-qty-val">{item.qty}</span>
                          <button className="cart-qty-btn" onClick={() => updateCartQty(item._id, item.qty + 1)}>+</button>
                          <span style={{ fontFamily: 'var(--font3)', fontSize: '12px', color: 'var(--textdim)', marginLeft: '8px' }}>= ₹{(price * item.qty).toLocaleString('en-IN')}</span>
                        </div>
                      </div>
                      <button className="cart-remove" onClick={() => removeFromCart(item._id)}>✕</button>
                    </div>
                  )
                })}
              </div>

              <div className="col-lg-4">
                <div className="cart-summary">
                  <div style={{ fontFamily: 'var(--font1)', fontSize: '1rem', fontWeight: 700, color: 'var(--white)', marginBottom: '1.25rem' }}>Order Summary</div>
                  <div className="summary-row"><span className="summary-label">Subtotal</span><span className="summary-val">₹{cartTotal.toLocaleString('en-IN')}</span></div>
                  <div className="summary-row"><span className="summary-label">Shipping</span><span className="summary-val" style={{ color: shipping === 0 ? 'var(--green)' : 'var(--text)' }}>{shipping === 0 ? 'FREE' : `₹${shipping}`}</span></div>
                  {shipping > 0 && <div style={{ fontFamily: 'var(--font3)', fontSize: '10px', color: 'var(--textdim)', padding: '6px 0' }}>Add ₹{(999 - cartTotal).toFixed(0)} more for free delivery</div>}
                  <div className="summary-row"><span className="summary-val" style={{ fontFamily: 'var(--font1)' }}>Total</span><span className="summary-total">₹{(cartTotal + shipping).toLocaleString('en-IN')}</span></div>
                  <button className="btn-glow mt-4" style={{ width: '100%', justifyContent: 'center', border: 'none' }}
                    onClick={() => user ? navigate('/checkout') : navigate('/login')}>
                    {user ? 'Proceed to Checkout' : 'Login to Checkout'}
                  </button>
                  <Link to="/products" className="btn-outline mt-3" style={{ width: '100%', justifyContent: 'center', fontSize: '13px' }}>← Continue Shopping</Link>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  )
}
