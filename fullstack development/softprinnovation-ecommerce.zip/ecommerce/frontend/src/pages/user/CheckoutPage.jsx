// CheckoutPage.jsx
import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import Navbar from '../../components/Navbar'
import { useAuth } from '../../context/AuthContext'
import api from '../../utils/api'
import { toast } from 'react-toastify'

const css = `
.checkout-page { min-height: 100vh; background: var(--c1); padding-top: 68px; }
.checkout-form { background: var(--card); border: 1px solid var(--border); border-radius: 16px; padding: 2rem; }
.cf-label { font-family: var(--font3); font-size: 10px; color: var(--accent); letter-spacing: 2px; text-transform: uppercase; display: block; margin-bottom: 8px; }
.cf-input { width: 100%; background: rgba(0,10,25,0.8); border: 1px solid var(--border); border-radius: 10px; padding: 12px 16px; color: var(--text); font-family: var(--font2); font-size: 14px; outline: none; transition: var(--transition); margin-bottom: 1.25rem; }
.cf-input:focus { border-color: var(--accent); box-shadow: 0 0 12px rgba(0,212,255,0.12); }
.pay-option { border: 1.5px solid var(--border); border-radius: 12px; padding: 1rem 1.25rem; cursor: pointer; transition: var(--transition); display: flex; align-items: center; gap: 12px; margin-bottom: 10px; }
.pay-option:hover, .pay-option.selected { border-color: var(--accent); background: rgba(0,212,255,0.05); }
.pay-radio { width: 18px; height: 18px; accent-color: var(--accent); }
.pay-label { font-family: var(--font2); font-size: 14px; font-weight: 600; color: var(--text); }
.order-summary-card { background: var(--card); border: 1px solid var(--border); border-radius: 16px; padding: 1.75rem; position: sticky; top: 90px; }
.oi-row { display: flex; gap: 12px; align-items: center; padding: 10px 0; border-bottom: 1px solid rgba(255,255,255,0.05); }
.oi-name { font-size: 13px; color: var(--text); flex: 1; }
.oi-qty { font-family: var(--font3); font-size: 11px; color: var(--textdim); }
.oi-price { font-family: var(--font1); font-size: 13px; color: var(--accent); }
`

export function CheckoutPage() {
  const { cart, cartTotal, clearCart, user } = useAuth()
  const navigate = useNavigate()
  const [loading, setLoading] = useState(false)
  const [payMethod, setPayMethod] = useState('COD')
  const [addr, setAddr] = useState({ name: user?.name || '', mobile: '', street: '', city: '', state: '', pincode: '' })

  const shipping = cartTotal >= 999 ? 0 : 49

  const handleOrder = async (e) => {
    e.preventDefault()
    if (cart.length === 0) { toast.error('Cart is empty.'); return }
    setLoading(true)
    try {
      await api.post('/api/order', {
        items: cart.map(x => ({ product: x._id, qty: x.qty })),
        shippingAddress: addr,
        paymentMethod: payMethod
      })
      clearCart()
      toast.success('Order placed successfully! 🎉')
      navigate('/orders')
    } catch (err) {
      toast.error(err.response?.data?.message || 'Order failed.')
    }
    setLoading(false)
  }

  return (
    <>
      <style>{css}</style>
      <div className="checkout-page">
        <Navbar />
        <div className="container py-5">
          <h1 style={{ fontFamily: 'var(--font1)', fontSize: '2rem', marginBottom: '2rem' }}>Checkout</h1>
          <div className="row g-4">
            <div className="col-lg-7">
              <form onSubmit={handleOrder}>
                <div className="checkout-form mb-4">
                  <h5 style={{ fontFamily: 'var(--font1)', color: 'var(--accent)', fontSize: '14px', letterSpacing: '2px', marginBottom: '1.5rem' }}>SHIPPING ADDRESS</h5>
                  <div className="row g-3">
                    <div className="col-md-6"><label className="cf-label">Full Name *</label><input className="cf-input" value={addr.name} onChange={e => setAddr(p => ({...p,name:e.target.value}))} required /></div>
                    <div className="col-md-6"><label className="cf-label">Mobile *</label><input className="cf-input" value={addr.mobile} onChange={e => setAddr(p => ({...p,mobile:e.target.value}))} required /></div>
                    <div className="col-12"><label className="cf-label">Street Address *</label><input className="cf-input" value={addr.street} onChange={e => setAddr(p => ({...p,street:e.target.value}))} required /></div>
                    <div className="col-md-4"><label className="cf-label">City *</label><input className="cf-input" value={addr.city} onChange={e => setAddr(p => ({...p,city:e.target.value}))} required /></div>
                    <div className="col-md-4"><label className="cf-label">State *</label><input className="cf-input" value={addr.state} onChange={e => setAddr(p => ({...p,state:e.target.value}))} required /></div>
                    <div className="col-md-4"><label className="cf-label">Pincode *</label><input className="cf-input" value={addr.pincode} onChange={e => setAddr(p => ({...p,pincode:e.target.value}))} required /></div>
                  </div>
                </div>
                <div className="checkout-form mb-4">
                  <h5 style={{ fontFamily: 'var(--font1)', color: 'var(--accent)', fontSize: '14px', letterSpacing: '2px', marginBottom: '1.5rem' }}>PAYMENT METHOD</h5>
                  <div className={`pay-option ${payMethod === 'COD' ? 'selected' : ''}`} onClick={() => setPayMethod('COD')}>
                    <input type="radio" className="pay-radio" checked={payMethod === 'COD'} readOnly /><span className="pay-label">💵 Cash on Delivery</span>
                  </div>
                  <div className={`pay-option ${payMethod === 'Online' ? 'selected' : ''}`} onClick={() => setPayMethod('Online')}>
                    <input type="radio" className="pay-radio" checked={payMethod === 'Online'} readOnly /><span className="pay-label">💳 Online Payment (Coming Soon)</span>
                  </div>
                </div>
                <button className="btn-glow" type="submit" disabled={loading} style={{ border: 'none' }}>
                  {loading ? 'Placing Order...' : `Place Order ₹${(cartTotal + shipping).toLocaleString('en-IN')}`}
                </button>
              </form>
            </div>
            <div className="col-lg-5">
              <div className="order-summary-card">
                <div style={{ fontFamily: 'var(--font1)', fontSize: '14px', color: 'var(--white)', marginBottom: '1.25rem', letterSpacing: '2px' }}>ORDER SUMMARY</div>
                {cart.map(item => {
                  const price = item.finalPrice || Math.round(item.actualPrice - item.actualPrice * (item.discount || 0) / 100)
                  return (
                    <div key={item._id} className="oi-row">
                      <div className="oi-name">{item.name} <span className="oi-qty">x{item.qty}</span></div>
                      <div className="oi-price">₹{(price * item.qty).toLocaleString('en-IN')}</div>
                    </div>
                  )
                })}
                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '12px 0 6px', fontSize: '14px', color: 'var(--textdim)' }}><span>Shipping</span><span style={{ color: shipping === 0 ? 'var(--green)' : 'var(--text)' }}>{shipping === 0 ? 'FREE' : `₹${shipping}`}</span></div>
                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 0', borderTop: '1px solid var(--border)', fontFamily: 'var(--font1)', fontSize: '1.1rem', color: 'var(--accent)' }}><span>Total</span><span>₹{(cartTotal + shipping).toLocaleString('en-IN')}</span></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

export default CheckoutPage
