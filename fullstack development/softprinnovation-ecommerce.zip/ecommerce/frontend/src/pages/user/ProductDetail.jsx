import React, { useState, useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'
import Navbar from '../../components/Navbar'
import { useAuth } from '../../context/AuthContext'
import api, { IMG_URL } from '../../utils/api'
import { toast } from 'react-toastify'

const css = `
.pd-page { min-height: 100vh; background: var(--c1); padding-top: 68px; }
.pd-img-wrap { background: linear-gradient(135deg,rgba(13,27,42,1),rgba(17,34,64,1)); border: 1px solid var(--border); border-radius: 16px; padding: 2rem; display: flex; align-items: center; justify-content: center; min-height: 350px; position: relative; overflow: hidden; }
.pd-img { max-width: 80%; max-height: 300px; object-fit: contain; filter: drop-shadow(0 8px 30px rgba(0,212,255,0.2)); transition: var(--transition); }
.pd-img:hover { transform: scale(1.05); }
.pd-badge-wrap { position: absolute; top: 16px; right: 16px; display: flex; flex-direction: column; gap: 8px; }
.pd-brand { font-family: var(--font3); font-size: 11px; color: var(--accent2); letter-spacing: 3px; text-transform: uppercase; margin-bottom: 8px; }
.pd-name { font-family: var(--font1); font-size: clamp(1.4rem,3vw,2rem); font-weight: 900; color: var(--white); line-height: 1.2; margin-bottom: 12px; }
.pd-price { font-family: var(--font1); font-size: 2.2rem; font-weight: 900; color: var(--accent); text-shadow: 0 0 20px rgba(0,212,255,0.3); }
.pd-old-price { font-size: 1rem; color: var(--textdim); text-decoration: line-through; margin-left: 10px; }
.pd-discount { font-family: var(--font3); font-size: 12px; color: var(--accent3); margin-left: 10px; }
.pd-meta-row { display: flex; gap: 12px; flex-wrap: wrap; margin: 1rem 0; }
.pd-meta-chip { font-family: var(--font3); font-size: 11px; padding: 6px 14px; border-radius: 20px; letter-spacing: 1px; border: 1px solid; }
.pd-free { color: var(--green); border-color: rgba(0,255,136,0.3); background: rgba(0,255,136,0.08); }
.pd-cod { color: #b57aff; border-color: rgba(123,47,247,0.3); background: rgba(123,47,247,0.08); }
.pd-stock-in { color: var(--green); border-color: rgba(0,255,136,0.3); background: rgba(0,255,136,0.08); }
.pd-stock-out { color: var(--red); border-color: rgba(255,71,87,0.3); background: rgba(255,71,87,0.08); }
.pd-qty-wrap { display: flex; align-items: center; gap: 12px; margin: 1.5rem 0; }
.pd-qty-btn { width: 38px; height: 38px; border-radius: 50%; border: 1px solid var(--border); background: transparent; color: var(--text); font-size: 18px; cursor: pointer; transition: var(--transition); display: flex; align-items: center; justify-content: center; }
.pd-qty-btn:hover { border-color: var(--accent); color: var(--accent); }
.pd-qty-val { font-family: var(--font1); font-size: 18px; font-weight: 700; color: var(--white); min-width: 32px; text-align: center; }
.pd-actions { display: flex; gap: 12px; flex-wrap: wrap; }
.pd-desc { font-size: 14px; color: var(--textdim); line-height: 1.75; }
.pd-tabs { display: flex; gap: 0; border-bottom: 1px solid var(--border); margin-bottom: 1.5rem; }
.pd-tab { font-family: var(--font2); font-size: 14px; font-weight: 600; color: var(--textdim); background: none; border: none; padding: 10px 20px; cursor: pointer; transition: var(--transition); position: relative; }
.pd-tab.active { color: var(--accent); }
.pd-tab.active::after { content:''; position:absolute; bottom:-1px; left:0; right:0; height:2px; background: var(--accent); }
.pd-attr-row { display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid rgba(255,255,255,0.05); font-size: 14px; }
.pd-attr-key { color: var(--textdim); font-family: var(--font3); font-size: 12px; letter-spacing: 1px; }
.pd-attr-val { color: var(--text); font-weight: 600; }
.policy-grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 12px; margin-top: 1rem; }
.policy-item { background: var(--card); border: 1px solid var(--border); border-radius: 12px; padding: 1rem; text-align: center; }
.policy-icon { font-size: 1.5rem; margin-bottom: 8px; display: block; }
.policy-title { font-family: var(--font1); font-size: 11px; color: var(--accent); margin-bottom: 4px; }
.policy-val { font-size: 12px; color: var(--textdim); }
@media(max-width:576px) { .policy-grid { grid-template-columns: 1fr; } }
`

export default function ProductDetail() {
  const { id } = useParams()
  const { addToCart, user } = useAuth()
  const [product, setProduct] = useState(null)
  const [loading, setLoading] = useState(true)
  const [qty, setQty] = useState(1)
  const [tab, setTab] = useState('description')

  useEffect(() => {
    api.get(`/api/product/${id}`).then(r => { setProduct(r.data.product); setLoading(false) }).catch(() => setLoading(false))
  }, [id])

  if (loading) return (<><Navbar /><div className="pd-page"><div className="container py-5"><div className="spinner"/></div></div></>)
  if (!product) return (<><Navbar /><div className="pd-page"><div className="container py-5"><div className="empty-state"><div className="empty-icon">❌</div><h3>Product Not Found</h3><Link to="/products" className="btn-glow mt-3">Back to Products</Link></div></div></div></>)

  const finalPrice = product.finalPrice || Math.round(product.actualPrice - product.actualPrice * product.discount / 100)
  const isOOS = product.stockStatus === 'outOfStock'

  const handleCart = () => {
    if (!user) { window.location.href = '/login'; return }
    for (let i = 0; i < qty; i++) addToCart(product)
    toast.success(`${product.name} (x${qty}) added to cart! 🛒`)
  }

  return (
    <>
      <style>{css}</style>
      <div className="pd-page">
        <Navbar />
        <div className="container py-5">
          {/* Breadcrumb */}
          <div style={{ fontFamily: 'var(--font3)', fontSize: '12px', color: 'var(--textdim)', marginBottom: '2rem' }}>
            <Link to="/home" style={{ color: 'var(--textdim)' }}>Home</Link> › <Link to="/products" style={{ color: 'var(--textdim)' }}>Products</Link> › <span style={{ color: 'var(--accent)' }}>{product.name}</span>
          </div>

          <div className="row g-5">
            {/* IMAGE */}
            <div className="col-lg-5">
              <div className="pd-img-wrap">
                <div className="pd-badge-wrap">
                  {product.discount > 0 && <span className="prod-discount">-{product.discount}%</span>}
                  {product.tag && <span className={`prod-tag badge-${product.tag}`}>{product.tag}</span>}
                </div>
                {product.images?.[0] ? (
                  <img src={`${IMG_URL}/${product.images[0]}`} alt={product.name} className="pd-img" />
                ) : <span style={{ fontSize: '6rem', opacity: 0.3 }}>📦</span>}
              </div>
            </div>

            {/* DETAILS */}
            <div className="col-lg-7">
              <div className="pd-brand">{product.brandName}</div>
              <h1 className="pd-name">{product.name}</h1>

              {product.category && (
                <div style={{ fontFamily: 'var(--font3)', fontSize: '11px', color: 'var(--accent)', letterSpacing: '2px', marginBottom: '1rem' }}>
                  {product.category.category}
                </div>
              )}

              <div style={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', marginBottom: '1rem' }}>
                <span className="pd-price">₹{finalPrice.toLocaleString('en-IN')}</span>
                {product.discount > 0 && <>
                  <span className="pd-old-price">₹{Number(product.actualPrice).toLocaleString('en-IN')}</span>
                  <span className="pd-discount">You save ₹{(product.actualPrice - finalPrice).toLocaleString('en-IN')}</span>
                </>}
              </div>

              <div className="pd-meta-row">
                <span className={`pd-meta-chip ${isOOS ? 'pd-stock-out' : 'pd-stock-in'}`}>
                  {isOOS ? '❌ Out of Stock' : `✅ In Stock (${product.stock})`}
                </span>
                {product.freeDelivery && <span className="pd-meta-chip pd-free">✈ Free Delivery</span>}
                {product.isCod && <span className="pd-meta-chip pd-cod">💵 COD Available</span>}
              </div>

              {!isOOS && (
                <div className="pd-qty-wrap">
                  <span style={{ fontFamily: 'var(--font3)', fontSize: '11px', color: 'var(--textdim)', letterSpacing: '2px' }}>QTY</span>
                  <button className="pd-qty-btn" onClick={() => setQty(q => Math.max(1, q - 1))}>−</button>
                  <span className="pd-qty-val">{qty}</span>
                  <button className="pd-qty-btn" onClick={() => setQty(q => Math.min(product.stock, q + 1))}>+</button>
                </div>
              )}

              <div className="pd-actions">
                <button className="btn-glow" onClick={handleCart} disabled={isOOS} style={{ opacity: isOOS ? 0.5 : 1 }}>
                  🛒 {isOOS ? 'Out of Stock' : 'Add to Cart'}
                </button>
                <Link to="/cart" className="btn-outline">View Cart</Link>
              </div>

              {/* POLICY */}
              <div className="policy-grid mt-4">
                {[['🔁', 'Return', product.returnPolicy || '7 days'], ['🔄', 'Replacement', product.replacementPolicy || '7 days'], ['💸', 'Refund', product.refundPolicy || '7 days']].map(([icon, title, val]) => (
                  <div key={title} className="policy-item">
                    <span className="policy-icon">{icon}</span>
                    <div className="policy-title">{title}</div>
                    <div className="policy-val">{val}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* TABS */}
          <div className="mt-5">
            <div className="pd-tabs">
              {['description', 'specifications', 'reviews'].map(t => (
                <button key={t} className={`pd-tab ${tab === t ? 'active' : ''}`} onClick={() => setTab(t)} style={{ textTransform: 'capitalize' }}>{t}</button>
              ))}
            </div>

            {tab === 'description' && <p className="pd-desc">{product.description}</p>}

            {tab === 'specifications' && (
              <div>
                {Object.keys(product.attributes || {}).length > 0 ? (
                  Object.entries(product.attributes).map(([k, v]) => (
                    <div key={k} className="pd-attr-row">
                      <span className="pd-attr-key">{k}</span>
                      <span className="pd-attr-val">{v}</span>
                    </div>
                  ))
                ) : (
                  <>
                    {product.height && <div className="pd-attr-row"><span className="pd-attr-key">Height</span><span className="pd-attr-val">{product.height}</span></div>}
                    {product.width && <div className="pd-attr-row"><span className="pd-attr-key">Width</span><span className="pd-attr-val">{product.width}</span></div>}
                    {product.weight && <div className="pd-attr-row"><span className="pd-attr-key">Weight</span><span className="pd-attr-val">{product.weight}</span></div>}
                    <div className="pd-attr-row"><span className="pd-attr-key">Brand</span><span className="pd-attr-val">{product.brandName}</span></div>
                    <div className="pd-attr-row"><span className="pd-attr-key">Stock</span><span className="pd-attr-val">{product.stock} units</span></div>
                  </>
                )}
              </div>
            )}

            {tab === 'reviews' && (
              <div>
                {product.reviews?.length > 0 ? product.reviews.map((r, i) => (
                  <div key={i} style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 12, padding: '1.25rem', marginBottom: 12 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                      <span style={{ fontFamily: 'var(--font1)', fontSize: 13, color: 'var(--white)' }}>{r.name || 'Anonymous'}</span>
                      <span style={{ color: 'var(--green)', letterSpacing: 2 }}>{'★'.repeat(r.rating)}{'☆'.repeat(5-r.rating)}</span>
                    </div>
                    <p style={{ fontSize: 14, color: 'var(--textdim)' }}>{r.comment}</p>
                  </div>
                )) : (
                  <div className="empty-state"><div className="empty-icon">💬</div><h3>No Reviews Yet</h3><p>Be the first to review this product.</p></div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  )
}
