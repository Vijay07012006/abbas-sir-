import React from 'react'
import Navbar from '../../components/Navbar'
import { Link } from 'react-router-dom'

const css = `
.about-page { min-height: 100vh; background: var(--c1); padding-top: 68px; }
.about-hero { background: linear-gradient(135deg,rgba(0,212,255,0.07),rgba(123,47,247,0.07)); border-bottom: 1px solid var(--border); padding: 5rem 0 4rem; text-align: center; }
.about-hero h1 { font-family: var(--font1); font-size: clamp(2rem,5vw,3.5rem); font-weight: 900; color: var(--white); margin-bottom: 1rem; }
.about-hero p { color: var(--textdim); font-size: 16px; max-width: 600px; margin: 0 auto; line-height: 1.8; }
.about-grid { display: grid; grid-template-columns: repeat(auto-fill,minmax(260px,1fr)); gap: 20px; margin-top: 3rem; }
.about-card { background: var(--card); border: 1px solid var(--border); border-radius: 16px; padding: 2rem; text-align: center; transition: var(--transition); }
.about-card:hover { transform: translateY(-6px); border-color: rgba(0,212,255,0.35); }
.about-icon { font-size: 3rem; margin-bottom: 1rem; display: block; }
.about-card h3 { font-family: var(--font1); font-size: 14px; color: var(--accent); margin-bottom: 10px; }
.about-card p { font-size: 14px; color: var(--textdim); line-height: 1.6; }
.team-grid { display: grid; grid-template-columns: repeat(auto-fill,minmax(200px,1fr)); gap: 20px; margin-top: 2rem; }
.team-card { background: var(--card); border: 1px solid var(--border); border-radius: 16px; padding: 2rem 1.5rem; text-align: center; transition: var(--transition); }
.team-card:hover { border-color: rgba(0,212,255,0.3); transform: translateY(-4px); }
.team-avatar { width: 70px; height: 70px; border-radius: 50%; background: linear-gradient(135deg,var(--accent),var(--accent2)); display: flex; align-items: center; justify-content: center; font-family: var(--font1); font-size: 22px; font-weight: 900; color: #fff; margin: 0 auto 14px; }
.team-name { font-family: var(--font1); font-size: 13px; color: var(--white); margin-bottom: 4px; }
.team-role { font-family: var(--font3); font-size: 11px; color: var(--textdim); letter-spacing: 2px; }
`

export function AboutPage() {
  return (
    <>
      <style>{css}</style>
      <div className="about-page">
        <Navbar />
        <div className="about-hero">
          <div className="container">
            <div className="section-eyebrow" style={{ justifyContent: 'center' }}>About Us</div>
            <h1>India's Premier <span className="gradient-text">Electronics Hub</span></h1>
            <p>SoftprInnovation is dedicated to empowering makers, engineers, and students with premium electronics components at unbeatable prices.</p>
          </div>
        </div>
        <div className="container py-5">
          <div className="about-grid">
            {[['🎯','Our Mission','To make advanced electronics accessible to every innovator, maker, and student across India.'],['👁','Our Vision','A future where every idea becomes reality with the right components and support.'],['💎','Our Values','Quality, authenticity, fast delivery, and exceptional customer support in every transaction.'],['🚀','Our Story','Founded in 2020, SoftprInnovation grew from a small lab to India\'s trusted electronics supplier.']].map(([icon,title,desc]) => (
              <div key={title} className="about-card">
                <span className="about-icon">{icon}</span>
                <h3>{title}</h3>
                <p>{desc}</p>
              </div>
            ))}
          </div>
          <div style={{ textAlign: 'center', marginTop: '4rem' }}>
            <div className="section-eyebrow" style={{ justifyContent: 'center' }}>Our Team</div>
            <h2 className="section-title">The People <span className="gradient-text">Behind the Magic</span></h2>
            <div className="team-grid">
              {[['RS','Rahul Singh','Founder & CEO'],['PK','Priya Kumar','Head of Products'],['AM','Amit Mehta','Tech Lead'],['SG','Sneha Gupta','Customer Success']].map(([init,name,role]) => (
                <div key={name} className="team-card">
                  <div className="team-avatar">{init}</div>
                  <div className="team-name">{name}</div>
                  <div className="team-role">{role}</div>
                </div>
              ))}
            </div>
          </div>
          <div style={{ textAlign: 'center', marginTop: '4rem' }}>
            <Link to="/products" className="btn-glow">🛍️ Shop Now</Link>
          </div>
        </div>
      </div>
    </>
  )
}

export function ContactPage() {
  const [form, setForm] = React.useState({ name: '', email: '', subject: '', message: '' })
  return (
    <>
      <div style={{ minHeight: '100vh', background: 'var(--c1)', paddingTop: 68 }}>
        <Navbar />
        <div className="container py-5">
          <div className="section-eyebrow">Contact</div>
          <h1 className="section-title">Get In <span className="gradient-text">Touch</span></h1>
          <div className="row g-5 mt-2">
            <div className="col-lg-5">
              {[['📧','Email','support@softprinnovation.com'],['📞','Phone','+91 98765 43210'],['📍','Address','Tech Park, Lucknow, UP, India'],['🕐','Hours','Mon–Sat: 9AM – 7PM IST'],['💬','WhatsApp','+91 98765 43210']].map(([icon,label,val]) => (
                <div key={label} style={{ display: 'flex', gap: 16, alignItems: 'center', marginBottom: 20 }}>
                  <div style={{ width: 46, height: 46, border: '1px solid var(--border)', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.3rem', background: 'rgba(0,212,255,0.05)', flexShrink: 0 }}>{icon}</div>
                  <div><div style={{ fontFamily: 'var(--font3)', fontSize: 10, color: 'var(--accent)', letterSpacing: '2px', textTransform: 'uppercase' }}>{label}</div><div style={{ fontSize: 14, color: 'var(--text)', marginTop: 2 }}>{val}</div></div>
                </div>
              ))}
            </div>
            <div className="col-lg-7">
              <div style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 20, padding: '2.5rem' }}>
                <div className="row g-3">
                  <div className="col-md-6"><label style={{ fontFamily: 'var(--font3)', fontSize: 10, color: 'var(--accent)', letterSpacing: '2px', textTransform: 'uppercase', display: 'block', marginBottom: 8 }}>Full Name</label><input style={{ width: '100%', background: 'rgba(0,10,25,0.8)', border: '1px solid var(--border)', borderRadius: 10, padding: '12px 16px', color: 'var(--text)', fontFamily: 'var(--font2)', fontSize: 14, outline: 'none', marginBottom: '1.25rem' }} value={form.name} onChange={e => setForm(p => ({...p,name:e.target.value}))} placeholder="John Doe" /></div>
                  <div className="col-md-6"><label style={{ fontFamily: 'var(--font3)', fontSize: 10, color: 'var(--accent)', letterSpacing: '2px', textTransform: 'uppercase', display: 'block', marginBottom: 8 }}>Email</label><input type="email" style={{ width: '100%', background: 'rgba(0,10,25,0.8)', border: '1px solid var(--border)', borderRadius: 10, padding: '12px 16px', color: 'var(--text)', fontFamily: 'var(--font2)', fontSize: 14, outline: 'none', marginBottom: '1.25rem' }} value={form.email} onChange={e => setForm(p => ({...p,email:e.target.value}))} placeholder="you@example.com" /></div>
                  <div className="col-12"><label style={{ fontFamily: 'var(--font3)', fontSize: 10, color: 'var(--accent)', letterSpacing: '2px', textTransform: 'uppercase', display: 'block', marginBottom: 8 }}>Subject</label><input style={{ width: '100%', background: 'rgba(0,10,25,0.8)', border: '1px solid var(--border)', borderRadius: 10, padding: '12px 16px', color: 'var(--text)', fontFamily: 'var(--font2)', fontSize: 14, outline: 'none', marginBottom: '1.25rem' }} value={form.subject} onChange={e => setForm(p => ({...p,subject:e.target.value}))} placeholder="Product inquiry..." /></div>
                  <div className="col-12"><label style={{ fontFamily: 'var(--font3)', fontSize: 10, color: 'var(--accent)', letterSpacing: '2px', textTransform: 'uppercase', display: 'block', marginBottom: 8 }}>Message</label><textarea style={{ width: '100%', background: 'rgba(0,10,25,0.8)', border: '1px solid var(--border)', borderRadius: 10, padding: '12px 16px', color: 'var(--text)', fontFamily: 'var(--font2)', fontSize: 14, outline: 'none', resize: 'vertical', minHeight: 120, marginBottom: '1.25rem' }} value={form.message} onChange={e => setForm(p => ({...p,message:e.target.value}))} placeholder="Describe your requirement..." /></div>
                  <div className="col-12"><button className="btn-glow" style={{ width: '100%', justifyContent: 'center', border: 'none' }} onClick={() => { alert('Message sent!'); setForm({name:'',email:'',subject:'',message:''}); }}>Send Message ⚡</button></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

export default AboutPage
