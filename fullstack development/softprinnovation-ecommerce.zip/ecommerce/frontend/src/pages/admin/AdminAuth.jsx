import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import { toast } from 'react-toastify'

const css = `
.admin-auth { min-height: 100vh; background: var(--c1); display: flex; align-items: center; justify-content: center; padding: 2rem; position: relative; overflow: hidden; }
.admin-auth-bg { position: absolute; inset: 0; background: radial-gradient(ellipse at 30% 50%, rgba(123,47,247,0.1) 0%, transparent 60%), radial-gradient(ellipse at 70% 50%, rgba(255,107,53,0.06) 0%, transparent 60%); }
.admin-auth-grid { position: absolute; inset: 0; background-image: linear-gradient(rgba(123,47,247,0.03) 1px,transparent 1px),linear-gradient(90deg,rgba(123,47,247,0.03) 1px,transparent 1px); background-size: 50px 50px; }
.admin-auth-card { position: relative; z-index: 1; width: 100%; max-width: 480px; background: rgba(10,15,30,0.95); border: 1px solid rgba(123,47,247,0.3); border-radius: 20px; padding: 3rem; box-shadow: 0 30px 60px rgba(0,0,0,0.5); }
.admin-auth-icon { width: 70px; height: 70px; border-radius: 16px; background: linear-gradient(135deg,var(--accent2),var(--accent3)); display: flex; align-items: center; justify-content: center; font-size: 2rem; margin: 0 auto 1.5rem; box-shadow: 0 0 30px rgba(123,47,247,0.4); }
.admin-auth-title { font-family: var(--font1); font-size: 1.6rem; font-weight: 900; color: var(--white); text-align: center; margin-bottom: 0.5rem; }
.admin-auth-sub { font-family: var(--font3); font-size: 11px; color: var(--textdim); text-align: center; letter-spacing: 2px; margin-bottom: 2rem; text-transform: uppercase; }
.aa-label { font-family: var(--font3); font-size: 10px; color: var(--accent2); letter-spacing: 2px; text-transform: uppercase; display: block; margin-bottom: 8px; }
.aa-input { width: 100%; background: rgba(0,10,25,0.8); border: 1px solid rgba(123,47,247,0.25); border-radius: 10px; padding: 12px 16px; color: var(--text); font-family: var(--font2); font-size: 14px; outline: none; transition: var(--transition); margin-bottom: 1.25rem; }
.aa-input:focus { border-color: var(--accent2); box-shadow: 0 0 15px rgba(123,47,247,0.15); }
.aa-btn { width: 100%; font-family: var(--font2); font-weight: 700; font-size: 15px; color: #fff; background: linear-gradient(135deg,var(--accent2),var(--accent3)); border: none; padding: 14px; border-radius: 30px; cursor: pointer; transition: var(--transition); box-shadow: 0 0 25px rgba(123,47,247,0.3); letter-spacing: 0.5px; margin-top: 0.5rem; }
.aa-btn:hover { transform: translateY(-2px); box-shadow: 0 0 40px rgba(123,47,247,0.5); }
.aa-btn:disabled { opacity: 0.6; cursor: not-allowed; transform: none; }
.aa-toggle { margin-top: 1.5rem; text-align: center; font-size: 13px; color: var(--textdim); }
.aa-toggle span { color: var(--accent2); cursor: pointer; font-weight: 600; }
.aa-back { margin-top: 1rem; text-align: center; }
.aa-back a { font-size: 12px; color: var(--textdim); text-decoration: none; transition: var(--transition); }
.aa-back a:hover { color: var(--accent); }
.aa-error { color: var(--red); font-size: 12px; margin-bottom: 1rem; font-family: var(--font3); text-align: center; }
`

export default function AdminAuth() {
  const [isRegister, setIsRegister] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [form, setForm] = useState({ name: '', email: '', password: '', confirmPassword: '' })

  const { loginAdmin, admin } = useAuth()
  const navigate = useNavigate()

  useEffect(() => { if (admin) navigate('/admin/home') }, [admin])

  const handleChange = (e) => { setForm(p => ({...p,[e.target.name]:e.target.value})); setError('') }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError(''); setLoading(true)
    try {
      if (isRegister) {
        if (form.password !== form.confirmPassword) { setError('Passwords do not match.'); setLoading(false); return }
        const { default: api } = await import('../../utils/api')
        await api.post('/api/admin/register', { name: form.name, email: form.email, password: form.password })
        toast.success('Admin registered! Please login.')
        setIsRegister(false)
      } else {
        await loginAdmin(form.email, form.password)
        toast.success('Admin login successful! 🚀')
        navigate('/admin/home')
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Authentication failed.')
    }
    setLoading(false)
  }

  return (
    <>
      <style>{css}</style>
      <div className="admin-auth">
        <div className="admin-auth-bg" />
        <div className="admin-auth-grid" />
        <div className="admin-auth-card">
          <div className="admin-auth-icon">⚙</div>
          <div className="admin-auth-title">{isRegister ? 'Admin Register' : 'Admin Login'}</div>
          <div className="admin-auth-sub">Secure admin control panel</div>

          {error && <div className="aa-error">⚠ {error}</div>}

          <form onSubmit={handleSubmit}>
            {isRegister && (
              <div><label className="aa-label">Full Name *</label><input className="aa-input" name="name" value={form.name} onChange={handleChange} placeholder="Admin Name" required /></div>
            )}
            <div><label className="aa-label">Email Address *</label><input className="aa-input" type="email" name="email" value={form.email} onChange={handleChange} placeholder="admin@example.com" required /></div>
            <div><label className="aa-label">Password *</label><input className="aa-input" type="password" name="password" value={form.password} onChange={handleChange} placeholder="••••••••" required /></div>
            {isRegister && (
              <div><label className="aa-label">Confirm Password *</label><input className="aa-input" type="password" name="confirmPassword" value={form.confirmPassword} onChange={handleChange} placeholder="••••••••" required /></div>
            )}
            <button className="aa-btn" type="submit" disabled={loading}>
              {loading ? 'Please wait...' : isRegister ? 'Create Admin Account' : 'Sign In to Admin Panel'}
            </button>
          </form>

          <div className="aa-toggle">
            {isRegister ? <>Already admin? <span onClick={() => setIsRegister(false)}>Login</span></> : <>New admin? <span onClick={() => setIsRegister(true)}>Register</span></>}
          </div>
          <div className="aa-back"><a href="/home">← Back to Store</a></div>
        </div>
      </div>
    </>
  )
}
