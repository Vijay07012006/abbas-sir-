import React, { useState } from 'react'
import { Outlet, Link, useNavigate, useLocation } from 'react-router-dom'
import { useAuth } from '../../../context/AuthContext'
import { toast } from 'react-toastify'

const css = `
.admin-layout { display: flex; min-height: 100vh; background: var(--c1); }
.admin-sidebar { width: 260px; background: rgba(5,10,20,0.98); border-right: 1px solid var(--border); display: flex; flex-direction: column; position: fixed; top: 0; left: 0; bottom: 0; z-index: 100; transition: var(--transition); overflow-y: auto; }
.admin-sidebar.collapsed { width: 72px; }
.sidebar-logo { padding: 1.25rem; border-bottom: 1px solid var(--border); display: flex; align-items: center; gap: 10px; min-height: 68px; }
.sidebar-logo-box { width: 38px; height: 38px; background: linear-gradient(135deg,var(--accent2),var(--accent3)); border-radius: 8px; display: flex; align-items: center; justify-content: center; font-family: var(--font1); font-size: 14px; font-weight: 900; color: #fff; flex-shrink: 0; }
.sidebar-logo-text { font-family: var(--font1); font-size: 14px; font-weight: 700; color: var(--white); white-space: nowrap; overflow: hidden; }
.sidebar-logo-text span { color: var(--accent); }
.sidebar-nav { padding: 1rem 0.75rem; flex: 1; }
.sidebar-section { font-family: var(--font3); font-size: 9px; color: var(--textdim); letter-spacing: 3px; text-transform: uppercase; padding: 0.5rem 0.75rem; margin-top: 1rem; margin-bottom: 0.25rem; }
.admin-sidebar.collapsed .sidebar-section { display: none; }
.sidebar-link { display: flex; align-items: center; gap: 12px; padding: 10px 12px; border-radius: 10px; text-decoration: none; color: var(--textdim); font-family: var(--font2); font-size: 14px; font-weight: 600; transition: var(--transition); margin-bottom: 4px; white-space: nowrap; overflow: hidden; }
.sidebar-link:hover { background: rgba(0,212,255,0.06); color: var(--accent); }
.sidebar-link.active { background: rgba(0,212,255,0.1); color: var(--accent); border-left: 2px solid var(--accent); }
.sidebar-icon { font-size: 18px; flex-shrink: 0; width: 22px; text-align: center; }
.sidebar-label { overflow: hidden; white-space: nowrap; }
.sidebar-logout { padding: 0.75rem; border-top: 1px solid var(--border); margin-top: auto; }
.sidebar-logout button { width: 100%; display: flex; align-items: center; gap: 12px; padding: 10px 12px; border-radius: 10px; border: 1px solid rgba(255,71,87,0.25); background: rgba(255,71,87,0.06); color: var(--red); font-family: var(--font2); font-size: 14px; font-weight: 600; cursor: pointer; transition: var(--transition); overflow: hidden; }
.sidebar-logout button:hover { background: rgba(255,71,87,0.12); border-color: var(--red); }
.admin-main { flex: 1; margin-left: 260px; display: flex; flex-direction: column; transition: var(--transition); }
.admin-topbar { height: 68px; background: rgba(5,10,20,0.95); border-bottom: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between; padding: 0 2rem; position: sticky; top: 0; z-index: 50; backdrop-filter: blur(10px); }
.topbar-toggle { background: none; border: none; color: var(--textdim); font-size: 20px; cursor: pointer; padding: 6px; border-radius: 8px; transition: var(--transition); }
.topbar-toggle:hover { color: var(--accent); background: rgba(0,212,255,0.08); }
.topbar-title { font-family: var(--font1); font-size: 15px; font-weight: 700; color: var(--white); }
.topbar-admin { font-family: var(--font3); font-size: 11px; color: var(--textdim); }
.admin-content { padding: 2rem; flex: 1; }
@media(max-width:768px) {
  .admin-sidebar { transform: translateX(-100%); }
  .admin-sidebar.mobile-open { transform: translateX(0); }
  .admin-main { margin-left: 0 !important; }
  .admin-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 99; }
}
`

const NAV_ITEMS = [
  { section: 'Dashboard', items: [{ icon: '🏠', label: 'Overview', path: '/admin/home' }] },
  { section: 'Catalog', items: [{ icon: '📂', label: 'Categories', path: '/admin/category' }, { icon: '📦', label: 'Products', path: '/admin/products' }] },
  { section: 'Sales', items: [{ icon: '🛒', label: 'Orders', path: '/admin/orders' }, { icon: '👥', label: 'Users', path: '/admin/users' }] },
]

export default function AdminLayout() {
  const [collapsed, setCollapsed] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const { admin, logoutAdmin } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()

  const handleLogout = () => { logoutAdmin(); toast.info('Admin logged out.'); navigate('/admin') }

  const isActive = (path) => location.pathname === path ? 'active' : ''

  return (
    <>
      <style>{css}</style>
      {mobileOpen && <div className="admin-overlay" onClick={() => setMobileOpen(false)} />}

      <div className="admin-layout">
        {/* SIDEBAR */}
        <aside className={`admin-sidebar ${collapsed ? 'collapsed' : ''} ${mobileOpen ? 'mobile-open' : ''}`}>
          <div className="sidebar-logo">
            <div className="sidebar-logo-box">AP</div>
            {!collapsed && <span className="sidebar-logo-text">Softpr<span>Innovation</span></span>}
          </div>

          <nav className="sidebar-nav">
            {NAV_ITEMS.map(({ section, items }) => (
              <div key={section}>
                <div className="sidebar-section">{section}</div>
                {items.map(({ icon, label, path }) => (
                  <Link key={path} to={path} className={`sidebar-link ${isActive(path)}`}>
                    <span className="sidebar-icon">{icon}</span>
                    {!collapsed && <span className="sidebar-label">{label}</span>}
                  </Link>
                ))}
              </div>
            ))}
          </nav>

          <div className="sidebar-logout">
            <button onClick={handleLogout}>
              <span className="sidebar-icon">🚪</span>
              {!collapsed && <span>Logout</span>}
            </button>
          </div>
        </aside>

        {/* MAIN */}
        <div className="admin-main" style={{ marginLeft: collapsed ? 72 : 260 }}>
          <div className="admin-topbar">
            <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
              <button className="topbar-toggle" onClick={() => { setCollapsed(c => !c); setMobileOpen(o => !o) }}>☰</button>
              <span className="topbar-title">Admin Panel</span>
            </div>
            <div>
              <div style={{ fontFamily: 'var(--font2)', fontSize: '14px', color: 'var(--white)', textAlign: 'right' }}>{admin?.name}</div>
              <div className="topbar-admin">{admin?.email}</div>
            </div>
          </div>
          <div className="admin-content">
            <Outlet />
          </div>
        </div>
      </div>
    </>
  )
}
