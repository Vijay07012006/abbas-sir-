import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import api from '../../../utils/api'

const css = `
.adh-stats { display: grid; grid-template-columns: repeat(auto-fill,minmax(200px,1fr)); gap: 20px; margin-bottom: 2rem; }
.adh-stat { background: var(--card); border: 1px solid var(--border); border-radius: 16px; padding: 1.75rem; transition: var(--transition); position: relative; overflow: hidden; }
.adh-stat:hover { transform: translateY(-4px); box-shadow: 0 15px 40px rgba(0,0,0,0.3); }
.adh-icon { font-size: 2rem; margin-bottom: 12px; display: block; }
.adh-num { font-family: var(--font1); font-size: 2rem; font-weight: 900; display: block; margin-bottom: 4px; }
.adh-label { font-family: var(--font3); font-size: 10px; color: var(--textdim); letter-spacing: 2px; text-transform: uppercase; }
.adh-quick { display: grid; grid-template-columns: repeat(auto-fill,minmax(180px,1fr)); gap: 14px; margin-bottom: 2rem; }
.adh-quick-btn { background: var(--card); border: 1px solid var(--border); border-radius: 12px; padding: 1.25rem; text-decoration: none; display: flex; align-items: center; gap: 12px; transition: var(--transition); }
.adh-quick-btn:hover { border-color: var(--accent); background: rgba(0,212,255,0.05); transform: translateY(-2px); }
.adh-qicon { font-size: 1.5rem; }
.adh-qtext { font-family: var(--font2); font-size: 13px; font-weight: 600; color: var(--text); }
.adh-section-title { font-family: var(--font1); font-size: 14px; font-weight: 700; color: var(--white); margin-bottom: 1.25rem; letter-spacing: 1px; display: flex; align-items: center; gap: 10px; }
.recent-order { background: var(--card); border: 1px solid var(--border); border-radius: 12px; padding: 1rem 1.25rem; margin-bottom: 10px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px; transition: var(--transition); }
.recent-order:hover { border-color: rgba(0,212,255,0.25); }
.ro-id { font-family: var(--font3); font-size: 12px; color: var(--accent); }
.ro-user { font-size: 13px; color: var(--text); }
.ro-amount { font-family: var(--font1); font-size: 14px; color: var(--accent); }
.ro-status { font-family: var(--font3); font-size: 10px; padding: 4px 12px; border-radius: 20px; letter-spacing: 1px; text-transform: uppercase; }
`

export default function AdminHome() {
  const [stats, setStats] = useState({ totalOrders: 0, totalRevenue: 0, pendingOrders: 0, deliveredOrders: 0 })
  const [recentOrders, setRecentOrders] = useState([])
  const [catCount, setCatCount] = useState(0)
  const [prodCount, setProdCount] = useState(0)
  const [userCount, setUserCount] = useState(0)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    Promise.all([
      api.get('/api/order/admin/stats').catch(() => ({ data: { stats: {} } })),
      api.get('/api/order/admin/all?limit=5').catch(() => ({ data: { orders: [] } })),
      api.get('/api/category').catch(() => ({ data: { total: 0 } })),
      api.get('/api/product?limit=1').catch(() => ({ data: { total: 0 } })),
      api.get('/api/user/all').catch(() => ({ data: { total: 0 } }))
    ]).then(([statsRes, ordersRes, catsRes, prodsRes, usersRes]) => {
      setStats(statsRes.data.stats || {})
      setRecentOrders(ordersRes.data.orders || [])
      setCatCount(catsRes.data.total || 0)
      setProdCount(prodsRes.data.total || 0)
      setUserCount(usersRes.data.total || 0)
      setLoading(false)
    })
  }, [])

  const statusColor = { placed: 'var(--accent)', confirmed: '#b57aff', processing: 'var(--accent3)', shipped: 'var(--accent2)', delivered: 'var(--green)', cancelled: 'var(--red)' }

  if (loading) return <div className="spinner" />

  return (
    <>
      <style>{css}</style>
      <div style={{ marginBottom: '2rem' }}>
        <h1 style={{ fontFamily: 'var(--font1)', fontSize: '1.5rem', color: 'var(--white)', marginBottom: '4px' }}>Dashboard Overview</h1>
        <p style={{ color: 'var(--textdim)', fontSize: '14px', fontFamily: 'var(--font3)', letterSpacing: '1px' }}>Welcome back, Admin! Here's what's happening.</p>
      </div>

      {/* STATS */}
      <div className="adh-stats">
        {[
          { icon: '🛒', num: stats.totalOrders || 0, label: 'Total Orders', color: 'var(--accent)' },
          { icon: '💰', num: `₹${(stats.totalRevenue || 0).toLocaleString('en-IN')}`, label: 'Total Revenue', color: 'var(--green)' },
          { icon: '⏳', num: stats.pendingOrders || 0, label: 'Pending Orders', color: 'var(--accent3)' },
          { icon: '✅', num: stats.deliveredOrders || 0, label: 'Delivered', color: 'var(--accent2)' },
          { icon: '📂', num: catCount, label: 'Categories', color: 'var(--accent)' },
          { icon: '📦', num: prodCount, label: 'Products', color: 'var(--green)' },
          { icon: '👥', num: userCount, label: 'Total Users', color: 'var(--accent2)' },
        ].map(({ icon, num, label, color }) => (
          <div key={label} className="adh-stat">
            <span className="adh-icon">{icon}</span>
            <span className="adh-num" style={{ color }}>{num}</span>
            <span className="adh-label">{label}</span>
          </div>
        ))}
      </div>

      {/* QUICK ACTIONS */}
      <div className="adh-section-title">⚡ Quick Actions</div>
      <div className="adh-quick">
        {[['📂', 'Add Category', '/admin/add-category'], ['📦', 'Add Product', '/admin/add-product'], ['📋', 'Manage Orders', '/admin/orders'], ['👥', 'View Users', '/admin/users'], ['🗂', 'All Categories', '/admin/category'], ['🛍', 'All Products', '/admin/products']].map(([icon, text, path]) => (
          <Link key={path} to={path} className="adh-quick-btn">
            <span className="adh-qicon">{icon}</span>
            <span className="adh-qtext">{text}</span>
          </Link>
        ))}
      </div>

      {/* RECENT ORDERS */}
      <div className="adh-section-title">📦 Recent Orders</div>
      {recentOrders.length === 0 ? (
        <div className="empty-state"><div className="empty-icon">📦</div><h3>No Orders Yet</h3></div>
      ) : recentOrders.map(order => (
        <div key={order._id} className="recent-order">
          <div>
            <div className="ro-id">#{order._id.slice(-8).toUpperCase()}</div>
            <div className="ro-user">{order.user?.name || 'Unknown'} • {order.user?.email}</div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
            <span className="ro-amount">₹{order.totalAmount?.toLocaleString('en-IN')}</span>
            <span className="ro-status" style={{ border: `1px solid ${statusColor[order.orderStatus]}`, color: statusColor[order.orderStatus], background: `${statusColor[order.orderStatus]}18` }}>{order.orderStatus}</span>
          </div>
        </div>
      ))}
      {recentOrders.length > 0 && <Link to="/admin/orders" className="btn-outline" style={{ fontSize: '13px', padding: '9px 20px', marginTop: '1rem', display: 'inline-flex' }}>View All Orders →</Link>}
    </>
  )
}
