import React, { useEffect, useState } from 'react'
import api from '../../../utils/api'
import { toast } from 'react-toastify'

const STATUS_OPTIONS = ['placed', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled']
const statusColor = { placed: 'var(--accent)', confirmed: '#b57aff', processing: 'var(--accent3)', shipped: 'var(--accent2)', delivered: 'var(--green)', cancelled: 'var(--red)' }

export default function Orders() {
  const [orders, setOrders] = useState([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState('')
  const [updating, setUpdating] = useState(null)

  const fetch = async () => {
    setLoading(true)
    try {
      const params = filter ? `?status=${filter}` : ''
      const r = await api.get(`/api/order/admin/all${params}`)
      setOrders(r.data.orders || [])
    } catch {}
    setLoading(false)
  }

  useEffect(() => { fetch() }, [filter])

  const handleStatusUpdate = async (orderId, status) => {
    setUpdating(orderId)
    try {
      await api.put(`/api/order/admin/${orderId}/status`, { orderStatus: status })
      toast.success(`Order status updated to "${status}"`)
      fetch()
    } catch { toast.error('Update failed.') }
    setUpdating(null)
  }

  return (
    <>
      <div style={{ marginBottom: '1.5rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 12 }}>
        <div>
          <h1 style={{ fontFamily: 'var(--font1)', fontSize: '1.4rem', color: 'var(--white)' }}>Orders</h1>
          <p style={{ color: 'var(--textdim)', fontSize: 13 }}>{orders.length} orders</p>
        </div>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          <select style={{ background: 'rgba(0,10,25,0.8)', border: '1px solid var(--border)', borderRadius: 20, padding: '8px 16px', color: 'var(--text)', fontFamily: 'var(--font2)', fontSize: 13, outline: 'none', cursor: 'pointer' }}
            value={filter} onChange={e => setFilter(e.target.value)}>
            <option value="">All Orders</option>
            {STATUS_OPTIONS.map(s => <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>)}
          </select>
        </div>
      </div>

      {loading ? <div className="spinner" /> : orders.length === 0 ? (
        <div className="empty-state"><div className="empty-icon">🛒</div><h3>No Orders Found</h3></div>
      ) : orders.map(order => (
        <div key={order._id} style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 14, padding: '1.5rem', marginBottom: 16, transition: 'all 0.35s ease' }}>
          <div className="d-flex justify-content-between align-items-start flex-wrap gap-3 mb-3">
            <div>
              <div style={{ fontFamily: 'var(--font3)', fontSize: 12, color: 'var(--accent)', marginBottom: 4 }}>Order #{order._id.slice(-8).toUpperCase()}</div>
              <div style={{ fontSize: 14, color: 'var(--white)', fontWeight: 600 }}>{order.user?.name || 'Unknown'}</div>
              <div style={{ fontSize: 12, color: 'var(--textdim)' }}>{order.user?.email} • {order.user?.mobile}</div>
              <div style={{ fontFamily: 'var(--font3)', fontSize: 11, color: 'var(--textdim)', marginTop: 4 }}>{new Date(order.createdAt).toLocaleString('en-IN')}</div>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 8 }}>
              <span style={{ fontFamily: 'var(--font1)', fontSize: '1.1rem', color: 'var(--accent)' }}>₹{order.totalAmount?.toLocaleString('en-IN')}</span>
              <span style={{ fontFamily: 'var(--font3)', fontSize: 10, padding: '4px 12px', borderRadius: 20, border: `1px solid ${statusColor[order.orderStatus]}`, color: statusColor[order.orderStatus], background: `${statusColor[order.orderStatus]}18`, letterSpacing: '1px', textTransform: 'uppercase' }}>{order.orderStatus}</span>
              <span style={{ fontFamily: 'var(--font3)', fontSize: 10, color: order.paymentStatus === 'paid' ? 'var(--green)' : 'var(--textdim)', letterSpacing: '1px' }}>💳 {order.paymentMethod} • {order.paymentStatus}</span>
            </div>
          </div>

          {/* Items */}
          <div style={{ borderTop: '1px solid rgba(255,255,255,0.06)', paddingTop: '1rem', marginBottom: '1rem' }}>
            {order.items?.map((item, i) => (
              <div key={i} style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', fontSize: 13 }}>
                <span style={{ color: 'var(--text)' }}>{item.name} <span style={{ color: 'var(--textdim)' }}>×{item.qty}</span></span>
                <span style={{ color: 'var(--accent)', fontFamily: 'var(--font1)', fontSize: 13 }}>₹{(item.price * item.qty).toLocaleString('en-IN')}</span>
              </div>
            ))}
          </div>

          {/* Shipping */}
          {order.shippingAddress && (
            <div style={{ background: 'rgba(0,0,0,0.2)', borderRadius: 8, padding: '10px 14px', marginBottom: '1rem', fontSize: 12, color: 'var(--textdim)' }}>
              📍 {order.shippingAddress.name} • {order.shippingAddress.mobile} • {order.shippingAddress.street}, {order.shippingAddress.city}, {order.shippingAddress.state} — {order.shippingAddress.pincode}
            </div>
          )}

          {/* Status Update */}
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
            <span style={{ fontFamily: 'var(--font3)', fontSize: '10px', color: 'var(--textdim)', letterSpacing: '2px' }}>UPDATE:</span>
            {STATUS_OPTIONS.map(s => (
              <button key={s} onClick={() => handleStatusUpdate(order._id, s)} disabled={updating === order._id || order.orderStatus === s}
                style={{ fontFamily: 'var(--font2)', fontSize: 11, fontWeight: 600, color: order.orderStatus === s ? '#fff' : 'var(--textdim)', background: order.orderStatus === s ? statusColor[s] : 'rgba(0,0,0,0.2)', border: `1px solid ${order.orderStatus === s ? statusColor[s] : 'var(--border)'}`, padding: '5px 12px', borderRadius: 20, cursor: order.orderStatus === s ? 'default' : 'pointer', transition: 'all 0.3s ease', opacity: updating === order._id ? 0.6 : 1 }}>
                {s}
              </button>
            ))}
          </div>
        </div>
      ))}
    </>
  )
}
