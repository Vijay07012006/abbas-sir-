import React, { useEffect, useState } from 'react'
import api from '../../../utils/api'

export default function Users() {
  const [users, setUsers] = useState([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')

  useEffect(() => {
    api.get('/api/user/all').then(r => { setUsers(r.data.users || []); setLoading(false) }).catch(() => setLoading(false))
  }, [])

  const filtered = users.filter(u =>
    u.name?.toLowerCase().includes(search.toLowerCase()) ||
    u.email?.toLowerCase().includes(search.toLowerCase()) ||
    u.mobile?.includes(search)
  )

  return (
    <>
      <div style={{ marginBottom: '1.5rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 12 }}>
        <div>
          <h1 style={{ fontFamily: 'var(--font1)', fontSize: '1.4rem', color: 'var(--white)' }}>Users</h1>
          <p style={{ color: 'var(--textdim)', fontSize: 13 }}>{users.length} registered users</p>
        </div>
        <input
          style={{ background: 'rgba(0,10,25,0.8)', border: '1px solid var(--border)', borderRadius: 20, padding: '8px 16px', color: 'var(--text)', fontFamily: 'var(--font2)', fontSize: 13, outline: 'none', minWidth: 220 }}
          placeholder="Search by name, email, mobile..."
          value={search} onChange={e => setSearch(e.target.value)}
        />
      </div>

      <div style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 16, overflow: 'hidden' }}>
        {loading ? <div className="spinner" /> : filtered.length === 0 ? (
          <div className="empty-state"><div className="empty-icon">👥</div><h3>No Users Found</h3></div>
        ) : (
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ background: 'rgba(0,0,0,0.2)' }}>
                  {['#', 'Avatar', 'Name', 'Email', 'Mobile', 'Joined', 'Status'].map(h => (
                    <th key={h} style={{ fontFamily: 'var(--font3)', fontSize: '10px', color: 'var(--textdim)', letterSpacing: '2px', textTransform: 'uppercase', padding: '12px 16px', textAlign: 'left', borderBottom: '1px solid var(--border)', whiteSpace: 'nowrap' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((user, i) => (
                  <tr key={user._id} style={{ borderBottom: '1px solid rgba(255,255,255,0.04)', transition: 'all 0.2s' }}>
                    <td style={{ padding: '14px 16px', color: 'var(--textdim)', fontFamily: 'var(--font3)', fontSize: 12 }}>{i + 1}</td>
                    <td style={{ padding: '14px 16px' }}>
                      <div style={{ width: 40, height: 40, borderRadius: '50%', background: 'linear-gradient(135deg,var(--accent),var(--accent2))', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--font1)', fontSize: 14, fontWeight: 900, color: '#fff' }}>
                        {user.name?.[0]?.toUpperCase() || 'U'}
                      </div>
                    </td>
                    <td style={{ padding: '14px 16px', fontFamily: 'var(--font2)', fontSize: 14, color: 'var(--white)', fontWeight: 600 }}>{user.name}</td>
                    <td style={{ padding: '14px 16px', fontSize: 13, color: 'var(--textdim)' }}>{user.email}</td>
                    <td style={{ padding: '14px 16px', fontSize: 13, color: 'var(--textdim)', fontFamily: 'var(--font3)' }}>{user.mobile || '—'}</td>
                    <td style={{ padding: '14px 16px', fontSize: 12, color: 'var(--textdim)', fontFamily: 'var(--font3)', whiteSpace: 'nowrap' }}>
                      {new Date(user.createdAt).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}
                    </td>
                    <td style={{ padding: '14px 16px' }}>
                      <span style={{ fontFamily: 'var(--font3)', fontSize: 10, padding: '4px 12px', borderRadius: 20, border: `1px solid ${user.isActive ? 'rgba(0,255,136,0.3)' : 'rgba(255,71,87,0.3)'}`, color: user.isActive ? 'var(--green)' : 'var(--red)', background: user.isActive ? 'rgba(0,255,136,0.1)' : 'rgba(255,71,87,0.1)', letterSpacing: '1px' }}>
                        {user.isActive ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </>
  )
}
