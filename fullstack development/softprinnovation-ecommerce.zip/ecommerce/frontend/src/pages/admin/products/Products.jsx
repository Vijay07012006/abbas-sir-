// Products.jsx
import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import api, { IMG_URL } from '../../../utils/api'
import { toast } from 'react-toastify'

export function Products() {
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')

  const fetch = async (q = '') => {
    setLoading(true)
    try {
      const r = await api.get(`/api/product?limit=50${q ? '&search=' + q : ''}`)
      setProducts(r.data.products || [])
    } catch {}
    setLoading(false)
  }

  useEffect(() => { fetch() }, [])

  const handleDelete = async (id, name) => {
    if (!confirm(`Delete product "${name}"?`)) return
    try { await api.delete(`/api/product/${id}`); toast.success('Product deleted!'); fetch() } catch { toast.error('Delete failed.') }
  }

  return (
    <>
      <div style={{ marginBottom: '1.5rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 12 }}>
        <div>
          <h1 style={{ fontFamily: 'var(--font1)', fontSize: '1.4rem', color: 'var(--white)' }}>Products</h1>
          <p style={{ color: 'var(--textdim)', fontSize: 13 }}>{products.length} products</p>
        </div>
        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
          <input style={{ background: 'rgba(0,10,25,0.8)', border: '1px solid var(--border)', borderRadius: 20, padding: '8px 16px', color: 'var(--text)', fontFamily: 'var(--font2)', fontSize: 13, outline: 'none', minWidth: 200 }}
            placeholder="Search products..." value={search} onChange={e => setSearch(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && fetch(search)} />
          <Link to="/admin/add-product" className="btn-glow" style={{ border: 'none' }}>+ Add Product</Link>
        </div>
      </div>
      <div className="admin-table-card" style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 16, overflow: 'hidden' }}>
        {loading ? <div className="spinner" /> : products.length === 0 ? (
          <div className="empty-state"><div className="empty-icon">📦</div><h3>No Products</h3><Link to="/admin/add-product" className="btn-glow mt-3">Add First Product</Link></div>
        ) : (
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ background: 'rgba(0,0,0,0.2)' }}>
                  {['#','Image','Name','Category','Price','Stock','Status','Actions'].map(h => (
                    <th key={h} style={{ fontFamily: 'var(--font3)', fontSize: '10px', color: 'var(--textdim)', letterSpacing: '2px', textTransform: 'uppercase', padding: '12px 16px', textAlign: 'left', borderBottom: '1px solid var(--border)' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {products.map((p, i) => {
                  const fp = p.finalPrice || Math.round(p.actualPrice - p.actualPrice * (p.discount || 0) / 100)
                  return (
                    <tr key={p._id} style={{ borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                      <td style={{ padding: '14px 16px', color: 'var(--textdim)', fontFamily: 'var(--font3)' }}>{i + 1}</td>
                      <td style={{ padding: '14px 16px' }}>
                        {p.images?.[0] ? <img src={`${IMG_URL}/${p.images[0]}`} alt={p.name} style={{ width: 48, height: 48, objectFit: 'contain', borderRadius: 8, border: '1px solid var(--border)', background: 'rgba(0,10,25,0.8)', padding: 4 }} />
                          : <div style={{ width: 48, height: 48, borderRadius: 8, background: 'rgba(0,212,255,0.08)', border: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.2rem' }}>📦</div>}
                      </td>
                      <td style={{ padding: '14px 16px', fontFamily: 'var(--font1)', fontSize: 13, color: 'var(--white)', maxWidth: 180 }}>{p.name}</td>
                      <td style={{ padding: '14px 16px', fontSize: 13, color: 'var(--textdim)' }}>{p.category?.category || '-'}</td>
                      <td style={{ padding: '14px 16px', fontFamily: 'var(--font1)', fontSize: 13, color: 'var(--accent)' }}>
                        ₹{fp.toLocaleString('en-IN')}
                        {p.discount > 0 && <span style={{ fontFamily: 'var(--font3)', fontSize: 10, color: 'var(--accent3)', marginLeft: 6 }}>-{p.discount}%</span>}
                      </td>
                      <td style={{ padding: '14px 16px', fontSize: 13, color: p.stock < 5 ? 'var(--red)' : 'var(--text)' }}>{p.stock}</td>
                      <td style={{ padding: '14px 16px' }}>
                        <span style={{ fontFamily: 'var(--font3)', fontSize: 10, padding: '4px 10px', borderRadius: 20, border: `1px solid ${p.stockStatus === 'inStock' ? 'rgba(0,255,136,0.3)' : 'rgba(255,71,87,0.3)'}`, color: p.stockStatus === 'inStock' ? 'var(--green)' : 'var(--red)', background: p.stockStatus === 'inStock' ? 'rgba(0,255,136,0.1)' : 'rgba(255,71,87,0.1)' }}>
                          {p.stockStatus}
                        </span>
                      </td>
                      <td style={{ padding: '14px 16px' }}>
                        <div style={{ display: 'flex', gap: 8 }}>
                          <Link to={`/admin/edit-product/${p._id}`} className="btn-edit" style={{ fontFamily: 'var(--font2)', fontSize: 12, fontWeight: 600, color: '#fff', background: 'linear-gradient(135deg,var(--accent2),#5522cc)', border: 'none', padding: '7px 14px', borderRadius: 20, cursor: 'pointer', textDecoration: 'none', display: 'inline-flex', alignItems: 'center', gap: 4 }}>✏ Edit</Link>
                          <button onClick={() => handleDelete(p._id, p.name)} style={{ fontFamily: 'var(--font2)', fontSize: 12, fontWeight: 600, color: '#fff', background: 'linear-gradient(135deg,var(--red),#c0392b)', border: 'none', padding: '7px 14px', borderRadius: 20, cursor: 'pointer' }}>🗑 Del</button>
                        </div>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </>
  )
}

export default Products
