import React, { useState, useEffect } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import api, { IMG_URL } from '../../../utils/api'
import { toast } from 'react-toastify'

const css = `
.af-label { font-family: var(--font3); font-size: 10px; color: var(--accent); letter-spacing: 2px; text-transform: uppercase; display: block; margin-bottom: 8px; }
.af-input { width: 100%; background: rgba(0,10,25,0.8); border: 1px solid var(--border); border-radius: 10px; padding: 12px 16px; color: var(--text); font-family: var(--font2); font-size: 14px; outline: none; transition: var(--transition); margin-bottom: 1.25rem; }
.af-input:focus { border-color: var(--accent); box-shadow: 0 0 12px rgba(0,212,255,0.12); }
.af-check-wrap { display: flex; align-items: center; gap: 12px; padding: 12px 0; }
.af-check { width: 18px; height: 18px; accent-color: var(--accent); cursor: pointer; }
.af-check-label { font-family: var(--font2); font-size: 14px; color: var(--text); cursor: pointer; }
`

export default function AddProduct() {
  const { id } = useParams()
  const navigate = useNavigate()
  const [categories, setCategories] = useState([])
  const [images, setImages] = useState([])
  const [previews, setPreviews] = useState([])
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({
    name: '', category: '', description: '', brandName: '', actualPrice: '',
    discount: '0', stock: '', tag: '', attributes: '', height: '', width: '', weight: '',
    stockStatus: 'inStock', refundPolicy: '7 days', replacementPolicy: '7 days',
    returnPolicy: '7 days', freeDelivery: false, isCod: false, status: 'active'
  })

  useEffect(() => {
    api.get('/api/category').then(r => setCategories(r.data.categories || []))
  }, [])

  useEffect(() => {
    if (!id) return
    api.get(`/api/product/${id}`).then(r => {
      const p = r.data.product
      setForm({
        name: p.name || '', category: typeof p.category === 'object' ? p.category?._id : p.category || '',
        description: p.description || '', brandName: p.brandName || '', actualPrice: p.actualPrice || '',
        discount: p.discount || '0', stock: p.stock || '', tag: p.tag || '',
        attributes: p.attributes ? JSON.stringify(p.attributes, null, 2) : '',
        height: p.height || '', width: p.width || '', weight: p.weight || '',
        stockStatus: p.stockStatus || 'inStock', refundPolicy: p.refundPolicy || '7 days',
        replacementPolicy: p.replacementPolicy || '7 days', returnPolicy: p.returnPolicy || '7 days',
        freeDelivery: p.freeDelivery || false, isCod: p.isCod || false, status: p.status || 'active'
      })
      if (p.images?.length) setPreviews(p.images.map(img => `${IMG_URL}/${img}`))
    }).catch(() => toast.error('Failed to load product.'))
  }, [id])

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target
    setForm(p => ({ ...p, [name]: type === 'checkbox' ? checked : value }))
  }

  const handleImages = (e) => {
    const files = Array.from(e.target.files)
    setImages(files)
    setPreviews(files.map(f => URL.createObjectURL(f)))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!id && images.length === 0) { toast.error('At least one image required.'); return }
    setLoading(true)
    const fd = new FormData()
    Object.entries(form).forEach(([k, v]) => fd.append(k, v))
    images.forEach(img => fd.append('images', img))
    try {
      if (id) { await api.put(`/api/product/${id}`, fd, { headers: { 'Content-Type': 'multipart/form-data' } }); toast.success('Product updated! ✅') }
      else { await api.post('/api/product', fd, { headers: { 'Content-Type': 'multipart/form-data' } }); toast.success('Product added! ✅') }
      navigate('/admin/products')
    } catch (err) { toast.error(err.response?.data?.message || 'Operation failed.') }
    setLoading(false)
  }

  const inputStyle = { width: '100%', background: 'rgba(0,10,25,0.8)', border: '1px solid var(--border)', borderRadius: 10, padding: '12px 16px', color: 'var(--text)', fontFamily: 'var(--font2)', fontSize: 14, outline: 'none', marginBottom: '1.25rem', transition: 'all 0.35s ease' }
  const labelStyle = { fontFamily: 'var(--font3)', fontSize: '10px', color: 'var(--accent)', letterSpacing: '2px', textTransform: 'uppercase', display: 'block', marginBottom: '8px' }

  return (
    <>
      <style>{css}</style>
      <div style={{ marginBottom: '1.5rem' }}>
        <h1 style={{ fontFamily: 'var(--font1)', fontSize: '1.4rem', color: 'var(--white)' }}>{id ? 'Edit Product' : 'Add New Product'}</h1>
      </div>
      <div style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 16, overflow: 'hidden', maxWidth: 900 }}>
        <div style={{ background: 'rgba(0,212,255,0.06)', borderBottom: '1px solid var(--border)', padding: '1.25rem 1.5rem' }}>
          <span style={{ fontFamily: 'var(--font1)', fontSize: '14px', fontWeight: 700, color: 'var(--white)' }}>{id ? '✏ Edit Product' : '📦 New Product'}</span>
        </div>
        <div style={{ padding: '2rem' }}>
          <form onSubmit={handleSubmit}>
            <div className="row g-3">
              {/* Basic Info */}
              <div className="col-md-6"><label style={labelStyle}>Product Name *</label><input style={inputStyle} name="name" value={form.name} onChange={handleChange} placeholder="e.g. Raspberry Pi 5" required /></div>
              <div className="col-md-6"><label style={labelStyle}>Category *</label>
                <select style={inputStyle} name="category" value={form.category} onChange={handleChange} required>
                  <option value="">Select Category</option>
                  {categories.map(c => <option key={c._id} value={c._id}>{c.category}</option>)}
                </select>
              </div>
              <div className="col-12"><label style={labelStyle}>Description *</label><textarea style={{...inputStyle, resize:'vertical', minHeight:100}} name="description" value={form.description} onChange={handleChange} placeholder="Detailed product description..." required /></div>
              <div className="col-md-4"><label style={labelStyle}>Brand Name *</label><input style={inputStyle} name="brandName" value={form.brandName} onChange={handleChange} placeholder="e.g. Raspberry Pi Foundation" required /></div>
              <div className="col-md-4"><label style={labelStyle}>Actual Price (₹) *</label><input style={inputStyle} type="number" name="actualPrice" value={form.actualPrice} onChange={handleChange} placeholder="999" required min="0" /></div>
              <div className="col-md-4"><label style={labelStyle}>Discount (%)</label><input style={inputStyle} type="number" name="discount" value={form.discount} onChange={handleChange} placeholder="0" min="0" max="100" /></div>
              <div className="col-md-3"><label style={labelStyle}>Stock Qty *</label><input style={inputStyle} type="number" name="stock" value={form.stock} onChange={handleChange} placeholder="100" required min="0" /></div>
              <div className="col-md-3"><label style={labelStyle}>Tag</label>
                <select style={inputStyle} name="tag" value={form.tag} onChange={handleChange}>
                  <option value="">No Tag</option>
                  {['new','hot','sale','featured'].map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
              <div className="col-md-3"><label style={labelStyle}>Stock Status</label>
                <select style={inputStyle} name="stockStatus" value={form.stockStatus} onChange={handleChange}>
                  <option value="inStock">In Stock</option>
                  <option value="outOfStock">Out of Stock</option>
                </select>
              </div>
              <div className="col-md-3"><label style={labelStyle}>Product Status</label>
                <select style={inputStyle} name="status" value={form.status} onChange={handleChange}>
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                </select>
              </div>
              <div className="col-md-4"><label style={labelStyle}>Height</label><input style={inputStyle} name="height" value={form.height} onChange={handleChange} placeholder="e.g. 85mm" /></div>
              <div className="col-md-4"><label style={labelStyle}>Width</label><input style={inputStyle} name="width" value={form.width} onChange={handleChange} placeholder="e.g. 56mm" /></div>
              <div className="col-md-4"><label style={labelStyle}>Weight</label><input style={inputStyle} name="weight" value={form.weight} onChange={handleChange} placeholder="e.g. 46g" /></div>
              <div className="col-md-4"><label style={labelStyle}>Return Policy</label><input style={inputStyle} name="returnPolicy" value={form.returnPolicy} onChange={handleChange} placeholder="7 days" /></div>
              <div className="col-md-4"><label style={labelStyle}>Replacement Policy</label><input style={inputStyle} name="replacementPolicy" value={form.replacementPolicy} onChange={handleChange} placeholder="7 days" /></div>
              <div className="col-md-4"><label style={labelStyle}>Refund Policy</label><input style={inputStyle} name="refundPolicy" value={form.refundPolicy} onChange={handleChange} placeholder="7 days" /></div>
              <div className="col-12"><label style={labelStyle}>Attributes (JSON)</label><textarea style={{...inputStyle, resize:'vertical', minHeight:80, fontFamily:'var(--font3)', fontSize:12}} name="attributes" value={form.attributes} onChange={handleChange} placeholder='{"Processor": "BCM2712", "RAM": "8GB", "GPIO": "40-pin"}' /></div>
              <div className="col-md-6">
                <div className="af-check-wrap">
                  <input type="checkbox" className="af-check" name="freeDelivery" checked={form.freeDelivery} onChange={handleChange} id="fd" />
                  <label className="af-check-label" htmlFor="fd">✈ Free Delivery</label>
                </div>
              </div>
              <div className="col-md-6">
                <div className="af-check-wrap">
                  <input type="checkbox" className="af-check" name="isCod" checked={form.isCod} onChange={handleChange} id="cod" />
                  <label className="af-check-label" htmlFor="cod">💵 Cash on Delivery (COD)</label>
                </div>
              </div>
              <div className="col-12">
                <label style={labelStyle}>Product Images {!id && '*'}</label>
                <div style={{ border: '2px dashed var(--border)', borderRadius: 12, padding: '2rem', textAlign: 'center', cursor: 'pointer', marginBottom: '1rem' }} onClick={() => document.getElementById('prod-img-input').click()}>
                  <div style={{ fontSize: '2rem', marginBottom: '8px' }}>📸</div>
                  <div style={{ fontFamily: 'var(--font3)', fontSize: '12px', color: 'var(--textdim)' }}>Click to upload images (up to 5)</div>
                </div>
                <input id="prod-img-input" type="file" accept="image/*" multiple onChange={handleImages} style={{ display: 'none' }} />
                {previews.length > 0 && (
                  <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
                    {previews.map((src, i) => <img key={i} src={src} alt={`preview-${i}`} style={{ width: 100, height: 100, objectFit: 'contain', borderRadius: 10, border: '1px solid var(--border)', background: 'rgba(0,10,25,0.8)', padding: 6 }} />)}
                  </div>
                )}
              </div>
            </div>
            <div style={{ display: 'flex', gap: 12, marginTop: '2rem' }}>
              <button className="btn-glow" type="submit" disabled={loading} style={{ border: 'none' }}>
                {loading ? 'Saving...' : id ? '✅ Update Product' : '✅ Add Product'}
              </button>
              <button type="button" className="btn-outline" onClick={() => navigate('/admin/products')}>Cancel</button>
            </div>
          </form>
        </div>
      </div>
    </>
  )
}
