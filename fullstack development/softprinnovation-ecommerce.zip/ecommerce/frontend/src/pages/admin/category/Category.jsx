// Category.jsx - Admin category management
import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import api, { IMG_URL } from '../../../utils/api'
import { toast } from 'react-toastify'

const tableCSS = `
.admin-table-card { background: var(--card); border: 1px solid var(--border); border-radius: 16px; overflow: hidden; }
.admin-table-header { background: rgba(0,212,255,0.06); border-bottom: 1px solid var(--border); padding: 1.25rem 1.5rem; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; }
.admin-table-title { font-family: var(--font1); font-size: 14px; font-weight: 700; color: var(--white); }
.at-table { width: 100%; border-collapse: collapse; }
.at-table th { font-family: var(--font3); font-size: 10px; color: var(--textdim); letter-spacing: 2px; text-transform: uppercase; padding: 12px 16px; text-align: left; border-bottom: 1px solid var(--border); background: rgba(0,0,0,0.2); }
.at-table td { padding: 14px 16px; border-bottom: 1px solid rgba(255,255,255,0.04); font-size: 14px; color: var(--text); vertical-align: middle; }
.at-table tr:last-child td { border-bottom: none; }
.at-table tr:hover td { background: rgba(0,212,255,0.03); }
.at-actions { display: flex; gap: 8px; }
.btn-edit { font-family: var(--font2); font-size: 12px; font-weight: 600; color: #fff; background: linear-gradient(135deg,var(--accent2),#5522cc); border: none; padding: 7px 16px; border-radius: 20px; cursor: pointer; transition: var(--transition); text-decoration: none; display: inline-flex; align-items: center; gap: 5px; }
.btn-edit:hover { transform: scale(1.04); box-shadow: 0 0 12px rgba(123,47,247,0.4); color: #fff; }
.btn-del { font-family: var(--font2); font-size: 12px; font-weight: 600; color: #fff; background: linear-gradient(135deg,var(--red),#c0392b); border: none; padding: 7px 16px; border-radius: 20px; cursor: pointer; transition: var(--transition); display: inline-flex; align-items: center; gap: 5px; }
.btn-del:hover { transform: scale(1.04); box-shadow: 0 0 12px rgba(255,71,87,0.4); }
.cat-thumb { width: 48px; height: 48px; object-fit: cover; border-radius: 8px; border: 1px solid var(--border); }
.cat-thumb-placeholder { width: 48px; height: 48px; border-radius: 8px; background: rgba(0,212,255,0.08); border: 1px solid var(--border); display: flex; align-items: center; justify-content: center; font-size: 1.3rem; }
.status-badge { font-family: var(--font3); font-size: 10px; padding: 4px 12px; border-radius: 20px; letter-spacing: 1px; text-transform: uppercase; }
.status-active { background: rgba(0,255,136,0.12); color: var(--green); border: 1px solid rgba(0,255,136,0.3); }
.status-inactive { background: rgba(255,107,53,0.12); color: var(--accent3); border: 1px solid rgba(255,107,53,0.3); }
`

export function Category() {
  const [data, setData] = useState([])
  const [loading, setLoading] = useState(true)

  const fetch = async () => {
    try { const r = await api.get('/api/category'); setData(r.data.categories || []) } catch {}
    setLoading(false)
  }

  useEffect(() => { fetch() }, [])

  const handleDelete = async (id, name) => {
    if (!confirm(`Delete category "${name}"?`)) return
    try { await api.delete(`/api/category/${id}`); toast.success('Category deleted!'); fetch() } catch { toast.error('Delete failed.') }
  }

  return (
    <>
      <style>{tableCSS}</style>
      <div style={{ marginBottom: '1.5rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 12 }}>
        <div><h1 style={{ fontFamily: 'var(--font1)', fontSize: '1.4rem', color: 'var(--white)' }}>Categories</h1><p style={{ color: 'var(--textdim)', fontSize: 13 }}>{data.length} categories</p></div>
        <Link to="/admin/add-category" className="btn-glow" style={{ border: 'none' }}>+ Add Category</Link>
      </div>
      <div className="admin-table-card">
        {loading ? <div className="spinner" /> : data.length === 0 ? (
          <div className="empty-state"><div className="empty-icon">📂</div><h3>No Categories</h3><Link to="/admin/add-category" className="btn-glow mt-3">Add First Category</Link></div>
        ) : (
          <div className="table-responsive">
            <table className="at-table">
              <thead><tr><th>#</th><th>Image</th><th>Name</th><th>Description</th><th>Status</th><th>Actions</th></tr></thead>
              <tbody>
                {data.map((item, i) => (
                  <tr key={item._id}>
                    <td style={{ fontFamily: 'var(--font3)', color: 'var(--textdim)' }}>{i + 1}</td>
                    <td>{item.picture ? <img src={`${IMG_URL}/${item.picture}`} alt={item.category} className="cat-thumb" /> : <div className="cat-thumb-placeholder">📦</div>}</td>
                    <td style={{ fontFamily: 'var(--font1)', fontSize: 13, color: 'var(--white)' }}>{item.category}</td>
                    <td style={{ color: 'var(--textdim)', maxWidth: 200 }}>{item.description?.slice(0, 60)}{item.description?.length > 60 ? '…' : ''}</td>
                    <td><span className={`status-badge ${item.status === 'active' ? 'status-active' : 'status-inactive'}`}>{item.status}</span></td>
                    <td><div className="at-actions"><Link to={`/admin/edit-category/${item._id}`} className="btn-edit">✏ Edit</Link><button className="btn-del" onClick={() => handleDelete(item._id, item.category)}>🗑 Delete</button></div></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </>
  )
}

export default Category
