import React, { useState, useEffect } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import api, { IMG_URL } from '../../../utils/api'
import { toast } from 'react-toastify'

const css = `
.admin-form-card { background: var(--card); border: 1px solid var(--border); border-radius: 16px; overflow: hidden; }
.afc-header { background: rgba(0,212,255,0.06); border-bottom: 1px solid var(--border); padding: 1.25rem 1.5rem; }
.afc-title { font-family: var(--font1); font-size: 14px; font-weight: 700; color: var(--white); }
.afc-body { padding: 2rem; }
.af-label { font-family: var(--font3); font-size: 10px; color: var(--accent); letter-spacing: 2px; text-transform: uppercase; display: block; margin-bottom: 8px; }
.af-input { width: 100%; background: rgba(0,10,25,0.8); border: 1px solid var(--border); border-radius: 10px; padding: 12px 16px; color: var(--text); font-family: var(--font2); font-size: 14px; outline: none; transition: var(--transition); margin-bottom: 1.5rem; }
.af-input:focus { border-color: var(--accent); box-shadow: 0 0 12px rgba(0,212,255,0.12); }
.af-file-wrap { border: 2px dashed var(--border); border-radius: 12px; padding: 2rem; text-align: center; cursor: pointer; transition: var(--transition); margin-bottom: 1.5rem; }
.af-file-wrap:hover { border-color: var(--accent); background: rgba(0,212,255,0.03); }
.af-preview { width: 120px; height: 120px; object-fit: contain; border-radius: 12px; border: 1px solid var(--border); padding: 8px; background: rgba(0,10,25,0.8); margin-bottom: 1.5rem; display: block; }
`

export default function AddCategory() {
  const { id } = useParams()
  const navigate = useNavigate()
  const [loading, setLoading] = useState(false)
  const [preview, setPreview] = useState('')
  const [data, setData] = useState({ category: '', description: '', picture: null })

  useEffect(() => {
    if (!id) return
    api.get(`/api/category/${id}`).then(r => {
      const cat = r.data.category
      setData({ category: cat.category, description: cat.description, picture: null })
      if (cat.picture) setPreview(`${IMG_URL}/${cat.picture}`)
    }).catch(() => toast.error('Failed to load category.'))
  }, [id])

  const handleChange = (e) => {
    if (e.target.type === 'file') {
      setData(p => ({ ...p, picture: e.target.files[0] }))
      setPreview(URL.createObjectURL(e.target.files[0]))
    } else {
      setData(p => ({ ...p, [e.target.name]: e.target.value }))
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!data.category || !data.description) { toast.error('Name and description required.'); return }
    if (!id && !data.picture) { toast.error('Image required for new category.'); return }

    setLoading(true)
    const fd = new FormData()
    fd.append('category', data.category)
    fd.append('description', data.description)
    if (data.picture) fd.append('picture', data.picture)

    try {
      if (id) {
        await api.put(`/api/category/${id}`, fd, { headers: { 'Content-Type': 'multipart/form-data' } })
        toast.success('Category updated! ✅')
      } else {
        await api.post('/api/category', fd, { headers: { 'Content-Type': 'multipart/form-data' } })
        toast.success('Category added! ✅')
      }
      navigate('/admin/category')
    } catch (err) {
      toast.error(err.response?.data?.message || 'Operation failed.')
    }
    setLoading(false)
  }

  return (
    <>
      <style>{css}</style>
      <div style={{ marginBottom: '1.5rem' }}>
        <h1 style={{ fontFamily: 'var(--font1)', fontSize: '1.4rem', color: 'var(--white)' }}>{id ? 'Edit Category' : 'Add New Category'}</h1>
      </div>
      <div className="admin-form-card" style={{ maxWidth: 700 }}>
        <div className="afc-header"><span className="afc-title">{id ? '✏ Edit Category' : '📂 New Category'}</span></div>
        <div className="afc-body">
          <form onSubmit={handleSubmit}>
            <label className="af-label">Category Name *</label>
            <input className="af-input" name="category" value={data.category} onChange={handleChange} placeholder="e.g. Raspberry Pi, Arduino..." required />

            <label className="af-label">Description *</label>
            <textarea className="af-input" name="description" value={data.description} onChange={handleChange} placeholder="Describe this category..." rows={3} required />

            <label className="af-label">Category Image {!id && '*'}</label>
            <div className="af-file-wrap" onClick={() => document.getElementById('cat-img-input').click()}>
              <div style={{ fontSize: '2rem', marginBottom: '8px' }}>📸</div>
              <div style={{ fontFamily: 'var(--font3)', fontSize: '12px', color: 'var(--textdim)' }}>Click to upload image</div>
              <div style={{ fontFamily: 'var(--font3)', fontSize: '10px', color: 'var(--textdim)', marginTop: '4px' }}>JPG, PNG, WEBP — Max 5MB</div>
            </div>
            <input id="cat-img-input" type="file" accept="image/*" onChange={handleChange} style={{ display: 'none' }} />

            {preview && <img src={preview} alt="preview" className="af-preview" />}

            <div style={{ display: 'flex', gap: '12px' }}>
              <button className="btn-glow" type="submit" disabled={loading} style={{ border: 'none' }}>
                {loading ? 'Saving...' : id ? '✅ Update Category' : '✅ Add Category'}
              </button>
              <button type="button" className="btn-outline" onClick={() => navigate('/admin/category')}>Cancel</button>
            </div>
          </form>
        </div>
      </div>
    </>
  )
}
