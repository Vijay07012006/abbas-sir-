const multer = require('multer');
const path = require('path');
const fs = require('fs');

const createStorage = (folder) => multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = `uploads/${folder}`;
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `${folder}-${Date.now()}${ext}`);
  }
});

const fileFilter = (req, file, cb) => {
  const allowed = /jpeg|jpg|png|webp|gif/;
  const ext = allowed.test(path.extname(file.originalname).toLowerCase());
  const mime = allowed.test(file.mimetype);
  if (ext && mime) cb(null, true);
  else cb(new Error('Only image files are allowed!'));
};

const categoryUpload = multer({
  storage: createStorage('category'),
  fileFilter,
  limits: { fileSize: 5 * 1024 * 1024 }
});

const productUpload = multer({
  storage: createStorage('product'),
  fileFilter,
  limits: { fileSize: 10 * 1024 * 1024 }
});

module.exports = { categoryUpload, productUpload };
