const mongoose = require('mongoose');

const categorySchema = new mongoose.Schema({
  category: { type: String, required: true, unique: true, trim: true },
  description: { type: String, required: true },
  picture: { type: String, default: '' },
  status: { type: String, enum: ['active', 'inactive', 'delete'], default: 'active' },
  slug: { type: String, unique: true, sparse: true }
}, { timestamps: true });

categorySchema.pre('save', function (next) {
  if (this.category) {
    this.slug = this.category.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
  }
  next();
});

module.exports = mongoose.model('Category', categorySchema);
