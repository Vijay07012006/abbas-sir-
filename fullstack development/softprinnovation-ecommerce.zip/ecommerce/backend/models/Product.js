const mongoose = require('mongoose');

const reviewSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  name: String,
  rating: { type: Number, required: true, min: 1, max: 5 },
  comment: String
}, { timestamps: true });

const productSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  category: { type: mongoose.Schema.Types.ObjectId, ref: 'Category', required: true },
  description: { type: String, required: true },
  brandName: { type: String, required: true, trim: true },
  actualPrice: { type: Number, required: true, min: 0 },
  discount: { type: Number, default: 0, min: 0, max: 100 },
  finalPrice: { type: Number },
  images: { type: [String], required: true },
  tag: { type: String, enum: ['new', 'hot', 'sale', 'featured', ''], default: '' },
  stock: { type: Number, required: true, min: 0, default: 0 },
  attributes: { type: Object, default: {} },
  height: String,
  width: String,
  weight: String,
  status: { type: String, enum: ['active', 'inactive', 'delete'], default: 'active' },
  stockStatus: { type: String, enum: ['inStock', 'outOfStock'], default: 'inStock' },
  refundPolicy: { type: String, default: '7 days' },
  replacementPolicy: { type: String, default: '7 days' },
  returnPolicy: { type: String, default: '7 days' },
  freeDelivery: { type: Boolean, default: false },
  isCod: { type: Boolean, default: false },
  reviews: [reviewSchema],
  avgRating: { type: Number, default: 0 },
  numReviews: { type: Number, default: 0 },
  sold: { type: Number, default: 0 }
}, { timestamps: true });

// Auto-calculate finalPrice
productSchema.pre('save', function (next) {
  this.finalPrice = Math.round(this.actualPrice - (this.actualPrice * this.discount) / 100);
  if (this.stock === 0) this.stockStatus = 'outOfStock';
  next();
});

productSchema.pre('findOneAndUpdate', function (next) {
  const update = this.getUpdate();
  if (update.actualPrice !== undefined || update.discount !== undefined) {
    const price = update.actualPrice || 0;
    const disc = update.discount || 0;
    update.finalPrice = Math.round(price - (price * disc) / 100);
  }
  next();
});

module.exports = mongoose.model('Product', productSchema);
