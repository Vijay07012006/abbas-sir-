const express = require('express');
const router = express.Router();
const Category = require('../models/Category');
const { categoryUpload } = require('../middleware/upload');
const { adminAuth } = require('../middleware/auth');
const fs = require('fs');

// GET /api/category - public
router.get('/', async (req, res) => {
  try {
    const categories = await Category.find({ status: { $ne: 'delete' } }).sort({ createdAt: -1 });
    res.json({ success: true, categories, total: categories.length });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// GET /api/category/:id - public
router.get('/:id', async (req, res) => {
  try {
    const category = await Category.findById(req.params.id);
    if (!category || category.status === 'delete')
      return res.status(404).json({ success: false, message: 'Category not found.' });
    res.json({ success: true, category });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// POST /api/category - admin only
router.post('/', adminAuth, categoryUpload.single('picture'), async (req, res) => {
  try {
    const { category, description } = req.body;
    if (!category || !description)
      return res.status(400).json({ success: false, message: 'Category name and description required.' });

    const existing = await Category.findOne({ category: { $regex: new RegExp(`^${category}$`, 'i') } });
    if (existing)
      return res.status(409).json({ success: false, message: 'Category already exists.' });

    const newCategory = new Category({
      category: category.trim(),
      description: description.trim(),
      picture: req.file ? req.file.path.replace(/\\/g, '/') : '',
      status: 'active'
    });

    await newCategory.save();
    res.status(201).json({ success: true, message: 'Category added!', category: newCategory });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// PUT /api/category/:id - admin only
router.put('/:id', adminAuth, categoryUpload.single('picture'), async (req, res) => {
  try {
    const { category, description, status } = req.body;
    const existing = await Category.findById(req.params.id);
    if (!existing) return res.status(404).json({ success: false, message: 'Category not found.' });

    const updateData = {
      category: category?.trim() || existing.category,
      description: description?.trim() || existing.description,
      status: status || existing.status
    };

    if (req.file) {
      // Delete old image
      if (existing.picture && fs.existsSync(existing.picture)) {
        fs.unlink(existing.picture, () => {});
      }
      updateData.picture = req.file.path.replace(/\\/g, '/');
    }

    const updated = await Category.findByIdAndUpdate(req.params.id, updateData, { new: true });
    res.json({ success: true, message: 'Category updated!', category: updated });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// DELETE /api/category/:id - soft delete, admin only
router.delete('/:id', adminAuth, async (req, res) => {
  try {
    await Category.findByIdAndUpdate(req.params.id, { status: 'delete' });
    res.json({ success: true, message: 'Category deleted.' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

module.exports = router;
