const express = require('express');
const router = express.Router();
const Order = require('../models/Order');
const Product = require('../models/Product');
const { userAuth, adminAuth } = require('../middleware/auth');

// POST /api/order - place order (user)
router.post('/', userAuth, async (req, res) => {
  try {
    const { items, shippingAddress, paymentMethod } = req.body;

    if (!items || items.length === 0)
      return res.status(400).json({ success: false, message: 'Order items required.' });

    let subtotal = 0;
    const orderItems = [];

    for (const item of items) {
      const product = await Product.findById(item.product);
      if (!product) continue;
      if (product.stock < item.qty)
        return res.status(400).json({ success: false, message: `Insufficient stock for ${product.name}.` });

      orderItems.push({
        product: product._id,
        name: product.name,
        image: product.images[0] || '',
        price: product.finalPrice,
        qty: item.qty
      });

      subtotal += product.finalPrice * item.qty;

      // Deduct stock
      await Product.findByIdAndUpdate(product._id, {
        $inc: { stock: -item.qty, sold: item.qty },
        stockStatus: product.stock - item.qty <= 0 ? 'outOfStock' : 'inStock'
      });
    }

    const shippingCharge = subtotal >= 999 ? 0 : 49;
    const totalAmount = subtotal + shippingCharge;

    const order = new Order({
      user: req.user.id,
      items: orderItems,
      shippingAddress,
      paymentMethod,
      subtotal,
      shippingCharge,
      totalAmount,
      paymentStatus: paymentMethod === 'COD' ? 'pending' : 'pending'
    });

    await order.save();
    res.status(201).json({ success: true, message: 'Order placed!', order });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// GET /api/order/my - user's orders
router.get('/my', userAuth, async (req, res) => {
  try {
    const orders = await Order.find({ user: req.user.id })
      .populate('items.product', 'name images')
      .sort({ createdAt: -1 });
    res.json({ success: true, orders });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// GET /api/order/:id - single order
router.get('/:id', userAuth, async (req, res) => {
  try {
    const order = await Order.findById(req.params.id).populate('items.product');
    if (!order) return res.status(404).json({ success: false, message: 'Order not found.' });
    res.json({ success: true, order });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// GET /api/order/admin/all - admin: all orders
router.get('/admin/all', adminAuth, async (req, res) => {
  try {
    const { page = 1, limit = 20, status } = req.query;
    const query = status ? { orderStatus: status } : {};
    const total = await Order.countDocuments(query);
    const orders = await Order.find(query)
      .populate('user', 'name email mobile')
      .populate('items.product', 'name images')
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(Number(limit));
    res.json({ success: true, orders, total, pages: Math.ceil(total / limit) });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// PUT /api/order/admin/:id/status - admin: update order status
router.put('/admin/:id/status', adminAuth, async (req, res) => {
  try {
    const { orderStatus, trackingId } = req.body;
    const updateData = { orderStatus };
    if (trackingId) updateData.trackingId = trackingId;
    if (orderStatus === 'delivered') {
      updateData.deliveredAt = new Date();
      updateData.paymentStatus = 'paid';
    }
    const order = await Order.findByIdAndUpdate(req.params.id, updateData, { new: true });
    res.json({ success: true, message: 'Order status updated!', order });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// GET /api/order/admin/stats - dashboard stats
router.get('/admin/stats', adminAuth, async (req, res) => {
  try {
    const totalOrders = await Order.countDocuments();
    const totalRevenue = await Order.aggregate([
      { $match: { paymentStatus: 'paid' } },
      { $group: { _id: null, total: { $sum: '$totalAmount' } } }
    ]);
    const pendingOrders = await Order.countDocuments({ orderStatus: 'placed' });
    const deliveredOrders = await Order.countDocuments({ orderStatus: 'delivered' });

    res.json({
      success: true,
      stats: {
        totalOrders,
        totalRevenue: totalRevenue[0]?.total || 0,
        pendingOrders,
        deliveredOrders
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

module.exports = router;
