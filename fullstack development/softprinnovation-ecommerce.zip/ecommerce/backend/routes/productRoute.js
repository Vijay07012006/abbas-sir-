const express = require('express');
const router = express.Router();
const Product = require('../models/Product');
const { productUpload } = require('../middleware/upload');
const { adminAuth, userAuth } = require('../middleware/auth');
const fs = require('fs');

// GET /api/product - public, supports search/filter/pagination
router.get('/', async (req, res) => {
  try {
    const {
      page = 1, limit = 12, category, search, tag,
      minPrice, maxPrice, sort = '-createdAt', status = 'active'
    } = req.query;

    const query = { status: { $ne: 'delete' } };

    if (status && status !== 'all') query.status = status;
    if (category) query.category = category;
    if (tag) query.tag = tag;
    if (search) query.name = { $regex: search, $options: 'i' };
    if (minPrice || maxPrice) {
      query.finalPrice = {};
      if (minPrice) query.finalPrice.$gte = Number(minPrice);
      if (maxPrice) query.finalPrice.$lte = Number(maxPrice);
    }

    const total = await Product.countDocuments(query);
    const products = await Product.find(query)
      .populate('category', 'category picture slug')
      .sort(sort)
      .skip((page - 1) * limit)
      .limit(Number(limit));

    res.json({
      success: true,
      products,
      total,
      page: Number(page),
      pages: Math.ceil(total / limit)
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// GET /api/product/featured
router.get('/featured', async (req, res) => {
  try {
    const products = await Product.find({ status: 'active', tag: { $in: ['featured', 'hot', 'new'] } })
      .populate('category', 'category')
      .sort({ sold: -1 })
      .limit(8);
    res.json({ success: true, products });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// GET /api/product/:id - public
router.get('/:id', async (req, res) => {
  try {
    const product = await Product.findById(req.params.id).populate('category', 'category slug');
    if (!product || product.status === 'delete')
      return res.status(404).json({ success: false, message: 'Product not found.' });
    res.json({ success: true, product });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// POST /api/product - admin only
router.post('/', adminAuth, productUpload.array('images', 5), async (req, res) => {
  try {
    if (!req.files || req.files.length === 0)
      return res.status(400).json({ success: false, message: 'At least one image required.' });

    let attributes = {};
    try {
      if (req.body.attributes) attributes = JSON.parse(req.body.attributes);
    } catch {}

    const product = new Product({
      ...req.body,
      images: req.files.map(f => f.path.replace(/\\/g, '/')),
      attributes,
      freeDelivery: req.body.freeDelivery === 'true',
      isCod: req.body.isCod === 'true',
      actualPrice: Number(req.body.actualPrice),
      discount: Number(req.body.discount) || 0,
      stock: Number(req.body.stock) || 0
    });

    await product.save();
    const populated = await product.populate('category', 'category');
    res.status(201).json({ success: true, message: 'Product added!', product: populated });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// PUT /api/product/:id - admin only
router.put('/:id', adminAuth, productUpload.array('images', 5), async (req, res) => {
  try {
    const existing = await Product.findById(req.params.id);
    if (!existing) return res.status(404).json({ success: false, message: 'Product not found.' });

    let attributes = existing.attributes;
    try {
      if (req.body.attributes && req.body.attributes !== '') {
        attributes = JSON.parse(req.body.attributes);
      }
    } catch {}

    const updateData = {
      name: req.body.name,
      category: req.body.category,
      description: req.body.description,
      brandName: req.body.brandName,
      actualPrice: Number(req.body.actualPrice),
      discount: Number(req.body.discount) || 0,
      tag: req.body.tag,
      stock: Number(req.body.stock) || 0,
      attributes,
      height: req.body.height,
      width: req.body.width,
      weight: req.body.weight,
      stockStatus: req.body.stockStatus,
      refundPolicy: req.body.refundPolicy,
      replacementPolicy: req.body.replacementPolicy,
      returnPolicy: req.body.returnPolicy,
      freeDelivery: req.body.freeDelivery === 'true',
      isCod: req.body.isCod === 'true',
      status: req.body.status || existing.status
    };

    if (req.files && req.files.length > 0) {
      // Delete old images
      existing.images.forEach(img => {
        if (fs.existsSync(img)) fs.unlink(img, () => {});
      });
      updateData.images = req.files.map(f => f.path.replace(/\\/g, '/'));
    }

    updateData.finalPrice = Math.round(updateData.actualPrice - (updateData.actualPrice * updateData.discount) / 100);

    const updated = await Product.findByIdAndUpdate(req.params.id, updateData, { new: true })
      .populate('category', 'category');

    res.json({ success: true, message: 'Product updated!', product: updated });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// DELETE /api/product/:id - soft delete, admin only
router.delete('/:id', adminAuth, async (req, res) => {
  try {
    await Product.findByIdAndUpdate(req.params.id, { status: 'delete' });
    res.json({ success: true, message: 'Product deleted.' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// POST /api/product/:id/review - user only
router.post('/:id/review', userAuth, async (req, res) => {
  try {
    const { rating, comment } = req.body;
    const product = await Product.findById(req.params.id);
    if (!product) return res.status(404).json({ success: false, message: 'Product not found.' });

    const alreadyReviewed = product.reviews.find(r => r.user.toString() === req.user.id);
    if (alreadyReviewed) return res.status(400).json({ success: false, message: 'Already reviewed.' });

    product.reviews.push({ user: req.user.id, name: req.body.name, rating: Number(rating), comment });
    product.numReviews = product.reviews.length;
    product.avgRating = product.reviews.reduce((acc, r) => acc + r.rating, 0) / product.reviews.length;

    await product.save();
    res.status(201).json({ success: true, message: 'Review added!' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

module.exports = router;
