const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const Admin = require('../models/Admin');
const { adminAuth } = require('../middleware/auth');

const generateToken = (payload, expiresIn) => jwt.sign(payload, process.env.JWT_SECRET, { expiresIn });

// POST /api/admin/register
router.post('/register', async (req, res) => {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password)
      return res.status(400).json({ success: false, message: 'All fields required.' });

    const existing = await Admin.findOne({ email });
    if (existing)
      return res.status(409).json({ success: false, message: 'Admin already exists.' });

    const admin = new Admin({ name, email, password });
    await admin.save();

    res.status(201).json({ success: true, message: 'Admin registered successfully.' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// POST /api/admin/login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password)
      return res.status(400).json({ success: false, message: 'Email and password required.' });

    const admin = await Admin.findOne({ email });
    if (!admin)
      return res.status(401).json({ success: false, message: 'Invalid credentials.' });

    const match = await admin.comparePassword(password);
    if (!match)
      return res.status(401).json({ success: false, message: 'Invalid credentials.' });

    const token = generateToken({ id: admin._id, role: 'admin' }, process.env.ADMIN_JWT_EXPIRES_IN);

    res.cookie('adminToken', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 30 * 24 * 60 * 60 * 1000
    });

    res.json({
      success: true,
      message: 'Admin login successful!',
      token,
      admin: { id: admin._id, name: admin.name, email: admin.email, role: admin.role }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// POST /api/admin/logout
router.post('/logout', (req, res) => {
  res.clearCookie('adminToken');
  res.json({ success: true, message: 'Admin logged out.' });
});

// GET /api/admin/profile
router.get('/profile', adminAuth, async (req, res) => {
  try {
    const admin = await Admin.findById(req.admin.id).select('-password');
    res.json({ success: true, admin });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

module.exports = router;
