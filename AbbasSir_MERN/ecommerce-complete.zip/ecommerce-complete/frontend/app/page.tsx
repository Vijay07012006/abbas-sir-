'use client';

import { useEffect, useState } from 'react';

export default function Home() {
  const [backendStatus, setBackendStatus] = useState<string>('Checking...');
  const [products, setProducts] = useState([]);

  useEffect(() => {
    // Check backend health
    fetch('http://localhost:5000/health')
      .then(res => res.json())
      .then(data => {
        setBackendStatus('✅ Connected');
      })
      .catch(() => {
        setBackendStatus('❌ Not Connected');
      });

    // Fetch products
    fetch('http://localhost:5000/api/v1/products')
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          setProducts(data.data.products || []);
        }
      })
      .catch(err => console.error('Error fetching products:', err));
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
                🛒 E-Commerce Platform
              </h1>
              <p className="text-sm text-gray-500 mt-1">
                Enterprise Grade Shopping Experience
              </p>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">
                Backend: <span className="font-semibold">{backendStatus}</span>
              </span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Welcome Section */}
        <div className="bg-white rounded-lg shadow-lg p-8 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            🎉 Welcome to Your E-Commerce Platform!
          </h2>
          <p className="text-gray-600 mb-6">
            Your enterprise-grade e-commerce platform is now running successfully. 
            This is a production-ready system with full authentication, product management, 
            cart, checkout, and admin dashboard.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-blue-50 rounded-lg p-6">
              <div className="text-3xl mb-2">🔐</div>
              <h3 className="font-semibold text-gray-900 mb-2">Authentication</h3>
              <p className="text-sm text-gray-600">
                JWT-based secure authentication with role-based access control
              </p>
            </div>
            
            <div className="bg-green-50 rounded-lg p-6">
              <div className="text-3xl mb-2">📦</div>
              <h3 className="font-semibold text-gray-900 mb-2">Product Management</h3>
              <p className="text-sm text-gray-600">
                Complete product catalog with variants, inventory, and reviews
              </p>
            </div>
            
            <div className="bg-purple-50 rounded-lg p-6">
              <div className="text-3xl mb-2">⚡</div>
              <h3 className="font-semibold text-gray-900 mb-2">High Performance</h3>
              <p className="text-sm text-gray-600">
                Multi-layer caching, optimized queries, and horizontal scaling
              </p>
            </div>
          </div>
        </div>

        {/* Quick Start */}
        <div className="bg-white rounded-lg shadow-lg p-8 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            🚀 Quick Start Guide
          </h2>
          
          <div className="space-y-4">
            <div className="border-l-4 border-blue-500 pl-4">
              <h3 className="font-semibold text-gray-900 mb-2">1. API Testing</h3>
              <p className="text-sm text-gray-600 mb-2">
                Test the backend API:
              </p>
              <code className="block bg-gray-100 p-3 rounded text-sm">
                curl http://localhost:5000/health
              </code>
            </div>
            
            <div className="border-l-4 border-green-500 pl-4">
              <h3 className="font-semibold text-gray-900 mb-2">2. Register User</h3>
              <p className="text-sm text-gray-600 mb-2">
                Create your first user account via API or implement the registration page
              </p>
              <code className="block bg-gray-100 p-3 rounded text-sm overflow-x-auto">
                POST http://localhost:5000/api/v1/auth/register
              </code>
            </div>
            
            <div className="border-l-4 border-purple-500 pl-4">
              <h3 className="font-semibold text-gray-900 mb-2">3. Explore Features</h3>
              <p className="text-sm text-gray-600">
                Check out the complete documentation in the project files
              </p>
            </div>
          </div>
        </div>

        {/* Products Section */}
        <div className="bg-white rounded-lg shadow-lg p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            📦 Products
          </h2>
          
          {products.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {products.map((product: any) => (
                <div key={product._id} className="border rounded-lg p-4 hover:shadow-md transition">
                  <h3 className="font-semibold text-gray-900">{product.name}</h3>
                  <p className="text-sm text-gray-600 mt-2">{product.description}</p>
                  <div className="mt-4 flex items-center justify-between">
                    <span className="text-lg font-bold text-blue-600">
                      ${product.pricing?.currentPrice}
                    </span>
                    <button className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition">
                      Add to Cart
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">📦</div>
              <p className="text-gray-600 mb-4">
                No products yet. Add some products via the admin panel or API.
              </p>
              <p className="text-sm text-gray-500">
                Seed the database: <code className="bg-gray-100 px-2 py-1 rounded">cd backend && npm run seed</code>
              </p>
            </div>
          )}
        </div>

        {/* Documentation Links */}
        <div className="mt-8 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg shadow-lg p-8 text-white">
          <h2 className="text-2xl font-bold mb-4">📚 Documentation</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h3 className="font-semibold mb-2">📖 Available Guides:</h3>
              <ul className="space-y-2 text-sm">
                <li>• README-HINDI.md - हिंदी में शुरुआती गाइड</li>
                <li>• ARCHITECTURE.md - System design</li>
                <li>• API_DOCUMENTATION.md - API reference</li>
                <li>• DATABASE_SCHEMA.md - Database structure</li>
                <li>• DEPLOYMENT.md - Production deployment</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-2">🛠️ Quick Commands:</h3>
              <ul className="space-y-2 text-sm">
                <li>• ./start.sh - Start project</li>
                <li>• ./stop.sh - Stop project</li>
                <li>• ./logs.sh - View logs</li>
                <li>• ./reset.sh - Reset everything</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-8 text-center text-gray-600">
          <p className="text-sm">
            Made with ❤️ - Enterprise Grade E-Commerce Platform
          </p>
          <p className="text-xs mt-2">
            Production Ready • Scalable • Secure • Fast
          </p>
        </div>
      </main>
    </div>
  );
}
