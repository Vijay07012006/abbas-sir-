import './globals.css'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'E-Commerce Platform',
  description: 'Enterprise Grade E-Commerce Platform',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
