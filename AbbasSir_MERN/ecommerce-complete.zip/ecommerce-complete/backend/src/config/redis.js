const { createClient } = require('redis');
const config = require('./index');
const logger = require('../utils/logger');

const redisClient = createClient({
  socket: {
    host: config.redis.host,
    port: config.redis.port,
  },
  password: config.redis.password,
  database: config.redis.db,
});

// Error handling
redisClient.on('error', (err) => {
  logger.error('Redis Client Error:', err);
});

redisClient.on('connect', () => {
  logger.info('Redis Client Connected');
});

redisClient.on('ready', () => {
  logger.info('Redis Client Ready');
});

redisClient.on('reconnecting', () => {
  logger.warn('Redis Client Reconnecting');
});

// Cache helper functions
const cache = {
  /**
   * Get value from cache
   * @param {string} key - Cache key
   * @returns {Promise<any>} - Cached value or null
   */
  async get(key) {
    try {
      const value = await redisClient.get(key);
      return value ? JSON.parse(value) : null;
    } catch (error) {
      logger.error('Cache get error:', error);
      return null;
    }
  },

  /**
   * Set value in cache
   * @param {string} key - Cache key
   * @param {any} value - Value to cache
   * @param {number} ttl - Time to live in seconds
   * @returns {Promise<boolean>} - Success status
   */
  async set(key, value, ttl = 3600) {
    try {
      await redisClient.setEx(key, ttl, JSON.stringify(value));
      return true;
    } catch (error) {
      logger.error('Cache set error:', error);
      return false;
    }
  },

  /**
   * Delete value from cache
   * @param {string} key - Cache key
   * @returns {Promise<boolean>} - Success status
   */
  async del(key) {
    try {
      await redisClient.del(key);
      return true;
    } catch (error) {
      logger.error('Cache delete error:', error);
      return false;
    }
  },

  /**
   * Delete all keys matching pattern
   * @param {string} pattern - Key pattern (e.g., 'product:*')
   * @returns {Promise<number>} - Number of keys deleted
   */
  async delPattern(pattern) {
    try {
      const keys = await redisClient.keys(pattern);
      if (keys.length > 0) {
        await redisClient.del(keys);
      }
      return keys.length;
    } catch (error) {
      logger.error('Cache delete pattern error:', error);
      return 0;
    }
  },

  /**
   * Check if key exists
   * @param {string} key - Cache key
   * @returns {Promise<boolean>} - Existence status
   */
  async exists(key) {
    try {
      const result = await redisClient.exists(key);
      return result === 1;
    } catch (error) {
      logger.error('Cache exists error:', error);
      return false;
    }
  },

  /**
   * Increment counter
   * @param {string} key - Cache key
   * @param {number} increment - Increment value (default: 1)
   * @returns {Promise<number>} - New value
   */
  async incr(key, increment = 1) {
    try {
      return await redisClient.incrBy(key, increment);
    } catch (error) {
      logger.error('Cache increment error:', error);
      return 0;
    }
  },

  /**
   * Set expiration on existing key
   * @param {string} key - Cache key
   * @param {number} ttl - Time to live in seconds
   * @returns {Promise<boolean>} - Success status
   */
  async expire(key, ttl) {
    try {
      await redisClient.expire(key, ttl);
      return true;
    } catch (error) {
      logger.error('Cache expire error:', error);
      return false;
    }
  },

  /**
   * Get multiple values
   * @param {string[]} keys - Array of cache keys
   * @returns {Promise<any[]>} - Array of values
   */
  async mget(keys) {
    try {
      const values = await redisClient.mGet(keys);
      return values.map((v) => (v ? JSON.parse(v) : null));
    } catch (error) {
      logger.error('Cache mget error:', error);
      return [];
    }
  },

  /**
   * Add to set
   * @param {string} key - Set key
   * @param {string|string[]} members - Member(s) to add
   * @returns {Promise<number>} - Number of added members
   */
  async sadd(key, members) {
    try {
      return await redisClient.sAdd(key, members);
    } catch (error) {
      logger.error('Cache sadd error:', error);
      return 0;
    }
  },

  /**
   * Get all members of set
   * @param {string} key - Set key
   * @returns {Promise<string[]>} - Set members
   */
  async smembers(key) {
    try {
      return await redisClient.sMembers(key);
    } catch (error) {
      logger.error('Cache smembers error:', error);
      return [];
    }
  },

  /**
   * Remove from set
   * @param {string} key - Set key
   * @param {string|string[]} members - Member(s) to remove
   * @returns {Promise<number>} - Number of removed members
   */
  async srem(key, members) {
    try {
      return await redisClient.sRem(key, members);
    } catch (error) {
      logger.error('Cache srem error:', error);
      return 0;
    }
  },
};

module.exports = redisClient;
module.exports.cache = cache;
