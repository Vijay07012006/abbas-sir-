const jwt = require('jsonwebtoken');
const asyncHandler = require('express-async-handler');
const User = require('../models/User');
const config = require('../config');
const { AppError } = require('../utils/errors');
const { cache } = require('../config/redis');

/**
 * Protect routes - Verify JWT token
 */
exports.protect = asyncHandler(async (req, res, next) => {
  let token;

  // Extract token from Authorization header
  if (
    req.headers.authorization &&
    req.headers.authorization.startsWith('Bearer')
  ) {
    token = req.headers.authorization.split(' ')[1];
  }

  if (!token) {
    throw new AppError('Not authorized to access this route', 401);
  }

  try {
    // Verify token
    const decoded = jwt.verify(token, config.jwt.secret);

    // Check if token is in blacklist (for logout)
    const isBlacklisted = await cache.exists(`blacklist:${token}`);
    if (isBlacklisted) {
      throw new AppError('Token has been invalidated', 401);
    }

    // Check cache first for user data
    const cacheKey = `user:${decoded.id}`;
    let user = await cache.get(cacheKey);

    if (!user) {
      // Get user from database
      user = await User.findById(decoded.id).select('-password');

      if (!user) {
        throw new AppError('User not found', 404);
      }

      // Cache user data
      await cache.set(cacheKey, user, config.cache.userSessionTTL);
    }

    // Check if user is active
    if (!user.isActive) {
      throw new AppError('User account is deactivated', 403);
    }

    // Check if user is suspended
    if (user.isSuspended) {
      throw new AppError('User account is suspended', 403);
    }

    // Attach user to request
    req.user = user;
    req.token = token;

    next();
  } catch (error) {
    if (error.name === 'JsonWebTokenError') {
      throw new AppError('Invalid token', 401);
    } else if (error.name === 'TokenExpiredError') {
      throw new AppError('Token expired', 401);
    }
    throw error;
  }
});

/**
 * Authorize by role
 * @param  {...string} roles - Allowed roles
 */
exports.authorize = (...roles) => {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      throw new AppError(
        `User role '${req.user.role}' is not authorized to access this route`,
        403
      );
    }
    next();
  };
};

/**
 * Authorize by permission
 * @param  {...string} permissions - Required permissions
 */
exports.requirePermissions = (...permissions) => {
  return (req, res, next) => {
    const userPermissions = req.user.permissions || [];

    const hasPermission = permissions.every((permission) =>
      userPermissions.includes(permission)
    );

    if (!hasPermission) {
      throw new AppError(
        'You do not have the required permissions',
        403
      );
    }

    next();
  };
};

/**
 * Optional authentication - Does not throw error if no token
 */
exports.optionalAuth = asyncHandler(async (req, res, next) => {
  let token;

  if (
    req.headers.authorization &&
    req.headers.authorization.startsWith('Bearer')
  ) {
    token = req.headers.authorization.split(' ')[1];
  }

  if (token) {
    try {
      const decoded = jwt.verify(token, config.jwt.secret);
      const user = await User.findById(decoded.id).select('-password');

      if (user && user.isActive && !user.isSuspended) {
        req.user = user;
      }
    } catch (error) {
      // Silently fail - authentication is optional
    }
  }

  next();
});

/**
 * Verify refresh token
 */
exports.verifyRefreshToken = asyncHandler(async (req, res, next) => {
  const refreshToken = req.cookies.refreshToken;

  if (!refreshToken) {
    throw new AppError('Refresh token not found', 401);
  }

  try {
    const decoded = jwt.verify(refreshToken, config.jwt.refreshSecret);

    if (decoded.type !== 'refresh') {
      throw new AppError('Invalid refresh token', 401);
    }

    // Get user and verify refresh token exists in database
    const user = await User.findById(decoded.id).select('+refreshTokens');

    if (!user) {
      throw new AppError('User not found', 404);
    }

    // Hash the refresh token for comparison
    const crypto = require('crypto');
    const hashedToken = crypto
      .createHash('sha256')
      .update(refreshToken)
      .digest('hex');

    const tokenExists = user.refreshTokens.some(
      (rt) => rt.token === hashedToken && rt.expiresAt > Date.now()
    );

    if (!tokenExists) {
      throw new AppError('Invalid or expired refresh token', 401);
    }

    req.user = user;
    req.refreshToken = refreshToken;

    next();
  } catch (error) {
    if (error.name === 'JsonWebTokenError') {
      throw new AppError('Invalid refresh token', 401);
    } else if (error.name === 'TokenExpiredError') {
      throw new AppError('Refresh token expired', 401);
    }
    throw error;
  }
});

/**
 * Check resource ownership
 * @param {string} resourceModel - Model name (e.g., 'Order', 'Review')
 * @param {string} userField - Field name that contains user ID (default: 'userId')
 */
exports.checkOwnership = (resourceModel, userField = 'userId') => {
  return asyncHandler(async (req, res, next) => {
    const Model = require(`../models/${resourceModel}`);
    const resourceId = req.params.id;

    const resource = await Model.findById(resourceId);

    if (!resource) {
      throw new AppError(`${resourceModel} not found`, 404);
    }

    // Allow admins to access any resource
    if (['ADMIN', 'SUPER_ADMIN'].includes(req.user.role)) {
      return next();
    }

    // Check ownership
    const ownerId = resource[userField]?.toString() || resource[userField];
    if (ownerId !== req.user.id) {
      throw new AppError('Not authorized to access this resource', 403);
    }

    // Attach resource to request for later use
    req.resource = resource;

    next();
  });
};

/**
 * API Key authentication (for server-to-server communication)
 */
exports.apiKeyAuth = asyncHandler(async (req, res, next) => {
  const apiKey = req.headers['x-api-key'];

  if (!apiKey) {
    throw new AppError('API key is required', 401);
  }

  // Verify API key (you would store these in database)
  const validApiKeys = process.env.API_KEYS?.split(',') || [];

  if (!validApiKeys.includes(apiKey)) {
    throw new AppError('Invalid API key', 401);
  }

  next();
});
