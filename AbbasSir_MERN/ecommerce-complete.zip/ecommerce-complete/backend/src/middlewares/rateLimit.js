const rateLimit = require('express-rate-limit');
const RedisStore = require('rate-limit-redis');
const redisClient = require('../config/redis');
const config = require('../config');
const { AppError } = require('./errorHandler');

/**
 * Create rate limiter with Redis store
 */
const createRateLimiter = (options = {}) => {
  const {
    windowMs = config.rateLimit.windowMs,
    max = config.rateLimit.maxRequests,
    message = 'Too many requests, please try again later',
    skipSuccessfulRequests = false,
    skipFailedRequests = false,
  } = options;

  return rateLimit({
    windowMs,
    max,
    message: { success: false, error: { code: 'RATE_LIMIT_EXCEEDED', message } },
    standardHeaders: true, // Return rate limit info in headers
    legacyHeaders: false,
    skipSuccessfulRequests,
    skipFailedRequests,
    
    // Use Redis as store
    store: new RedisStore({
      client: redisClient,
      prefix: 'rl:',
    }),

    // Key generator based on user or IP
    keyGenerator: (req) => {
      if (req.user) {
        return `user:${req.user.id}`;
      }
      return req.ip;
    },

    // Skip rate limiting for certain conditions
    skip: (req) => {
      // Skip for super admins
      if (req.user?.role === 'SUPER_ADMIN') {
        return true;
      }
      return false;
    },

    // Handler for rate limit exceeded
    handler: (req, res) => {
      throw new AppError(message, 429, 'RATE_LIMIT_EXCEEDED');
    },
  });
};

/**
 * Global API rate limiter
 */
const apiLimiter = createRateLimiter({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: async (req) => {
    // Different limits based on user role
    if (req.user) {
      switch (req.user.role) {
        case 'SUPER_ADMIN':
          return 10000; // Practically unlimited
        case 'ADMIN':
          return 5000;
        case 'VENDOR':
          return 2000;
        default:
          return 1000; // Authenticated users
      }
    }
    return 100; // Anonymous users
  },
  message: 'Too many requests from this IP, please try again later',
});

/**
 * Strict rate limiter for sensitive endpoints
 */
const strictLimiter = createRateLimiter({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5,
  message: 'Too many attempts, please try again later',
  skipSuccessfulRequests: false,
  skipFailedRequests: false,
});

/**
 * Authentication rate limiter
 */
const authLimiter = createRateLimiter({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // 5 login attempts
  message: 'Too many login attempts, please try again later',
  skipSuccessfulRequests: true, // Don't count successful logins
});

/**
 * Registration rate limiter
 */
const registerLimiter = createRateLimiter({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 3, // 3 registrations per hour
  message: 'Too many accounts created, please try again later',
});

/**
 * Password reset rate limiter
 */
const passwordResetLimiter = createRateLimiter({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 3,
  message: 'Too many password reset attempts, please try again later',
});

/**
 * Search rate limiter
 */
const searchLimiter = createRateLimiter({
  windowMs: 60 * 1000, // 1 minute
  max: 50,
  message: 'Too many search requests, please slow down',
});

/**
 * File upload rate limiter
 */
const uploadLimiter = createRateLimiter({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 50,
  message: 'Too many file uploads, please try again later',
});

/**
 * Review creation rate limiter
 */
const reviewLimiter = createRateLimiter({
  windowMs: 24 * 60 * 60 * 1000, // 24 hours
  max: 10,
  message: 'Too many reviews submitted, please try again tomorrow',
});

/**
 * Order creation rate limiter
 */
const orderLimiter = createRateLimiter({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 10,
  message: 'Too many orders placed, please try again later',
});

/**
 * Custom rate limiter based on cost/complexity
 * Used for expensive operations
 */
const createCostBasedLimiter = (cost) => {
  return async (req, res, next) => {
    const key = `cost:${req.user?.id || req.ip}`;
    const windowMs = 60 * 1000; // 1 minute
    const maxCost = 100; // Maximum cost per minute

    try {
      // Get current cost
      const currentCost = await redisClient.get(key);
      const totalCost = (parseInt(currentCost) || 0) + cost;

      if (totalCost > maxCost) {
        throw new AppError(
          'Request complexity limit exceeded',
          429,
          'COMPLEXITY_LIMIT_EXCEEDED'
        );
      }

      // Increment cost
      await redisClient.setEx(key, windowMs / 1000, totalCost.toString());

      next();
    } catch (error) {
      next(error);
    }
  };
};

/**
 * Sliding window rate limiter (more precise)
 */
const createSlidingWindowLimiter = (options) => {
  const {
    windowMs = 60000,
    max = 10,
    message = 'Rate limit exceeded',
  } = options;

  return async (req, res, next) => {
    const key = `sw:${req.user?.id || req.ip}`;
    const now = Date.now();
    const windowStart = now - windowMs;

    try {
      // Remove old entries
      await redisClient.zRemRangeByScore(key, 0, windowStart);

      // Count requests in current window
      const count = await redisClient.zCard(key);

      if (count >= max) {
        throw new AppError(message, 429, 'RATE_LIMIT_EXCEEDED');
      }

      // Add current request
      await redisClient.zAdd(key, { score: now, value: now.toString() });
      
      // Set expiry
      await redisClient.expire(key, Math.ceil(windowMs / 1000));

      // Add rate limit headers
      res.set({
        'X-RateLimit-Limit': max,
        'X-RateLimit-Remaining': Math.max(0, max - count - 1),
        'X-RateLimit-Reset': new Date(now + windowMs).toISOString(),
      });

      next();
    } catch (error) {
      next(error);
    }
  };
};

module.exports = {
  apiLimiter,
  strictLimiter,
  authLimiter,
  registerLimiter,
  passwordResetLimiter,
  searchLimiter,
  uploadLimiter,
  reviewLimiter,
  orderLimiter,
  createRateLimiter,
  createCostBasedLimiter,
  createSlidingWindowLimiter,
};
