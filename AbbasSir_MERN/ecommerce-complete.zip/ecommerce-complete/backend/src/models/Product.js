const mongoose = require('mongoose');
const slugify = require('slugify');
const mongoosePaginate = require('mongoose-paginate-v2');

const productSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Product name is required'],
      trim: true,
      maxlength: [200, 'Product name cannot exceed 200 characters'],
    },
    slug: {
      type: String,
      unique: true,
      lowercase: true,
    },
    sku: {
      type: String,
      required: [true, 'SKU is required'],
      unique: true,
      uppercase: true,
      trim: true,
    },
    description: {
      type: String,
      required: [true, 'Description is required'],
      maxlength: [5000, 'Description cannot exceed 5000 characters'],
    },
    shortDescription: {
      type: String,
      maxlength: [500, 'Short description cannot exceed 500 characters'],
    },
    categoryId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Category',
      required: [true, 'Category is required'],
    },
    categoryPath: {
      type: String, // "Electronics > Phones > Smartphones"
    },
    brandId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Brand',
    },
    brandName: {
      type: String, // Denormalized for performance
    },
    pricing: {
      basePrice: {
        type: Number,
        required: [true, 'Base price is required'],
        min: [0, 'Price cannot be negative'],
      },
      currentPrice: {
        type: Number,
        required: [true, 'Current price is required'],
        min: [0, 'Price cannot be negative'],
      },
      currency: {
        type: String,
        default: 'USD',
        enum: ['USD', 'EUR', 'GBP', 'INR'],
      },
      discount: {
        type: {
          type: String,
          enum: ['PERCENTAGE', 'FIXED'],
        },
        value: Number,
        startDate: Date,
        endDate: Date,
      },
      costPrice: {
        type: Number,
        min: [0, 'Cost price cannot be negative'],
      },
      compareAtPrice: Number,
    },
    inventory: {
      quantity: {
        type: Number,
        required: [true, 'Quantity is required'],
        min: [0, 'Quantity cannot be negative'],
        default: 0,
      },
      lowStockThreshold: {
        type: Number,
        default: 10,
      },
      inStock: {
        type: Boolean,
        default: true,
      },
      backorder: {
        type: Boolean,
        default: false,
      },
      restockDate: Date,
      warehouse: String,
    },
    images: [
      {
        url: {
          type: String,
          required: true,
        },
        alt: String,
        isPrimary: {
          type: Boolean,
          default: false,
        },
        order: {
          type: Number,
          default: 0,
        },
      },
    ],
    videos: [
      {
        url: String,
        thumbnail: String,
        duration: Number,
      },
    ],
    specifications: {
      dimensions: {
        length: Number,
        width: Number,
        height: Number,
        unit: {
          type: String,
          enum: ['cm', 'in', 'mm'],
          default: 'cm',
        },
      },
      weight: {
        value: Number,
        unit: {
          type: String,
          enum: ['kg', 'g', 'lb', 'oz'],
          default: 'kg',
        },
      },
      color: String,
      size: String,
      material: String,
      custom: {
        type: Map,
        of: String,
      },
    },
    hasVariants: {
      type: Boolean,
      default: false,
    },
    parentProductId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Product',
    },
    variantOptions: [
      {
        name: String, // Color, Size, Material
        value: String, // Red, Large, Cotton
      },
    ],
    seo: {
      metaTitle: {
        type: String,
        maxlength: [60, 'Meta title cannot exceed 60 characters'],
      },
      metaDescription: {
        type: String,
        maxlength: [160, 'Meta description cannot exceed 160 characters'],
      },
      metaKeywords: [String],
      ogImage: String,
    },
    rating: {
      average: {
        type: Number,
        default: 0,
        min: 0,
        max: 5,
      },
      count: {
        type: Number,
        default: 0,
      },
      distribution: {
        1: { type: Number, default: 0 },
        2: { type: Number, default: 0 },
        3: { type: Number, default: 0 },
        4: { type: Number, default: 0 },
        5: { type: Number, default: 0 },
      },
    },
    analytics: {
      views: {
        type: Number,
        default: 0,
      },
      clicks: {
        type: Number,
        default: 0,
      },
      purchases: {
        type: Number,
        default: 0,
      },
      conversionRate: {
        type: Number,
        default: 0,
      },
      revenue: {
        type: Number,
        default: 0,
      },
    },
    shipping: {
      weight: Number,
      dimensions: {
        length: Number,
        width: Number,
        height: Number,
      },
      freeShipping: {
        type: Boolean,
        default: false,
      },
      shippingClass: String,
    },
    status: {
      type: String,
      enum: ['DRAFT', 'ACTIVE', 'ARCHIVED', 'OUT_OF_STOCK'],
      default: 'DRAFT',
    },
    featured: {
      type: Boolean,
      default: false,
    },
    trending: {
      type: Boolean,
      default: false,
    },
    newArrival: {
      type: Boolean,
      default: false,
    },
    vendorId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
    },
    tags: [String],
    publishedAt: Date,
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

// Indexes for performance
productSchema.index({ slug: 1 });
productSchema.index({ sku: 1 });
productSchema.index({ categoryId: 1, 'pricing.currentPrice': 1 });
productSchema.index({ categoryId: 1, 'rating.average': -1 });
productSchema.index({ brandId: 1 });
productSchema.index({ status: 1, featured: 1 });
productSchema.index({ 'pricing.currentPrice': 1 });
productSchema.index({ 'rating.average': -1 });
productSchema.index({ createdAt: -1 });
productSchema.index({ trending: 1, 'rating.average': -1 }, { sparse: true });

// Text index for search
productSchema.index({ name: 'text', description: 'text', tags: 'text' });

// Compound index for common queries
productSchema.index({
  categoryId: 1,
  'pricing.currentPrice': 1,
  'rating.average': -1,
  status: 1,
});

// Virtual for discount percentage
productSchema.virtual('discountPercentage').get(function () {
  if (this.pricing.basePrice && this.pricing.currentPrice) {
    return Math.round(
      ((this.pricing.basePrice - this.pricing.currentPrice) /
        this.pricing.basePrice) *
        100
    );
  }
  return 0;
});

// Virtual for low stock status
productSchema.virtual('isLowStock').get(function () {
  return (
    this.inventory.quantity > 0 &&
    this.inventory.quantity <= this.inventory.lowStockThreshold
  );
});

// Virtual for profit margin
productSchema.virtual('profitMargin').get(function () {
  if (this.pricing.costPrice && this.pricing.currentPrice) {
    return (
      ((this.pricing.currentPrice - this.pricing.costPrice) /
        this.pricing.currentPrice) *
      100
    );
  }
  return 0;
});

// Pre-save middleware: Generate slug
productSchema.pre('save', function (next) {
  if (this.isModified('name') && !this.slug) {
    this.slug = slugify(this.name, {
      lower: true,
      strict: true,
    });
  }
  next();
});

// Pre-save middleware: Update inventory status
productSchema.pre('save', function (next) {
  if (this.isModified('inventory.quantity')) {
    this.inventory.inStock = this.inventory.quantity > 0;
    
    // Auto-update status based on inventory
    if (this.inventory.quantity === 0 && this.status === 'ACTIVE') {
      this.status = 'OUT_OF_STOCK';
    } else if (this.inventory.quantity > 0 && this.status === 'OUT_OF_STOCK') {
      this.status = 'ACTIVE';
    }
  }
  next();
});

// Pre-save middleware: Ensure only one primary image
productSchema.pre('save', function (next) {
  if (this.isModified('images')) {
    const primaryImages = this.images.filter((img) => img.isPrimary);
    if (primaryImages.length > 1) {
      // Keep only the first one as primary
      this.images.forEach((img, index) => {
        img.isPrimary = index === 0;
      });
    } else if (primaryImages.length === 0 && this.images.length > 0) {
      // Set first image as primary if none is set
      this.images[0].isPrimary = true;
    }
  }
  next();
});

// Pre-save middleware: Calculate current price from discount
productSchema.pre('save', function (next) {
  if (this.pricing.discount && this.pricing.discount.value) {
    const now = new Date();
    const discountActive =
      (!this.pricing.discount.startDate ||
        this.pricing.discount.startDate <= now) &&
      (!this.pricing.discount.endDate || this.pricing.discount.endDate >= now);

    if (discountActive) {
      if (this.pricing.discount.type === 'PERCENTAGE') {
        this.pricing.currentPrice =
          this.pricing.basePrice *
          (1 - this.pricing.discount.value / 100);
      } else if (this.pricing.discount.type === 'FIXED') {
        this.pricing.currentPrice =
          this.pricing.basePrice - this.pricing.discount.value;
      }
      this.pricing.currentPrice = Math.max(0, this.pricing.currentPrice);
    } else {
      this.pricing.currentPrice = this.pricing.basePrice;
    }
  }
  next();
});

// Method: Update rating
productSchema.methods.updateRating = async function (newRating, oldRating = null) {
  if (oldRating !== null) {
    // Update existing review
    this.rating.distribution[oldRating]--;
    this.rating.distribution[newRating]++;
  } else {
    // New review
    this.rating.distribution[newRating]++;
    this.rating.count++;
  }

  // Calculate new average
  let totalRating = 0;
  for (let i = 1; i <= 5; i++) {
    totalRating += i * this.rating.distribution[i];
  }

  this.rating.average = this.rating.count > 0 
    ? totalRating / this.rating.count 
    : 0;

  return this.save();
};

// Method: Increment view count
productSchema.methods.incrementViews = async function () {
  this.analytics.views++;
  return this.save();
};

// Method: Record purchase
productSchema.methods.recordPurchase = async function (quantity, amount) {
  this.analytics.purchases++;
  this.analytics.revenue += amount;
  this.analytics.conversionRate =
    this.analytics.views > 0
      ? (this.analytics.purchases / this.analytics.views) * 100
      : 0;
  
  // Decrease inventory
  this.inventory.quantity -= quantity;
  
  return this.save();
};

// Static method: Search products
productSchema.statics.searchProducts = async function (query, options = {}) {
  const {
    page = 1,
    limit = 20,
    sortBy = 'createdAt',
    sortOrder = 'desc',
    filters = {},
  } = options;

  const searchQuery = {
    status: 'ACTIVE',
    ...filters,
  };

  if (query) {
    searchQuery.$text = { $search: query };
  }

  const sort = { [sortBy]: sortOrder === 'desc' ? -1 : 1 };

  const products = await this.find(searchQuery)
    .sort(sort)
    .limit(limit)
    .skip((page - 1) * limit)
    .populate('categoryId', 'name slug')
    .populate('brandId', 'name')
    .lean();

  const total = await this.countDocuments(searchQuery);

  return {
    products,
    pagination: {
      total,
      page,
      pages: Math.ceil(total / limit),
      limit,
    },
  };
};

// Plugin
productSchema.plugin(mongoosePaginate);

const Product = mongoose.model('Product', productSchema);

module.exports = Product;
