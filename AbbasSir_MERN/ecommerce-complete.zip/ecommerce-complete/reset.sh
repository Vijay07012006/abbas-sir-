#!/bin/bash

# Reset E-Commerce Platform (Fresh Start)

clear
echo "=================================="
echo "🔄 Resetting E-Commerce Platform..."
echo "=================================="
echo ""

RED='\033[0;31m'
YELLOW='\033[1;33m'
GREEN='\033[0;32m'
NC='\033[0m'

echo -e "${RED}⚠️  WARNING: Ye sab data delete kar dega!${NC}"
echo ""
read -p "Continue kare? (y/n): " -n 1 -r
echo ""

if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Reset cancelled."
    exit 0
fi

# Check if running with sudo
if ! docker ps &> /dev/null; then
    USE_SUDO="sudo"
fi

echo ""
echo -e "${YELLOW}Stopping containers...${NC}"
$USE_SUDO docker-compose down -v

echo ""
echo -e "${YELLOW}Removing old data...${NC}"
$USE_SUDO docker system prune -f

echo ""
echo -e "${GREEN}✅ Reset complete!${NC}"
echo ""
echo "Ab fresh start karo: ./start.sh"
echo ""
