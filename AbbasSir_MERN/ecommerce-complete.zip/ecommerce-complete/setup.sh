#!/bin/bash

# E-Commerce Platform Setup Script
# This script will set up the entire platform

set -e  # Exit on error

echo "🚀 E-Commerce Platform Setup"
echo "=============================="
echo ""

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if running with sudo for docker
check_docker_permission() {
    if ! docker ps &> /dev/null; then
        echo -e "${YELLOW}⚠️  Docker requires elevated permissions${NC}"
        echo "Please run: sudo usermod -aG docker $USER"
        echo "Then log out and log back in"
        echo ""
        echo "Or run this script with sudo"
        return 1
    fi
    return 0
}

# Check prerequisites
echo "📋 Checking prerequisites..."

# Check Node.js
if ! command -v node &> /dev/null; then
    echo -e "${RED}❌ Node.js is not installed${NC}"
    echo "Please install Node.js 20+ from https://nodejs.org/"
    exit 1
else
    NODE_VERSION=$(node --version)
    echo -e "${GREEN}✅ Node.js installed: $NODE_VERSION${NC}"
fi

# Check npm
if ! command -v npm &> /dev/null; then
    echo -e "${RED}❌ npm is not installed${NC}"
    exit 1
else
    NPM_VERSION=$(npm --version)
    echo -e "${GREEN}✅ npm installed: $NPM_VERSION${NC}"
fi

# Check Docker
if ! command -v docker &> /dev/null; then
    echo -e "${YELLOW}⚠️  Docker is not installed (optional but recommended)${NC}"
    echo "Install from: https://docs.docker.com/get-docker/"
    DOCKER_AVAILABLE=false
else
    echo -e "${GREEN}✅ Docker installed${NC}"
    DOCKER_AVAILABLE=true
fi

echo ""
echo "📦 Choose setup method:"
echo "1) Docker (Recommended - includes MongoDB & Redis)"
echo "2) Manual (Install dependencies manually)"
read -p "Enter choice (1 or 2): " SETUP_CHOICE

if [ "$SETUP_CHOICE" = "1" ]; then
    if [ "$DOCKER_AVAILABLE" = false ]; then
        echo -e "${RED}❌ Docker is not installed${NC}"
        echo "Please install Docker or choose manual setup (option 2)"
        exit 1
    fi
    
    echo ""
    echo "🐳 Setting up with Docker..."
    
    # Check docker permissions
    if ! check_docker_permission; then
        echo ""
        echo "Attempting with sudo..."
        sudo docker-compose up -d
    else
        docker-compose up -d
    fi
    
    echo ""
    echo -e "${GREEN}✅ Docker containers started!${NC}"
    echo ""
    echo "Services running:"
    echo "  - Frontend: http://localhost:3000"
    echo "  - Backend:  http://localhost:5000"
    echo "  - MongoDB:  localhost:27017"
    echo "  - Redis:    localhost:6379"
    echo ""
    echo "To view logs: docker-compose logs -f"
    echo "To stop: docker-compose down"
    
else
    echo ""
    echo "🔧 Manual setup selected..."
    echo ""
    
    # Backend setup
    echo "📦 Installing backend dependencies..."
    cd backend
    
    if [ ! -f ".env" ]; then
        echo "Creating .env file..."
        cp .env.example .env
        echo -e "${YELLOW}⚠️  Please edit backend/.env with your configuration${NC}"
    fi
    
    npm install
    cd ..
    
    echo ""
    echo "📦 Installing frontend dependencies..."
    cd frontend
    
    if [ ! -f ".env.local" ]; then
        echo "Creating .env.local file..."
        cp .env.example .env.local
        echo -e "${YELLOW}⚠️  Please edit frontend/.env.local with your configuration${NC}"
    fi
    
    npm install
    cd ..
    
    echo ""
    echo -e "${GREEN}✅ Dependencies installed!${NC}"
    echo ""
    echo "⚠️  Before starting, ensure you have:"
    echo "  1. MongoDB running on localhost:27017"
    echo "  2. Redis running on localhost:6379"
    echo ""
    echo "To install MongoDB:"
    echo "  Ubuntu/Debian: sudo apt install mongodb"
    echo "  macOS: brew install mongodb-community"
    echo ""
    echo "To install Redis:"
    echo "  Ubuntu/Debian: sudo apt install redis-server"
    echo "  macOS: brew install redis"
    echo ""
    echo "To start the application:"
    echo "  1. Start MongoDB: mongod"
    echo "  2. Start Redis: redis-server"
    echo "  3. Start Backend: cd backend && npm run dev"
    echo "  4. Start Frontend: cd frontend && npm run dev"
    echo ""
    echo "Or use the provided start scripts:"
    echo "  ./start-backend.sh"
    echo "  ./start-frontend.sh"
fi

echo ""
echo -e "${GREEN}🎉 Setup complete!${NC}"
echo ""
echo "📚 Next steps:"
echo "  1. Read QUICK_START.md for detailed instructions"
echo "  2. Read ARCHITECTURE.md to understand the system"
echo "  3. Read API_DOCUMENTATION.md for API reference"
echo ""
echo "Need help? Check the documentation or run: cat QUICK_START.md"
