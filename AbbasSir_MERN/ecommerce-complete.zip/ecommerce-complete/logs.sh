#!/bin/bash

# View E-Commerce Platform Logs

clear
echo "=================================="
echo "📋 E-Commerce Platform Logs"
echo "=================================="
echo ""
echo "Press Ctrl+C to stop viewing logs"
echo ""
sleep 2

# Check if running with sudo
if ! docker ps &> /dev/null; then
    USE_SUDO="sudo"
fi

# Show logs
$USE_SUDO docker-compose logs -f --tail=100
