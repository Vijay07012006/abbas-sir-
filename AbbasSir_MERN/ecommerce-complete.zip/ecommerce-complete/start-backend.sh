#!/bin/bash

# Start Backend Server
echo "🚀 Starting Backend Server..."

cd backend

# Check if .env exists
if [ ! -f ".env" ]; then
    echo "⚠️  .env file not found. Creating from template..."
    cp .env.example .env
    echo "Please edit backend/.env with your configuration"
    exit 1
fi

# Check if node_modules exists
if [ ! -d "node_modules" ]; then
    echo "📦 Installing dependencies..."
    npm install
fi

# Start the server
echo "Starting server on port 5000..."
npm run dev
