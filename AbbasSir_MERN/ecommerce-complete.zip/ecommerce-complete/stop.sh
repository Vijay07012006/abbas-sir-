#!/bin/bash

# Stop E-Commerce Platform

clear
echo "=================================="
echo "🛑 Stopping E-Commerce Platform..."
echo "=================================="
echo ""

# Check if running with sudo
if ! docker ps &> /dev/null; then
    USE_SUDO="sudo"
fi

# Stop containers
$USE_SUDO docker-compose down

echo ""
echo "✅ All services stopped!"
echo ""
echo "Start karne ke liye run karo: ./start.sh"
echo ""
