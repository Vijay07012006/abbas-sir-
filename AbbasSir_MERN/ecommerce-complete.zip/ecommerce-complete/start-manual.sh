#!/bin/bash

# Manual Start (Without Docker)

clear
echo "=================================="
echo "🚀 Starting Without Docker..."
echo "=================================="
echo ""

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Check MongoDB
if ! systemctl is-active --quiet mongodb; then
    echo -e "${YELLOW}Starting MongoDB...${NC}"
    sudo systemctl start mongodb
fi

# Check Redis
if ! systemctl is-active --quiet redis-server; then
    echo -e "${YELLOW}Starting Redis...${NC}"
    sudo systemctl start redis-server
fi

# Check if dependencies are installed
if [ ! -d "backend/node_modules" ]; then
    echo ""
    echo -e "${YELLOW}📦 Installing backend dependencies...${NC}"
    cd backend && npm install && cd ..
fi

if [ ! -d "frontend/node_modules" ]; then
    echo ""
    echo -e "${YELLOW}📦 Installing frontend dependencies...${NC}"
    cd frontend && npm install && cd ..
fi

# Create .env files if not exist
if [ ! -f "backend/.env" ]; then
    echo -e "${YELLOW}Creating backend .env...${NC}"
    cp backend/.env.example backend/.env
fi

if [ ! -f "frontend/.env.local" ]; then
    echo -e "${YELLOW}Creating frontend .env.local...${NC}"
    cp frontend/.env.example frontend/.env.local
fi

echo ""
echo -e "${GREEN}✅ Setup Complete!${NC}"
echo ""
echo -e "${YELLOW}Ab 2 terminal windows open karo:${NC}"
echo ""
echo -e "${GREEN}Terminal 1 (Backend):${NC}"
echo "  cd backend && npm run dev"
echo ""
echo -e "${GREEN}Terminal 2 (Frontend):${NC}"
echo "  cd frontend && npm run dev"
echo ""
echo "Ya phir tmux/screen use karo:"
echo ""
echo "# Backend start karo"
echo "cd backend && npm run dev &"
echo ""
echo "# Frontend start karo"
echo "cd frontend && npm run dev"
echo ""
