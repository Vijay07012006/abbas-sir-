# Database Schema Design

## Overview

This document defines the MongoDB schema design for the e-commerce platform, optimized for scalability, performance, and data integrity.

## Design Principles

1. **Embedding vs Referencing:** Embed for one-to-few, reference for one-to-many
2. **Denormalization:** Strategic duplication for read performance
3. **Indexing:** Cover frequent query patterns
4. **Sharding:** Partition data for horizontal scaling

## Collections & Schemas

### 1. Users Collection

```javascript
{
  _id: ObjectId,
  email: String,                    // Unique, indexed
  password: String,                 // bcrypt hashed
  firstName: String,
  lastName: String,
  phone: {
    countryCode: String,
    number: String
  },
  role: String,                     // CUSTOMER, ADMIN, VENDOR
  permissions: [String],            // Array of permission strings
  
  // Address embedded (one-to-few relationship)
  addresses: [{
    _id: ObjectId,
    type: String,                   // HOME, WORK, OTHER
    street: String,
    city: String,
    state: String,
    country: String,
    postalCode: String,
    isDefault: Boolean
  }],
  
  // Profile information
  avatar: String,                   // S3 URL
  dateOfBirth: Date,
  gender: String,
  
  // Preferences
  preferences: {
    newsletter: Boolean,
    notifications: {
      email: Boolean,
      sms: Boolean,
      push: Boolean
    },
    language: String,
    currency: String
  },
  
  // Wishlists (referenced for scalability)
  wishlistIds: [ObjectId],          // Reference to Wishlist collection
  
  // Account status
  isEmailVerified: Boolean,
  isPhoneVerified: Boolean,
  isActive: Boolean,
  isSuspended: Boolean,
  
  // Security
  refreshTokens: [{
    token: String,                  // Hashed
    deviceId: String,
    deviceInfo: String,
    createdAt: Date,
    expiresAt: Date
  }],
  passwordResetToken: String,
  passwordResetExpires: Date,
  loginAttempts: Number,
  lockUntil: Date,
  
  // Timestamps
  createdAt: Date,
  updatedAt: Date,
  lastLoginAt: Date
}

// Indexes
db.users.createIndex({ email: 1 }, { unique: true })
db.users.createIndex({ phone: 1 }, { sparse: true })
db.users.createIndex({ role: 1 })
db.users.createIndex({ createdAt: -1 })
db.users.createIndex({ "refreshTokens.token": 1 }, { sparse: true })
```

### 2. Products Collection

```javascript
{
  _id: ObjectId,
  
  // Basic Information
  name: String,                     // Indexed for text search
  slug: String,                     // Unique, URL-friendly
  sku: String,                      // Stock Keeping Unit, unique
  description: String,              // Indexed for text search
  shortDescription: String,
  
  // Categorization
  categoryId: ObjectId,             // Reference to Category
  categoryPath: String,             // "Electronics > Phones > Smartphones"
  brandId: ObjectId,                // Reference to Brand
  brandName: String,                // Denormalized for performance
  
  // Pricing
  pricing: {
    basePrice: Number,              // Original price
    currentPrice: Number,           // After discounts
    currency: String,               // USD, EUR, INR
    discount: {
      type: String,                 // PERCENTAGE, FIXED
      value: Number,
      startDate: Date,
      endDate: Date
    },
    costPrice: Number,              // For profit calculation
    compareAtPrice: Number          // "Was $199, Now $149"
  },
  
  // Inventory
  inventory: {
    quantity: Number,               // Current stock
    lowStockThreshold: Number,
    inStock: Boolean,               // Calculated field
    backorder: Boolean,
    restockDate: Date,
    sku: String,
    warehouse: String
  },
  
  // Media
  images: [{
    url: String,                    // CDN URL
    alt: String,
    isPrimary: Boolean,
    order: Number
  }],
  videos: [{
    url: String,
    thumbnail: String,
    duration: Number
  }],
  
  // Specifications (flexible schema)
  specifications: {
    dimensions: {
      length: Number,
      width: Number,
      height: Number,
      unit: String
    },
    weight: {
      value: Number,
      unit: String
    },
    color: String,
    size: String,
    material: String,
    // ... other product-specific attributes
    custom: Map                     // For category-specific specs
  },
  
  // Variants (for products with options)
  hasVariants: Boolean,
  parentProductId: ObjectId,        // If this is a variant
  variantOptions: [{
    name: String,                   // Color, Size, Material
    value: String                   // Red, Large, Cotton
  }],
  
  // SEO
  seo: {
    metaTitle: String,
    metaDescription: String,
    metaKeywords: [String],
    ogImage: String
  },
  
  // Reviews & Ratings (denormalized for performance)
  rating: {
    average: Number,                // 0-5, indexed
    count: Number,
    distribution: {
      1: Number,                    // Count of 1-star reviews
      2: Number,
      3: Number,
      4: Number,
      5: Number
    }
  },
  
  // Analytics
  analytics: {
    views: Number,
    clicks: Number,
    purchases: Number,
    conversionRate: Number,
    revenue: Number
  },
  
  // Shipping
  shipping: {
    weight: Number,
    dimensions: {
      length: Number,
      width: Number,
      height: Number
    },
    freeShipping: Boolean,
    shippingClass: String
  },
  
  // Status
  status: String,                   // DRAFT, ACTIVE, ARCHIVED, OUT_OF_STOCK
  featured: Boolean,                // Featured on homepage
  trending: Boolean,
  newArrival: Boolean,
  
  // Vendor (for marketplace model)
  vendorId: ObjectId,
  
  // Tags
  tags: [String],                   // For filtering and search
  
  // Timestamps
  createdAt: Date,
  updatedAt: Date,
  publishedAt: Date
}

// Indexes
db.products.createIndex({ slug: 1 }, { unique: true })
db.products.createIndex({ sku: 1 }, { unique: true })
db.products.createIndex({ categoryId: 1, "pricing.currentPrice": 1 })
db.products.createIndex({ categoryId: 1, "rating.average": -1 })
db.products.createIndex({ brandId: 1 })
db.products.createIndex({ status: 1, featured: 1 })
db.products.createIndex({ "pricing.currentPrice": 1 })
db.products.createIndex({ "rating.average": -1 })
db.products.createIndex({ createdAt: -1 })
db.products.createIndex({ name: "text", description: "text", tags: "text" })
db.products.createIndex({ trending: 1, "rating.average": -1 }, { sparse: true })

// Compound index for common query patterns
db.products.createIndex({
  categoryId: 1,
  "pricing.currentPrice": 1,
  "rating.average": -1,
  status: 1
})
```

### 3. Categories Collection

```javascript
{
  _id: ObjectId,
  name: String,
  slug: String,                     // Unique
  description: String,
  
  // Hierarchy
  parentId: ObjectId,               // null for root categories
  level: Number,                    // 0 for root, 1 for subcategory, etc.
  path: String,                     // "electronics/phones/smartphones"
  ancestors: [ObjectId],            // Array of parent IDs
  
  // Display
  icon: String,                     // Icon class or SVG
  image: String,                    // Category banner
  color: String,                    // For UI theming
  order: Number,                    // Display order
  
  // SEO
  seo: {
    metaTitle: String,
    metaDescription: String,
    keywords: [String]
  },
  
  // Status
  isActive: Boolean,
  showInMenu: Boolean,
  
  // Statistics (denormalized)
  productCount: Number,
  
  createdAt: Date,
  updatedAt: Date
}

// Indexes
db.categories.createIndex({ slug: 1 }, { unique: true })
db.categories.createIndex({ parentId: 1 })
db.categories.createIndex({ path: 1 })
db.categories.createIndex({ level: 1, order: 1 })
```

### 4. Orders Collection

```javascript
{
  _id: ObjectId,
  orderNumber: String,              // Human-readable, unique (ORD-2024-001234)
  
  // Customer Information
  userId: ObjectId,                 // Reference to User
  customerEmail: String,            // Denormalized for quick access
  customerName: String,
  
  // Order Items
  items: [{
    _id: ObjectId,
    productId: ObjectId,
    productName: String,            // Snapshot at time of order
    productImage: String,
    sku: String,
    quantity: Number,
    price: Number,                  // Price at time of purchase
    discount: Number,
    tax: Number,
    total: Number,                  // (price - discount + tax) * quantity
    
    // Variant information if applicable
    variantOptions: [{
      name: String,
      value: String
    }]
  }],
  
  // Pricing Summary
  pricing: {
    subtotal: Number,               // Sum of items before tax
    discount: Number,               // Total discounts applied
    tax: Number,                    // Total tax
    shippingCost: Number,
    total: Number,                  // Final amount
    currency: String
  },
  
  // Coupon/Discount
  coupon: {
    code: String,
    discountType: String,           // PERCENTAGE, FIXED
    discountValue: Number,
    appliedAmount: Number
  },
  
  // Shipping Information
  shippingAddress: {
    firstName: String,
    lastName: String,
    email: String,
    phone: String,
    street: String,
    apartment: String,
    city: String,
    state: String,
    country: String,
    postalCode: String
  },
  
  billingAddress: {
    // Same structure as shippingAddress
    // Or reference to shippingAddress if same
    sameAsShipping: Boolean
  },
  
  // Shipping Details
  shipping: {
    method: String,                 // STANDARD, EXPRESS, OVERNIGHT
    carrier: String,                // FedEx, UPS, USPS
    trackingNumber: String,
    estimatedDelivery: Date,
    shippedAt: Date,
    deliveredAt: Date
  },
  
  // Payment Information
  payment: {
    method: String,                 // CARD, UPI, WALLET, COD
    provider: String,               // Stripe, Razorpay
    transactionId: String,
    status: String,                 // PENDING, PROCESSING, COMPLETED, FAILED, REFUNDED
    paidAt: Date,
    
    // Card info (last 4 digits only)
    cardLast4: String,
    cardBrand: String
  },
  
  // Order Status State Machine
  status: String,                   // PENDING, CONFIRMED, PROCESSING, SHIPPED, DELIVERED, CANCELLED
  statusHistory: [{
    status: String,
    timestamp: Date,
    note: String,
    updatedBy: ObjectId             // Admin/System user
  }],
  
  // Fulfillment
  fulfillment: {
    warehouse: String,
    pickedAt: Date,
    packedAt: Date,
    shippedAt: Date,
    deliveredAt: Date,
    pickedBy: ObjectId,
    packedBy: ObjectId
  },
  
  // Notes
  customerNotes: String,            // Special instructions
  internalNotes: String,            // Admin notes
  
  // Cancellation/Return
  cancellation: {
    isCancelled: Boolean,
    cancelledAt: Date,
    cancelledBy: ObjectId,
    reason: String,
    refundStatus: String,
    refundedAmount: Number
  },
  
  // Analytics
  source: String,                   // WEB, MOBILE_APP, PHONE
  utmParams: {
    source: String,
    medium: String,
    campaign: String
  },
  
  // Timestamps
  createdAt: Date,
  updatedAt: Date,
  confirmedAt: Date,
  completedAt: Date
}

// Indexes
db.orders.createIndex({ orderNumber: 1 }, { unique: true })
db.orders.createIndex({ userId: 1, createdAt: -1 })
db.orders.createIndex({ status: 1, createdAt: -1 })
db.orders.createIndex({ "payment.transactionId": 1 }, { sparse: true })
db.orders.createIndex({ "payment.status": 1 })
db.orders.createIndex({ createdAt: -1 })
db.orders.createIndex({ customerEmail: 1 })
```

### 5. Reviews Collection

```javascript
{
  _id: ObjectId,
  productId: ObjectId,              // Reference to Product
  userId: ObjectId,                 // Reference to User
  orderId: ObjectId,                // Verified purchase
  
  // Review Content
  rating: Number,                   // 1-5
  title: String,
  comment: String,
  
  // Media
  images: [String],                 // Review images
  videos: [String],
  
  // Metadata
  userName: String,                 // Denormalized for display
  userAvatar: String,
  verifiedPurchase: Boolean,
  
  // Helpful votes
  helpful: {
    count: Number,
    users: [ObjectId]               // Users who found it helpful
  },
  
  // Moderation
  status: String,                   // PENDING, APPROVED, REJECTED
  moderatedBy: ObjectId,
  moderatedAt: Date,
  rejectionReason: String,
  
  // Response from vendor/seller
  response: {
    comment: String,
    respondedBy: ObjectId,
    respondedAt: Date
  },
  
  createdAt: Date,
  updatedAt: Date
}

// Indexes
db.reviews.createIndex({ productId: 1, createdAt: -1 })
db.reviews.createIndex({ userId: 1 })
db.reviews.createIndex({ rating: 1 })
db.reviews.createIndex({ status: 1 })
db.reviews.createIndex({ productId: 1, rating: -1 })
```

### 6. Cart Collection

```javascript
{
  _id: ObjectId,
  userId: ObjectId,                 // null for guest carts
  sessionId: String,                // For guest carts
  
  items: [{
    _id: ObjectId,
    productId: ObjectId,
    productName: String,            // Cached for performance
    productImage: String,
    sku: String,
    quantity: Number,
    price: Number,                  // Current price
    
    // Variant selection
    variantOptions: [{
      name: String,
      value: String
    }],
    
    // Availability check
    inStock: Boolean,
    maxQuantity: Number,
    
    addedAt: Date
  }],
  
  // Pricing summary (calculated)
  summary: {
    subtotal: Number,
    discount: Number,
    estimatedTax: Number,
    estimatedTotal: Number
  },
  
  // Applied coupons
  appliedCoupons: [{
    code: String,
    discountAmount: Number
  }],
  
  // Metadata
  lastModified: Date,
  expiresAt: Date,                  // Auto-delete old carts
  createdAt: Date,
  updatedAt: Date
}

// Indexes
db.carts.createIndex({ userId: 1 }, { unique: true, sparse: true })
db.carts.createIndex({ sessionId: 1 }, { unique: true, sparse: true })
db.carts.createIndex({ expiresAt: 1 }, { expireAfterSeconds: 0 }) // TTL index
```

### 7. Payments Collection

```javascript
{
  _id: ObjectId,
  orderId: ObjectId,
  userId: ObjectId,
  
  // Payment details
  amount: Number,
  currency: String,
  
  // Provider information
  provider: String,                 // STRIPE, RAZORPAY, PAYPAL
  providerTransactionId: String,
  providerPaymentMethodId: String,
  
  // Payment method
  method: String,                   // CARD, UPI, WALLET, NETBANKING
  methodDetails: {
    cardLast4: String,
    cardBrand: String,
    walletType: String,
    upiId: String
  },
  
  // Status
  status: String,                   // PENDING, PROCESSING, SUCCEEDED, FAILED, REFUNDED
  
  // Webhook data
  webhookReceived: Boolean,
  webhookData: Object,              // Raw webhook payload
  
  // Refund information
  refund: {
    amount: Number,
    reason: String,
    status: String,
    refundedAt: Date,
    refundTransactionId: String
  },
  
  // Timestamps
  initiatedAt: Date,
  completedAt: Date,
  failedAt: Date,
  createdAt: Date,
  updatedAt: Date
}

// Indexes
db.payments.createIndex({ orderId: 1 })
db.payments.createIndex({ userId: 1, createdAt: -1 })
db.payments.createIndex({ providerTransactionId: 1 })
db.payments.createIndex({ status: 1 })
```

### 8. Inventory Collection

```javascript
{
  _id: ObjectId,
  productId: ObjectId,
  sku: String,
  
  // Stock information
  quantity: Number,
  reserved: Number,                 // Reserved for pending orders
  available: Number,                // quantity - reserved
  
  // Warehouse information
  warehouse: {
    id: String,
    name: String,
    location: String
  },
  
  // Restocking
  lowStockThreshold: Number,
  restockAlert: Boolean,
  supplier: String,
  reorderQuantity: Number,
  
  // Movement tracking
  movements: [{
    type: String,                   // IN, OUT, ADJUSTMENT, RETURN
    quantity: Number,
    reason: String,
    reference: String,              // Order ID, PO number, etc.
    performedBy: ObjectId,
    timestamp: Date
  }],
  
  lastStockCheck: Date,
  createdAt: Date,
  updatedAt: Date
}

// Indexes
db.inventory.createIndex({ productId: 1, warehouse: 1 }, { unique: true })
db.inventory.createIndex({ sku: 1 })
db.inventory.createIndex({ available: 1 })
```

## Relationships Diagram

```
Users (1) ─────────── (M) Orders
  │                        │
  │                        │
  └─────── (M) Reviews     │
               │           │
               │           │
Products (1) ──┴───────────┤
  │                        │
  │                        │
  ├─────── (1) Inventory   │
  │                        │
  │                        │
  └─────── (M) Cart Items  │
                           │
Categories (1) ── (M) Products
                           │
Payments (1) ──────────────┘
```

## Sharding Strategy

### Shard Key Selection

**Users Collection:**
- Shard Key: `_id` (default)
- Rationale: Evenly distributed, most queries include userId

**Products Collection:**
- Shard Key: `categoryId` + `_id`
- Rationale: Products within same category often queried together

**Orders Collection:**
- Shard Key: `userId` + `createdAt` (range-based)
- Rationale: User-centric queries, time-based partitioning

**Reviews Collection:**
- Shard Key: `productId`
- Rationale: Reviews queried by product

## Data Retention Policy

```
Collection     | Retention Period  | Archive Strategy
---------------|-------------------|------------------
Users          | Indefinite        | Soft delete + GDPR compliance
Products       | Indefinite        | Archive to cold storage after deletion
Orders         | 7 years           | Move to archive collection
Reviews        | Indefinite        | Keep for historical data
Cart           | 90 days           | TTL index auto-deletion
Payments       | 7 years           | Compliance requirement
Inventory      | 2 years           | Historical data to analytics DB
```

## Performance Considerations

1. **Denormalization:** Product name, image in orders for historical accuracy
2. **Embedding:** Addresses, order items (bounded arrays)
3. **Indexing:** Cover 80% of queries with compound indexes
4. **Projection:** Always specify fields to return
5. **Aggregation:** Use for complex analytics, cache results
