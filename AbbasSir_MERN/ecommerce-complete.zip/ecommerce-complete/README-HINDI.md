# 🚀 E-Commerce Platform - Complete Setup

## आसान Setup (बस 3 Commands!)

### तरीका 1: Docker से (सबसे आसान - Recommended)

```bash
# 1. Project extract karo
unzip ecommerce-complete.zip
cd ecommerce-complete

# 2. Docker permission fix karo (पहली बार सिर्फ एक बार)
sudo usermod -aG docker $USER
newgrp docker

# 3. Bas start karo!
./start.sh
```

**बस इतना ही! आपका project चालू हो गया:**
- Frontend: http://localhost:3000
- Backend: http://localhost:5000

---

### तरीका 2: Manual Setup (बिना Docker के)

```bash
# 1. MongoDB install karo
sudo apt update
sudo apt install -y mongodb redis-server

# 2. Services start karo
sudo systemctl start mongodb redis-server

# 3. Project start karo
./start-manual.sh
```

---

## 🎯 Project को देखने के लिए

**Browser में खोलो:**
- http://localhost:3000 - Frontend
- http://localhost:5000/health - Backend Check

---

## 📱 Test User Login

```
Email: admin@example.com
Password: Admin123!
```

---

## ⚡ Important Commands

```bash
# Project start karo
./start.sh

# Project stop karo
./stop.sh

# Logs dekho
./logs.sh

# Reset everything
./reset.sh
```

---

## 🐛 Problem हो तो

### Docker permission error:
```bash
sudo usermod -aG docker $USER
newgrp docker
```

### Port already in use:
```bash
./stop.sh
./start.sh
```

### Sab kuch reset karna hai:
```bash
./reset.sh
./start.sh
```

---

## 📂 Project Structure

```
ecommerce-complete/
├── start.sh          ← Isse project start hoga
├── stop.sh           ← Project band karne ke liye
├── logs.sh           ← Logs dekhne ke liye
├── reset.sh          ← Sab kuch fresh karne ke liye
├── backend/          ← Backend code
├── frontend/         ← Frontend code
└── docker-compose.yml ← Docker configuration
```

---

## 🆘 Help

Problem ho to:
1. TROUBLESHOOTING.md padho
2. QUICK_START.md padho
3. ./logs.sh run karke error dekho

---

## ✅ Features

- ✅ Complete E-Commerce Platform
- ✅ User Authentication
- ✅ Product Management
- ✅ Shopping Cart
- ✅ Order Management
- ✅ Admin Dashboard
- ✅ Payment Integration Ready
- ✅ Mobile Responsive
- ✅ Production Ready

---

**Made with ❤️ - Enterprise Grade E-Commerce Platform**
