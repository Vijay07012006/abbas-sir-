# Quick Start Guide

Get your enterprise e-commerce platform up and running in minutes.

## 🚀 Prerequisites Check

Before starting, ensure you have:

```bash
# Check Node.js version (must be >= 20)
node --version

# Check npm version (must be >= 10)
npm --version

# Check Docker (optional but recommended)
docker --version
docker-compose --version
```

If you don't have these installed:
- **Node.js**: Download from [nodejs.org](https://nodejs.org/)
- **Docker**: Download from [docker.com](https://www.docker.com/)

## ⚡ Quick Start (Docker - Recommended)

The fastest way to get started is using Docker:

```bash
# 1. Navigate to project directory
cd ecommerce-platform

# 2. Start all services
docker-compose up -d

# 3. Wait for services to be ready (30-60 seconds)
docker-compose logs -f

# 4. Access the application
# Frontend: http://localhost:3000
# Backend API: http://localhost:5000
# MongoDB: localhost:27017
# Redis: localhost:6379
```

That's it! The platform is now running with:
- ✅ MongoDB database
- ✅ Redis cache
- ✅ Backend API
- ✅ Frontend application

## 🔧 Manual Setup (Without Docker)

### Step 1: Install Dependencies

**Backend:**
```bash
cd backend
npm install
```

**Frontend:**
```bash
cd ../frontend
npm install
```

### Step 2: Setup Databases

**MongoDB:**
```bash
# Install MongoDB (macOS)
brew tap mongodb/brew
brew install mongodb-community

# Start MongoDB
brew services start mongodb-community

# Or run manually
mongod --dbpath /path/to/data
```

**Redis:**
```bash
# Install Redis (macOS)
brew install redis

# Start Redis
brew services start redis

# Or run manually
redis-server
```

### Step 3: Configure Environment

**Backend:**
```bash
cd backend
cp .env.example .env

# Edit .env with your settings
nano .env
```

Required environment variables:
```env
MONGODB_URI=mongodb://localhost:27017/ecommerce
REDIS_HOST=localhost
REDIS_PORT=6379
JWT_SECRET=your-secret-key-here
JWT_REFRESH_SECRET=your-refresh-secret-here
```

**Frontend:**
```bash
cd frontend
cp .env.example .env.local

# Edit .env.local
nano .env.local
```

Required environment variables:
```env
NEXT_PUBLIC_API_URL=http://localhost:5000/api/v1
```

### Step 4: Start Services

**Backend (Terminal 1):**
```bash
cd backend
npm run dev
```

You should see:
```
Server running in development mode on port 5000
MongoDB Connected: localhost
Redis Connected
```

**Frontend (Terminal 2):**
```bash
cd frontend
npm run dev
```

You should see:
```
ready - started server on 0.0.0.0:3000
```

## 🎯 Testing the Installation

### 1. Health Check

```bash
# Backend health check
curl http://localhost:5000/health

# Expected response:
# {"status":"ok","timestamp":"...","uptime":123.45}
```

### 2. Create Admin User

```bash
# Register admin user
curl -X POST http://localhost:5000/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@example.com",
    "password": "Admin123!",
    "firstName": "Admin",
    "lastName": "User"
  }'
```

### 3. Login

```bash
# Login
curl -X POST http://localhost:5000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@example.com",
    "password": "Admin123!"
  }'

# Save the accessToken from response
```

### 4. Test Product API

```bash
# Get products
curl http://localhost:5000/api/v1/products

# Expected: {"success":true,"data":{"products":[],...}}
```

## 📚 Next Steps

### 1. Seed Sample Data

```bash
cd backend
npm run seed

# This will create:
# - Sample categories
# - Sample products
# - Sample users
```

### 2. Access the Frontend

Visit http://localhost:3000 in your browser:

- **Homepage**: Product catalog
- **Login**: http://localhost:3000/login
- **Register**: http://localhost:3000/register
- **Admin**: http://localhost:3000/admin (requires admin role)

### 3. Explore the API

**Using the Browser:**
- API Documentation: http://localhost:5000/api/v1/docs (if configured)

**Using Postman:**
1. Import the Postman collection from `/docs/postman`
2. Set environment variable `baseUrl` to `http://localhost:5000/api/v1`
3. Start testing endpoints

### 4. Development Workflow

**Making Changes:**

Backend:
- Edit files in `backend/src/`
- Server auto-restarts on file changes

Frontend:
- Edit files in `frontend/`
- Browser auto-refreshes on changes

**Viewing Logs:**

Backend:
```bash
# Terminal logs (with npm run dev)
# Or check log files
tail -f backend/logs/combined.log
```

Frontend:
```bash
# Terminal logs show Next.js compilation
# Browser console shows client-side logs
```

### 5. Database Management

**View MongoDB Data:**

```bash
# Connect to MongoDB shell
mongosh

# Use database
use ecommerce

# List collections
show collections

# View users
db.users.find().pretty()

# View products
db.products.find().pretty()
```

**View Redis Cache:**

```bash
# Connect to Redis CLI
redis-cli

# List all keys
KEYS *

# Get a value
GET "product:123"

# Clear all cache
FLUSHDB
```

## 🐛 Troubleshooting

### Backend won't start

**Issue:** "MongoDB connection failed"
```bash
# Check MongoDB is running
brew services list | grep mongodb

# Start if not running
brew services start mongodb-community

# Check connection
mongosh --eval "db.adminCommand('ping')"
```

**Issue:** "Redis connection failed"
```bash
# Check Redis is running
brew services list | grep redis

# Start if not running
brew services start redis

# Test connection
redis-cli ping
```

**Issue:** Port 5000 already in use
```bash
# Find process using port 5000
lsof -i :5000

# Kill the process
kill -9 <PID>

# Or change port in backend/.env
PORT=5001
```

### Frontend won't start

**Issue:** Port 3000 already in use
```bash
# Change port
PORT=3001 npm run dev

# Or in package.json
"dev": "next dev -p 3001"
```

**Issue:** "Cannot connect to API"
- Check backend is running on port 5000
- Verify `NEXT_PUBLIC_API_URL` in `.env.local`
- Check CORS settings in backend

### Docker Issues

**Issue:** "Cannot connect to Docker daemon"
```bash
# Start Docker Desktop
# Or start Docker service
sudo service docker start
```

**Issue:** Containers keep restarting
```bash
# Check logs
docker-compose logs backend

# Rebuild containers
docker-compose down
docker-compose up --build
```

**Issue:** "Port already allocated"
```bash
# Find conflicting containers
docker ps -a

# Stop all containers
docker-compose down

# Remove all containers
docker rm $(docker ps -a -q)
```

## 📖 Common Tasks

### Reset Database

```bash
# Using Docker
docker-compose down -v
docker-compose up -d

# Manual
mongosh
use ecommerce
db.dropDatabase()
```

### Clear Cache

```bash
# Using Docker
docker-compose exec redis redis-cli FLUSHDB

# Manual
redis-cli FLUSHDB
```

### Update Dependencies

```bash
# Backend
cd backend
npm update

# Frontend
cd frontend
npm update
```

### Run Tests

```bash
# Backend
cd backend
npm test

# Frontend
cd frontend
npm test
```

## 🎓 Learning Resources

- **Architecture**: Read [ARCHITECTURE.md](./ARCHITECTURE.md)
- **Database**: Read [DATABASE_SCHEMA.md](./DATABASE_SCHEMA.md)
- **API**: Read [API_DOCUMENTATION.md](./API_DOCUMENTATION.md)
- **Deployment**: Read [DEPLOYMENT.md](./DEPLOYMENT.md)
- **Structure**: Read [PROJECT_STRUCTURE.md](./PROJECT_STRUCTURE.md)

## 💡 Pro Tips

1. **Use MongoDB Compass** for visual database management
   - Download: https://www.mongodb.com/products/compass
   - Connect: mongodb://localhost:27017

2. **Use Redis Insight** for Redis management
   - Download: https://redis.com/redis-enterprise/redis-insight/
   - Connect: localhost:6379

3. **Use Postman** for API testing
   - Import collection from `/docs/postman`
   - Set up environments for dev/staging/prod

4. **Enable ESLint** in your IDE
   - VS Code: Install ESLint extension
   - Automatic code formatting on save

5. **Use Git hooks** for pre-commit checks
   ```bash
   npm install husky --save-dev
   npx husky install
   ```

## 🆘 Getting Help

- **Documentation**: Check all `.md` files in project root
- **Issues**: Check if similar issue exists in GitHub Issues
- **Community**: Join our Slack/Discord channel
- **Support**: Email support@ecommerce.com

## ✅ Verification Checklist

Before proceeding with development:

- [ ] Backend server starts without errors
- [ ] Frontend application loads in browser
- [ ] MongoDB connection is successful
- [ ] Redis connection is successful
- [ ] Can register a new user
- [ ] Can login with user
- [ ] Can access protected endpoints with token
- [ ] Hot reload works for both backend and frontend
- [ ] Sample data seeded successfully
- [ ] Tests pass

## 🎉 You're Ready!

Your enterprise e-commerce platform is now running. Start building amazing features!

For detailed development guidelines, see the README.md file.

Happy coding! 🚀
