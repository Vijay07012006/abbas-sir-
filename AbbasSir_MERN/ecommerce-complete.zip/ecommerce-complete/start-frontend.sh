#!/bin/bash

# Start Frontend Application
echo "🚀 Starting Frontend Application..."

cd frontend

# Check if .env.local exists
if [ ! -f ".env.local" ]; then
    echo "⚠️  .env.local file not found. Creating from template..."
    cp .env.example .env.local
    echo "Please edit frontend/.env.local with your configuration"
    exit 1
fi

# Check if node_modules exists
if [ ! -d "node_modules" ]; then
    echo "📦 Installing dependencies..."
    npm install
fi

# Start the application
echo "Starting Next.js on port 3000..."
npm run dev
