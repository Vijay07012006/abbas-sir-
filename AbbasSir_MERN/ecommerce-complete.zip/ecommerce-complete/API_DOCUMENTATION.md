# API Documentation

## Base URL
```
Development: http://localhost:5000/api/v1
Production: https://api.ecommerce.com/api/v1
```

## Authentication

All authenticated endpoints require a Bearer token in the Authorization header:
```
Authorization: Bearer <access_token>
```

### Token Refresh Flow
Access tokens expire after 15 minutes. Use refresh token to get new access token:

```bash
POST /auth/refresh
Cookie: refreshToken=<refresh_token>
```

## API Endpoints

### Authentication & User Management

#### Register User
```http
POST /auth/register
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "SecurePass123!",
  "firstName": "John",
  "lastName": "Doe",
  "phone": {
    "countryCode": "+1",
    "number": "1234567890"
  }
}

Response: 201 Created
{
  "success": true,
  "data": {
    "user": {...},
    "accessToken": "eyJhbGciOiJIUzI1NiIs...",
    "refreshToken": "eyJhbGciOiJIUzI1NiIs..."
  }
}
```

#### Login
```http
POST /auth/login
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "SecurePass123!"
}

Response: 200 OK
{
  "success": true,
  "data": {
    "user": {...},
    "accessToken": "...",
    "refreshToken": "..."
  }
}
```

#### Get Current User
```http
GET /auth/me
Authorization: Bearer <token>

Response: 200 OK
{
  "success": true,
  "data": {
    "user": {...}
  }
}
```

#### Update Profile
```http
PATCH /users/profile
Authorization: Bearer <token>
Content-Type: application/json

{
  "firstName": "Jane",
  "phone": {
    "countryCode": "+1",
    "number": "9876543210"
  }
}

Response: 200 OK
```

#### Change Password
```http
POST /users/change-password
Authorization: Bearer <token>

{
  "currentPassword": "OldPass123!",
  "newPassword": "NewPass456!"
}
```

#### Forgot Password
```http
POST /auth/forgot-password

{
  "email": "user@example.com"
}
```

#### Reset Password
```http
POST /auth/reset-password/:token

{
  "password": "NewPassword123!"
}
```

### Products

#### Get All Products
```http
GET /products?page=1&limit=20&sort=-createdAt&category=electronics&minPrice=100&maxPrice=1000&rating=4

Query Parameters:
- page: Page number (default: 1)
- limit: Items per page (default: 20, max: 100)
- sort: Sort field (prefix with - for desc)
- search: Text search query
- category: Category ID or slug
- brand: Brand ID
- minPrice: Minimum price filter
- maxPrice: Maximum price filter
- rating: Minimum rating (1-5)
- inStock: true/false
- featured: true/false
- trending: true/false

Response: 200 OK
{
  "success": true,
  "data": {
    "products": [...],
    "pagination": {
      "total": 1000,
      "page": 1,
      "pages": 50,
      "limit": 20
    }
  }
}
```

#### Get Product by ID/Slug
```http
GET /products/:id

Response: 200 OK
{
  "success": true,
  "data": {
    "product": {
      "_id": "...",
      "name": "Product Name",
      "slug": "product-name",
      "pricing": {...},
      "inventory": {...},
      "rating": {...},
      ...
    }
  }
}
```

#### Create Product (Admin/Vendor)
```http
POST /products
Authorization: Bearer <admin_token>
Content-Type: application/json

{
  "name": "Amazing Product",
  "sku": "PROD-12345",
  "description": "Detailed description...",
  "categoryId": "category_id",
  "pricing": {
    "basePrice": 99.99,
    "currentPrice": 79.99,
    "currency": "USD"
  },
  "inventory": {
    "quantity": 100,
    "lowStockThreshold": 10
  },
  "images": [
    {
      "url": "https://cdn.example.com/image1.jpg",
      "alt": "Product image",
      "isPrimary": true
    }
  ],
  "tags": ["electronics", "gadgets"]
}

Response: 201 Created
```

#### Update Product (Admin/Vendor)
```http
PATCH /products/:id
Authorization: Bearer <admin_token>

{
  "pricing": {
    "currentPrice": 69.99
  },
  "inventory": {
    "quantity": 150
  }
}

Response: 200 OK
```

#### Delete Product (Admin)
```http
DELETE /products/:id
Authorization: Bearer <admin_token>

Response: 204 No Content
```

#### Get Product Reviews
```http
GET /products/:id/reviews?page=1&limit=10&sort=-createdAt

Response: 200 OK
{
  "success": true,
  "data": {
    "reviews": [...],
    "pagination": {...}
  }
}
```

### Categories

#### Get All Categories
```http
GET /categories

Response: 200 OK
{
  "success": true,
  "data": {
    "categories": [
      {
        "_id": "...",
        "name": "Electronics",
        "slug": "electronics",
        "parentId": null,
        "level": 0,
        "children": [...]
      }
    ]
  }
}
```

#### Get Category Tree
```http
GET /categories/tree

Response: Hierarchical category structure
```

#### Create Category (Admin)
```http
POST /categories
Authorization: Bearer <admin_token>

{
  "name": "Smartphones",
  "parentId": "electronics_id",
  "description": "Latest smartphones",
  "icon": "phone",
  "seo": {
    "metaTitle": "Best Smartphones",
    "metaDescription": "..."
  }
}
```

### Cart

#### Get Cart
```http
GET /cart
Authorization: Bearer <token>

Response: 200 OK
{
  "success": true,
  "data": {
    "cart": {
      "items": [
        {
          "productId": "...",
          "productName": "...",
          "quantity": 2,
          "price": 99.99,
          "total": 199.98
        }
      ],
      "summary": {
        "subtotal": 199.98,
        "discount": 20.00,
        "estimatedTax": 18.00,
        "estimatedTotal": 197.98
      }
    }
  }
}
```

#### Add to Cart
```http
POST /cart/items
Authorization: Bearer <token>

{
  "productId": "product_id",
  "quantity": 1,
  "variantOptions": [
    { "name": "Color", "value": "Red" },
    { "name": "Size", "value": "Large" }
  ]
}

Response: 200 OK
```

#### Update Cart Item
```http
PATCH /cart/items/:itemId
Authorization: Bearer <token>

{
  "quantity": 3
}
```

#### Remove from Cart
```http
DELETE /cart/items/:itemId
Authorization: Bearer <token>

Response: 200 OK
```

#### Apply Coupon
```http
POST /cart/coupon
Authorization: Bearer <token>

{
  "code": "SUMMER20"
}

Response: 200 OK
{
  "success": true,
  "data": {
    "discount": 39.99,
    "newTotal": 157.99
  }
}
```

### Orders

#### Create Order
```http
POST /orders
Authorization: Bearer <token>

{
  "shippingAddress": {
    "firstName": "John",
    "lastName": "Doe",
    "street": "123 Main St",
    "city": "New York",
    "state": "NY",
    "country": "USA",
    "postalCode": "10001",
    "phone": "1234567890"
  },
  "billingAddress": {
    "sameAsShipping": true
  },
  "shipping": {
    "method": "STANDARD"
  },
  "payment": {
    "method": "CARD",
    "provider": "STRIPE"
  }
}

Response: 201 Created
{
  "success": true,
  "data": {
    "order": {
      "orderNumber": "ORD-2024-001234",
      "total": 197.98,
      "status": "PENDING"
    }
  }
}
```

#### Get User Orders
```http
GET /orders?page=1&limit=10&status=DELIVERED

Query Parameters:
- status: PENDING, CONFIRMED, PROCESSING, SHIPPED, DELIVERED, CANCELLED

Response: 200 OK
{
  "success": true,
  "data": {
    "orders": [...],
    "pagination": {...}
  }
}
```

#### Get Order by ID
```http
GET /orders/:id
Authorization: Bearer <token>

Response: 200 OK
```

#### Update Order Status (Admin)
```http
PATCH /orders/:id/status
Authorization: Bearer <admin_token>

{
  "status": "SHIPPED",
  "note": "Shipped via FedEx"
}
```

#### Cancel Order
```http
POST /orders/:id/cancel
Authorization: Bearer <token>

{
  "reason": "Changed my mind"
}
```

### Reviews

#### Create Review
```http
POST /reviews
Authorization: Bearer <token>

{
  "productId": "product_id",
  "orderId": "order_id",
  "rating": 5,
  "title": "Excellent product!",
  "comment": "Highly recommend...",
  "images": ["url1", "url2"]
}

Response: 201 Created
```

#### Update Review
```http
PATCH /reviews/:id
Authorization: Bearer <token>

{
  "rating": 4,
  "comment": "Updated review..."
}
```

#### Delete Review
```http
DELETE /reviews/:id
Authorization: Bearer <token>

Response: 204 No Content
```

#### Mark Review as Helpful
```http
POST /reviews/:id/helpful
Authorization: Bearer <token>

Response: 200 OK
```

### Payment

#### Create Payment Intent (Stripe)
```http
POST /payments/create-intent
Authorization: Bearer <token>

{
  "orderId": "order_id",
  "amount": 19798
}

Response: 200 OK
{
  "success": true,
  "data": {
    "clientSecret": "pi_xxx_secret_xxx"
  }
}
```

#### Webhook Handler
```http
POST /payments/webhook/stripe
Stripe-Signature: t=xxx,v1=xxx

Handles: payment_intent.succeeded, payment_intent.failed, etc.
```

### Search

#### Search Products
```http
GET /search?q=laptop&category=electronics&sort=price

Response: 200 OK
{
  "success": true,
  "data": {
    "results": [...],
    "suggestions": ["laptop bag", "laptop stand"],
    "filters": {
      "brands": [...],
      "priceRanges": [...],
      "ratings": [...]
    }
  }
}
```

#### Autocomplete
```http
GET /search/autocomplete?q=lap

Response: 200 OK
{
  "success": true,
  "data": {
    "suggestions": [
      "laptop",
      "laptop bag",
      "laptop stand"
    ]
  }
}
```

### Admin Analytics

#### Get Dashboard Stats
```http
GET /admin/analytics/dashboard
Authorization: Bearer <admin_token>

Response: 200 OK
{
  "success": true,
  "data": {
    "totalRevenue": 1234567.89,
    "totalOrders": 5432,
    "totalCustomers": 12345,
    "averageOrderValue": 227.35,
    "topProducts": [...],
    "recentOrders": [...],
    "salesChart": {...}
  }
}
```

#### Get Sales Report
```http
GET /admin/analytics/sales?startDate=2024-01-01&endDate=2024-12-31&groupBy=month

Query Parameters:
- startDate: ISO date string
- endDate: ISO date string
- groupBy: day, week, month, year

Response: Sales data grouped by period
```

## Error Responses

All errors follow this format:

```json
{
  "success": false,
  "error": {
    "code": "ERROR_CODE",
    "message": "Human-readable error message",
    "details": {} // Optional additional details
  }
}
```

### Common Error Codes

- `400` - Bad Request (Validation errors)
- `401` - Unauthorized (Invalid/missing token)
- `403` - Forbidden (Insufficient permissions)
- `404` - Not Found
- `409` - Conflict (Duplicate resource)
- `429` - Too Many Requests (Rate limit exceeded)
- `500` - Internal Server Error

### Example Error Response

```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Validation failed",
    "details": {
      "fields": {
        "email": "Invalid email format",
        "password": "Password must be at least 8 characters"
      }
    }
  }
}
```

## Rate Limiting

Rate limits are applied per IP address:

- **Anonymous users**: 100 requests per 15 minutes
- **Authenticated users**: 1000 requests per 15 minutes
- **Premium users**: 5000 requests per 15 minutes

Rate limit headers are included in responses:

```
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1640995200
```

## Pagination

All list endpoints support pagination:

**Request:**
```
GET /products?page=2&limit=20
```

**Response:**
```json
{
  "success": true,
  "data": {
    "products": [...],
    "pagination": {
      "total": 1000,
      "page": 2,
      "pages": 50,
      "limit": 20,
      "hasNextPage": true,
      "hasPrevPage": true
    }
  }
}
```

## Sorting

Sort by any field using the `sort` parameter:

```
GET /products?sort=-createdAt,name
```

- Prefix with `-` for descending order
- Comma-separated for multiple fields
- Default: `-createdAt`

## Filtering

Filter results using query parameters:

```
GET /products?category=electronics&minPrice=100&maxPrice=500&inStock=true
```

Supported operators:
- Exact match: `field=value`
- Range: `minField=100&maxField=500`
- Boolean: `inStock=true`
- Array contains: `tags=electronics`

## Field Selection

Request specific fields using the `fields` parameter:

```
GET /products?fields=name,price,images
```

Response will only include requested fields plus `_id`.

## Webhooks

Configure webhooks to receive real-time notifications:

### Supported Events

- `order.created`
- `order.updated`
- `order.cancelled`
- `payment.succeeded`
- `payment.failed`
- `product.created`
- `product.updated`
- `inventory.low_stock`

### Webhook Payload

```json
{
  "event": "order.created",
  "timestamp": "2024-01-15T10:30:00Z",
  "data": {
    "orderId": "...",
    "orderNumber": "ORD-2024-001234",
    ...
  }
}
```

### Webhook Security

All webhooks are signed. Verify the signature:

```javascript
const crypto = require('crypto');

const signature = req.headers['x-webhook-signature'];
const payload = JSON.stringify(req.body);
const hash = crypto
  .createHmac('sha256', webhookSecret)
  .update(payload)
  .digest('hex');

if (hash === signature) {
  // Webhook is authentic
}
```
