#!/bin/bash

# 🚀 E-Commerce Platform - One Click Start
# Ye script automatically sab kuch setup kar dega

clear
echo "=================================="
echo "🚀 E-Commerce Platform Starting..."
echo "=================================="
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Check Docker
if ! command -v docker &> /dev/null; then
    echo -e "${RED}❌ Docker install nahi hai${NC}"
    echo ""
    echo "Option 1: Docker install karo"
    echo "  sudo apt install docker.io docker-compose"
    echo ""
    echo "Option 2: Manual setup use karo"
    echo "  ./start-manual.sh"
    exit 1
fi

# Check Docker running
if ! docker ps &> /dev/null; then
    echo -e "${YELLOW}⚠️  Docker ko permission chahiye${NC}"
    echo ""
    echo "Ye command run karo:"
    echo -e "${BLUE}  sudo usermod -aG docker \$USER${NC}"
    echo -e "${BLUE}  newgrp docker${NC}"
    echo ""
    echo "Ya phir sudo ke saath run karo:"
    echo -e "${BLUE}  sudo ./start.sh${NC}"
    echo ""
    read -p "Sudo ke saath continue kare? (y/n): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        USE_SUDO="sudo"
    else
        exit 1
    fi
fi

echo -e "${BLUE}📦 Checking existing containers...${NC}"

# Stop existing containers
if $USE_SUDO docker-compose ps | grep -q "Up"; then
    echo "Purane containers stop kar rahe hai..."
    $USE_SUDO docker-compose down
fi

echo ""
echo -e "${BLUE}🐳 Docker containers start kar rahe hai...${NC}"
echo "Thoda wait karo, pehli baar setup hone me 2-3 minute lag sakte hai..."
echo ""

# Start containers
$USE_SUDO docker-compose up -d

# Wait for services
echo ""
echo -e "${YELLOW}⏳ Services ready ho rahi hai...${NC}"
sleep 10

# Check if services are up
echo ""
echo -e "${BLUE}📊 Service Status:${NC}"
$USE_SUDO docker-compose ps

echo ""
echo -e "${GREEN}=================================="
echo "✅ Project Successfully Started!"
echo "==================================${NC}"
echo ""
echo -e "${GREEN}🌐 Frontend:${NC} http://localhost:3000"
echo -e "${GREEN}🔧 Backend:${NC}  http://localhost:5000"
echo -e "${GREEN}📊 MongoDB:${NC}  localhost:27017"
echo -e "${GREEN}💾 Redis:${NC}    localhost:6379"
echo ""
echo -e "${YELLOW}📝 Useful Commands:${NC}"
echo "  ./stop.sh    - Project band karne ke liye"
echo "  ./logs.sh    - Logs dekhne ke liye"
echo "  ./reset.sh   - Sab reset karne ke liye"
echo ""
echo -e "${BLUE}🔍 Logs dekhne ke liye:${NC}"
echo "  $USE_SUDO docker-compose logs -f"
echo ""
echo -e "${GREEN}Happy Coding! 🎉${NC}"
