# Troubleshooting Guide

## Common Issues and Solutions

### 1. Docker Permission Denied

**Error:**
```
permission denied while trying to connect to the Docker daemon socket
```

**Solutions:**

**Option A: Add user to docker group (Recommended)**
```bash
# Add your user to docker group
sudo usermod -aG docker $USER

# Log out and log back in (or run)
newgrp docker

# Verify
docker ps
```

**Option B: Use sudo**
```bash
sudo docker-compose up -d
```

**Option C: Fix docker socket permissions**
```bash
sudo chmod 666 /var/run/docker.sock
```

### 2. "next: not found" Error

**Error:**
```
sh: 1: next: not found
```

**Cause:** Dependencies not installed

**Solution:**
```bash
cd frontend
npm install
npm run dev
```

### 3. MongoDB Connection Failed

**Error:**
```
MongoDB connection failed
```

**Solution 1: Install MongoDB**
```bash
# Ubuntu/Debian
sudo apt update
sudo apt install -y mongodb

# Start MongoDB
sudo systemctl start mongodb
sudo systemctl enable mongodb

# Verify
sudo systemctl status mongodb
```

**Solution 2: Use Docker for MongoDB only**
```bash
docker run -d -p 27017:27017 --name mongodb mongo:7
```

### 4. Redis Connection Failed

**Error:**
```
Redis connection failed
```

**Solution 1: Install Redis**
```bash
# Ubuntu/Debian
sudo apt install -y redis-server

# Start Redis
sudo systemctl start redis-server
sudo systemctl enable redis-server

# Verify
redis-cli ping
```

**Solution 2: Use Docker for Redis only**
```bash
docker run -d -p 6379:6379 --name redis redis:7-alpine
```

### 5. Port Already in Use

**Error:**
```
Error: listen EADDRINUSE: address already in use :::5000
```

**Solution:**
```bash
# Find process using the port
sudo lsof -i :5000

# Kill the process
sudo kill -9 <PID>

# Or change port in backend/.env
PORT=5001
```

### 6. Module Not Found Errors

**Error:**
```
Cannot find module 'express'
```

**Solution:**
```bash
# Backend
cd backend
rm -rf node_modules package-lock.json
npm install

# Frontend
cd frontend
rm -rf node_modules package-lock.json
npm install
```

### 7. Docker Compose Version Warning

**Warning:**
```
the attribute `version` is obsolete
```

**This is just a warning - safe to ignore**

Or update docker-compose.yml:
```yaml
# Remove this line:
# version: '3.8'

# Just start with:
services:
  mongodb:
    ...
```

## Step-by-Step Setup (Manual)

### 1. Install Prerequisites

**Node.js 20+**
```bash
# Ubuntu/Debian
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Verify
node --version  # Should be v20.x.x
npm --version   # Should be 10.x.x
```

**MongoDB**
```bash
# Ubuntu/Debian
sudo apt install -y mongodb

# Start and enable
sudo systemctl start mongodb
sudo systemctl enable mongodb
```

**Redis**
```bash
# Ubuntu/Debian
sudo apt install -y redis-server

# Start and enable
sudo systemctl start redis-server
sudo systemctl enable redis-server
```

### 2. Setup Backend

```bash
cd ecommerce-platform/backend

# Install dependencies
npm install

# Create environment file
cp .env.example .env

# Edit configuration
nano .env
```

**Minimum .env configuration:**
```env
NODE_ENV=development
PORT=5000
MONGODB_URI=mongodb://localhost:27017/ecommerce
REDIS_HOST=localhost
REDIS_PORT=6379
JWT_SECRET=your-secret-key-change-this
JWT_REFRESH_SECRET=your-refresh-secret-change-this
```

```bash
# Start backend
npm run dev
```

### 3. Setup Frontend

```bash
cd ../frontend

# Install dependencies
npm install

# Create environment file
cp .env.example .env.local

# Edit configuration
nano .env.local
```

**Minimum .env.local configuration:**
```env
NEXT_PUBLIC_API_URL=http://localhost:5000/api/v1
```

```bash
# Start frontend
npm run dev
```

### 4. Verify Installation

**Test Backend:**
```bash
curl http://localhost:5000/health
# Expected: {"status":"ok",...}
```

**Test Frontend:**
Open browser: http://localhost:3000

## Quick Setup with Scripts

Make scripts executable:
```bash
chmod +x setup.sh start-backend.sh start-frontend.sh
```

Run setup:
```bash
./setup.sh
```

Start services:
```bash
# Terminal 1
./start-backend.sh

# Terminal 2
./start-frontend.sh
```

## Docker Setup (Recommended)

### Fix Docker Permissions First

```bash
# Add user to docker group
sudo usermod -aG docker $USER

# Logout and login, or run:
newgrp docker

# Test
docker ps
```

### Start with Docker

```bash
# Start all services
docker-compose up -d

# View logs
docker-compose logs -f

# Stop services
docker-compose down
```

## Checking Service Status

**MongoDB:**
```bash
sudo systemctl status mongodb
# Or
mongosh --eval "db.adminCommand('ping')"
```

**Redis:**
```bash
sudo systemctl status redis-server
# Or
redis-cli ping
```

**Backend:**
```bash
curl http://localhost:5000/health
```

**Frontend:**
```bash
curl http://localhost:3000
```

## Clean Start

If things are completely broken:

```bash
# Stop everything
docker-compose down -v
sudo systemctl stop mongodb
sudo systemctl stop redis-server

# Clean node_modules
cd backend && rm -rf node_modules package-lock.json
cd ../frontend && rm -rf node_modules package-lock.json

# Reinstall
cd ../backend && npm install
cd ../frontend && npm install

# Restart databases
sudo systemctl start mongodb
sudo systemctl start redis-server

# Start application
cd ../backend && npm run dev &
cd ../frontend && npm run dev
```

## Getting Help

1. Check logs:
   ```bash
   # Docker
   docker-compose logs backend
   docker-compose logs frontend
   
   # Manual
   tail -f backend/logs/combined.log
   ```

2. Check system resources:
   ```bash
   # Memory
   free -h
   
   # Disk space
   df -h
   ```

3. Check network:
   ```bash
   # Ports in use
   sudo netstat -tulpn | grep -E '3000|5000|27017|6379'
   ```

## Still Having Issues?

1. Read QUICK_START.md
2. Read ARCHITECTURE.md
3. Check GitHub issues
4. Contact support
